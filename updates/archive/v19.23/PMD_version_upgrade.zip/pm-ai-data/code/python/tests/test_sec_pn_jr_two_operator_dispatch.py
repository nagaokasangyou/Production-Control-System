# -*- coding: utf-8 -*-
"""特別ルール L7（SEC / EC × SEC機 湖南・PN/JR 開始の原則 2 名配台）のテスト。"""

from __future__ import annotations

from datetime import date, datetime

import pytest

from planning_core import _core as pc


# ---------------------------------------------------------------------------
# 1. match_need_sheet_condition（依頼NO条件の接頭辞・NFKC・大小文字正規化）
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("cond", "task_id", "expected"),
    [
        ("prefix:PN", "PN06-01", True),
        ("prefix:JR", "JR260902", True),
        ("prefix:PN", "ＰＮ０６－０１", True),
        ("prefix:JR", "ＪＲ２６０９０２", True),
        ("prefix:ＰＮ", "pn06-01", True),
        ("prefix:ＪＲ", "  jr260902  ", True),
        ("接頭辞:PN", "pn06-01", True),
        ("接頭辞：ＪＲ", "ＪＲ260903", True),
        ("PN", "ＰＮ06-01", True),
        ("JR", "jr260902", True),
        ("prefix:PN", "XPN06-01", False),
        ("prefix:PN", "C9-PN01", False),
        ("prefix:JR", "AJR260902", False),
        ("prefix:JR", "C9-JR01", False),
        ("prefix:PN", "C9-12", False),
        ("prefix:", "PN06-01", False),
        ("regex:^JR\\d+", "ＪＲ260902", True),
        ("regex:^JR\\d+", "AJR260902", False),
        ("*", "C9-12", True),
        ("全件", "C9-12", True),
        ("", "C9-12", True),
    ],
)
def test_match_need_sheet_condition_prefix_normalization(cond, task_id, expected):
    assert pc.match_need_sheet_condition(cond, task_id) is expected


# ---------------------------------------------------------------------------
# 2. _apply_special_rule_l7_sec_two_op（L7 ヘルパ単体）
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    ("proc", "mach", "task", "req_in", "req_out", "matched"),
    [
        ("SEC", "SEC機　湖南", {"task_id": "PN06-01"}, 3, 2, True),
        ("SEC", "SEC機　湖南", {"task_id": "JR260902"}, 3, 2, True),
        ("EC", "SEC機　湖南", {"task_id": "PN06-01"}, 3, 2, True),
        ("EC", "SEC機　湖南", {"task_id": "JR260902"}, 3, 2, True),
        ("ＳＥＣ", "ＳＥＣ機 湖南", {"task_id": "ＰＮ０６－０１"}, 3, 2, True),
        ("sec", "sec機　湖南", {"task_id": "  jr260903 "}, 3, 2, True),
        # 枝番タスクは親 rule_task_id で判定
        ("EC", "SEC機　湖南", {"task_id": "PN06-01-01", "rule_task_id": "PN06-01"}, 3, 2, True),
        ("SEC", "SEC機　湖南", {"task_id": "X-01", "rule_task_id": "JR260902"}, 3, 2, True),
        # 既に need 特別指定で req_num=2 でも matched=True を返す（超過プリセット抑止用）
        ("SEC", "SEC機　湖南", {"task_id": "JR260902"}, 2, 2, True),
        # 途中含有は対象外（接頭辞のみ）
        ("SEC", "SEC機　湖南", {"task_id": "XPN06-01"}, 3, 3, False),
        ("SEC", "SEC機　湖南", {"task_id": "C9-JR01"}, 3, 3, False),
        ("SEC", "SEC機　湖南", {"task_id": "C9-12"}, 3, 3, False),
        # 別工程・別機械・国分は対象外
        ("穴あけ", "SEC機　湖南", {"task_id": "PN06-01"}, 2, 2, False),
        ("EC", "EC機　湖南", {"task_id": "PN06-01"}, 3, 3, False),
        ("EC", "LAC/EC機", {"task_id": "PN06-01"}, 3, 3, False),
        ("SEC", "SEC機　国分", {"task_id": "JR260902"}, 3, 3, False),
    ],
)
def test_apply_special_rule_l7_sec_two_op(proc, mach, task, req_in, req_out, matched):
    got_req, got_src, got_matched = pc._apply_special_rule_l7_sec_two_op(
        proc, mach, task, req_in, "base"
    )
    assert got_req == req_out
    assert got_matched is matched
    if matched and req_in > 2:
        assert "特別ルールL7(PN/JR)" in got_src
    else:
        assert got_src == "base"


# ---------------------------------------------------------------------------
# 3. _combo_preset_team_size_bounds（安全性・緩和時超過抑止・既存互換）
# ---------------------------------------------------------------------------
def test_combo_preset_bounds_rejects_under_minimum_team_size(monkeypatch):
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_MAY_EXCEED_NEED", True)
    # 3名必須の通常SECに対し、2名プリセットは絶対に採用不可
    assert (
        pc._combo_preset_team_size_bounds(
            ("冨田", "竹内"), 2, 3, min_team_size_need=3, allow_exceed_need=True
        )
        is None
    )
    assert (
        pc._combo_preset_team_size_bounds(
            ("冨田", "竹内"), 2, 3, min_team_size_need=3, allow_exceed_need=False
        )
        is None
    )
    # sheet_req_n 省略行でも実人数 < min_team_size_need は不可
    assert (
        pc._combo_preset_team_size_bounds(
            ("冨田", "竹内"), None, 3, min_team_size_need=3, allow_exceed_need=True
        )
        is None
    )


def test_combo_preset_bounds_suppresses_3op_preset_when_relaxed_to_2op(monkeypatch):
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_MAY_EXCEED_NEED", True)
    # グローバル MAY_EXCEED_NEED=True でも allow_exceed_need=False なら 3 名プリセットを拒否
    assert (
        pc._combo_preset_team_size_bounds(
            ("冨田", "竹内", "菅沼"),
            3,
            2,
            min_team_size_need=2,
            allow_exceed_need=False,
        )
        is None
    )
    # 2名プリセットなら通る
    assert pc._combo_preset_team_size_bounds(
        ("冨田", "竹内"),
        2,
        2,
        min_team_size_need=2,
        allow_exceed_need=False,
    ) == (2, 2)


def test_combo_preset_bounds_preserves_normal_exceed_need_behavior(monkeypatch):
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_MAY_EXCEED_NEED", True)
    # 通常の need 超過許可（例: スリット基本1名・2名プリセット）は従来どおり許可
    assert pc._combo_preset_team_size_bounds(
        ("宮島", "竹内"),
        2,
        1,
        min_team_size_need=1,
        allow_exceed_need=True,
    ) == (2, 2)
    # 引数省略時の後方互換
    assert pc._combo_preset_team_size_bounds(("宮島", "竹内"), 2, 1) == (2, 2)


# ---------------------------------------------------------------------------
# 4. エンドツーエンド: _assign_one_roll_trial_order_flow
# ---------------------------------------------------------------------------
def _make_sec_env(monkeypatch):
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_MAY_EXCEED_NEED", True)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_RESTRICT_TO_PRESET_MEMBERS", True)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_START_SLACK_WAIT_MINUTES", 60)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_HEADCOUNT_FROM_NEED_ONLY", True)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_USE_NEED_SURPLUS_IN_MAIN_PASS", False)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_IGNORE_NEED_SURPLUS_ROW", False)

    day = date(2026, 9, 29)
    start_dt = datetime(2026, 9, 29, 8, 25)
    end_dt = datetime(2026, 9, 29, 17, 0)
    members = ["冨田　裕子", "宮島　　剛", "森岡　真由美", "図司　智子", "竹内　正美", "菅沼　めぐみ"]
    daily_status = {
        m: {
            "start_dt": start_dt,
            "end_dt": end_dt,
            "breaks_dt": [],
            "efficiency": 1.0,
            "is_working": True,
        }
        for m in members
    }
    avail_dt = {m: start_dt for m in members}
    skills_dict = {
        "冨田　裕子": {"SEC+SEC機　湖南": "OP1", "EC+SEC機　湖南": "OP1", "スリット+スリット機1　湖南": "OP5"},
        "宮島　　剛": {"SEC+SEC機　湖南": "OP4", "EC+SEC機　湖南": "OP2", "スリット+スリット機1　湖南": "OP1"},
        "森岡　真由美": {"SEC+SEC機　湖南": "OP5", "EC+SEC機　湖南": "OP5", "スリット+スリット機1　湖南": "AS2"},
        "図司　智子": {"SEC+SEC機　湖南": "OP6", "EC+SEC機　湖南": "OP6", "スリット+スリット機1　湖南": "OP6"},
        "竹内　正美": {"SEC+SEC機　湖南": "AS3", "EC+SEC機　湖南": "AS3", "スリット+スリット機1　湖南": "AS3"},
        "菅沼　めぐみ": {"SEC+SEC機　湖南": "AS2", "EC+SEC機　湖南": "AS4", "スリット+スリット機1　湖南": "AS4"},
    }
    req_map = {
        "SEC+SEC機 湖南": 3,
        "EC+SEC機 湖南": 3,
        "スリット+スリット機1 湖南": 1,
    }
    need_rules = [
        {"order": 1, "condition": "prefix:JR", "overrides": {"SEC+SEC機 湖南": 2}},
        {"order": 2, "condition": "prefix:PN", "overrides": {"SEC+SEC機 湖南": 2}},
    ]
    presets = {
        "SEC+SEC機　湖南": [
            (1.0, 3, ("冨田　裕子", "竹内　正美", "菅沼　めぐみ"), 28),
            (2.0, 3, ("冨田　裕子", "宮島　　剛", "菅沼　めぐみ"), 29),
            (3.0, 3, ("冨田　裕子", "宮島　　剛", "竹内　正美"), 30),
        ],
        "EC+SEC機　湖南": [
            (1.0, 3, ("冨田　裕子", "森岡　真由美", "竹内　正美"), 8),
            (2.0, 3, ("冨田　裕子", "図司　智子", "竹内　正美"), 9),
        ],
        "スリット+スリット機1　湖南": [
            (1.0, 2, ("宮島　　剛", "森岡　真由美"), 70),
            (2.0, 1, ("宮島　　剛",), 71),
        ],
    }
    return day, start_dt, members, daily_status, avail_dt, skills_dict, req_map, need_rules, presets


def _make_task(task_id: str, proc: str, mach: str, *, limited_operator_names=(), rule_task_id: str = ""):
    return {
        "task_id": task_id,
        "rule_task_id": rule_task_id or task_id,
        "machine": proc,
        "machine_name": mach,
        "equipment_line_key": f"{proc}+{mach}",
        "unit_m": 100.0,
        "remaining_units": 5.0,
        "initial_remaining_units": 5.0,
        "base_time_per_unit": 5.0,
        "start_date_req": date(2026, 9, 29),
        "assigned_history": [],
        "dispatch_trial_order": 1,
        "limited_operator_names": tuple(limited_operator_names),
    }


def test_assign_sec_jr_and_pn_use_2_operators_while_normal_sec_uses_3(monkeypatch):
    day, start_dt, members, daily_status, avail_dt, skills_dict, req_map, need_rules, presets = (
        _make_sec_env(monkeypatch)
    )

    # 1. JR on SEC×SEC機 湖南（need特別指定1 + 3名プリセット群 + MAY_EXCEED_NEED=True）→ 2名で配台
    t_jr = _make_task("JR260902", "SEC", "SEC機　湖南")
    res_jr = pc._assign_one_roll_trial_order_flow(
        t_jr,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_jr],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res_jr is not None
    assert res_jr["req_num"] == 2
    assert len(res_jr["team"]) == 2
    assert res_jr["combo_sheet_row_id"] is None

    # 2. PN on EC×SEC機 湖南（need_rules 空でも L7 が効き、3名プリセット超過を抑止して 2名で配台）
    t_pn_ec = _make_task("PN06-01", "EC", "SEC機　湖南")
    res_pn_ec = pc._assign_one_roll_trial_order_flow(
        t_pn_ec,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_pn_ec],
        skills_dict,
        members,
        req_map,
        [],
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res_pn_ec is not None
    assert res_pn_ec["req_num"] == 2
    assert len(res_pn_ec["team"]) == 2

    # 3. 全角・小文字（ＰＮ / ｊｒ）も 2名で配台
    for tid, proc in [("ＰＮ０６－０２", "EC"), ("ｊｒ260903", "SEC")]:
        t_norm = _make_task(tid, proc, "SEC機　湖南")
        res_norm = pc._assign_one_roll_trial_order_flow(
            t_norm,
            day,
            daily_status,
            dict(avail_dt),
            {},
            [t_norm],
            skills_dict,
            members,
            req_map,
            [],
            {},
            {},
            day,
            start_dt,
            None,
            set(),
            team_combo_presets=presets,
        )
        assert res_norm is not None
        assert len(res_norm["team"]) == 2

    # 4. 通常SEC（C9-12）は従来どおり 3名プリセット #28 で配台
    t_normal = _make_task("C9-12", "SEC", "SEC機　湖南")
    res_normal = pc._assign_one_roll_trial_order_flow(
        t_normal,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_normal],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res_normal is not None
    assert res_normal["req_num"] == 3
    assert len(res_normal["team"]) == 3
    assert res_normal["combo_sheet_row_id"] == 28


def test_assign_2op_preset_in_combo_sheet_never_leaks_to_normal_3op_sec(monkeypatch):
    day, start_dt, members, daily_status, avail_dt, skills_dict, req_map, need_rules, presets = (
        _make_sec_env(monkeypatch)
    )
    # 組み合わせ表に 2名プリセット行を追加しても、通常3名SEC(C9-12)には使われず、JRには使われる
    presets_with_2op = dict(presets)
    presets_with_2op["SEC+SEC機　湖南"] = [
        (0.5, 2, ("冨田　裕子", "菅沼　めぐみ"), 99),
        *presets["SEC+SEC機　湖南"],
    ]

    t_normal = _make_task("C9-12", "SEC", "SEC機　湖南")
    res_normal = pc._assign_one_roll_trial_order_flow(
        t_normal,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_normal],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets_with_2op,
    )
    assert res_normal is not None
    assert len(res_normal["team"]) == 3
    assert res_normal["combo_sheet_row_id"] == 28

    t_jr = _make_task("JR260902", "SEC", "SEC機　湖南")
    res_jr = pc._assign_one_roll_trial_order_flow(
        t_jr,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_jr],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets_with_2op,
    )
    assert res_jr is not None
    assert len(res_jr["team"]) == 2
    assert res_jr["combo_sheet_row_id"] == 99


def test_assign_limited_operator_3_overrides_l7_and_other_machine_exceed_need_unchanged(
    monkeypatch,
):
    day, start_dt, members, daily_status, avail_dt, skills_dict, req_map, need_rules, presets = (
        _make_sec_env(monkeypatch)
    )

    # 担当OP_限定で 3名明示指定された PN タスクは 3名指定を尊重する
    t_lim = _make_task(
        "PN06-01",
        "EC",
        "SEC機　湖南",
        limited_operator_names=("冨田　裕子", "森岡　真由美", "竹内　正美"),
    )
    res_lim = pc._assign_one_roll_trial_order_flow(
        t_lim,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_lim],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res_lim is not None
    assert len(res_lim["team"]) == 3

    # 非SEC設備（スリット基本1名・2名プリセット・MAY_EXCEED_NEED=True）は従来どおり 2名プリセット許可
    t_slit = _make_task("Y6-1", "スリット", "スリット機1　湖南")
    res_slit = pc._assign_one_roll_trial_order_flow(
        t_slit,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_slit],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res_slit is not None
    assert len(res_slit["team"]) == 2
    assert res_slit["combo_sheet_row_id"] == 70


def test_assign_sec_jr_starts_earlier_with_2_ops_without_waiting_60m_for_3rd_op(monkeypatch):
    day, start_dt, members, daily_status, avail_dt, skills_dict, req_map, need_rules, presets = (
        _make_sec_env(monkeypatch)
    )
    # 2名のみ 9:00 から空き、他のメンバーは 9:30 まで占有（スラック60分以内）
    # 旧実装は 3名プリセットを待って 9:30 開始・3名消費していたが、新実装は 9:00 開始・2名で配台する
    early_dt = datetime(2026, 9, 29, 9, 0)
    later_dt = datetime(2026, 9, 29, 9, 30)
    staggered_avail = {m: later_dt for m in members}
    staggered_avail["冨田　裕子"] = early_dt
    staggered_avail["菅沼　めぐみ"] = early_dt

    t_jr = _make_task("JR260902", "SEC", "SEC機　湖南")
    res_jr = pc._assign_one_roll_trial_order_flow(
        t_jr,
        day,
        daily_status,
        staggered_avail,
        {},
        [t_jr],
        skills_dict,
        members,
        req_map,
        need_rules,
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res_jr is not None
    assert len(res_jr["team"]) == 2
    assert set(res_jr["team"]) == {"冨田　裕子", "菅沼　めぐみ"}
    assert res_jr["team_start"] == early_dt


# ---------------------------------------------------------------------------
# 5. 回帰テスト: L3（EC × EC機 湖南・NR28）の 2名プリセット救済 & 3名優先、および L2 維持
# ---------------------------------------------------------------------------
def test_l3_nr28_ec_machine_allows_2op_preset_when_only_2_capable_ops_exist(monkeypatch):
    """EC+EC機 湖南は基本人数=2・有資格2名・組み合わせ表も2名プリセットのみ。
    L3(NR28) で req_num=3 に上がっても 2名プリセットで配台成立することを確認する。"""
    day, start_dt, _members, _ds, _av, _sk, _rm, _nr, _pr = _make_sec_env(monkeypatch)
    end_dt = datetime(2026, 9, 29, 17, 0)
    members = ["宮島　　剛", "竹内　正美"]
    daily_status = {
        m: {
            "start_dt": start_dt,
            "end_dt": end_dt,
            "breaks_dt": [],
            "efficiency": 1.0,
            "is_working": True,
        }
        for m in members
    }
    avail_dt = {m: start_dt for m in members}
    skills_dict = {
        "宮島　　剛": {"EC+EC機　湖南": "OP1"},
        "竹内　正美": {"EC+EC機　湖南": "AS1"},
    }
    req_map = {"EC+EC機 湖南": 2}
    presets = {
        "EC+EC機　湖南": [
            (1.0, 2, ("宮島　　剛", "竹内　正美"), 101),
        ],
    }

    t_e11_2 = _make_task("E11-2", "EC", "EC機　湖南")
    t_e11_2[pc.TASK_COL_PRODUCT] = "15025-NR28"

    res = pc._assign_one_roll_trial_order_flow(
        t_e11_2,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_e11_2],
        skills_dict,
        members,
        req_map,
        [],
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res is not None
    assert res["req_num"] == 3
    assert len(res["team"]) == 2
    assert set(res["team"]) == {"宮島　　剛", "竹内　正美"}
    assert res["combo_sheet_row_id"] == 101


def test_l3_nr28_ec_machine_prefers_3op_combinatorial_team_when_3_capable_ops_exist(
    monkeypatch,
):
    """L3(NR28) で有資格3名が揃う場合は、2名プリセットが残っていても -len(team) で3名編成が勝つ。"""
    day, start_dt, _members, _ds, _av, _sk, _rm, _nr, _pr = _make_sec_env(monkeypatch)
    end_dt = datetime(2026, 9, 29, 17, 0)
    members = ["宮島　　剛", "竹内　正美", "森岡　真由美"]
    daily_status = {
        m: {
            "start_dt": start_dt,
            "end_dt": end_dt,
            "breaks_dt": [],
            "efficiency": 1.0,
            "is_working": True,
        }
        for m in members
    }
    avail_dt = {m: start_dt for m in members}
    skills_dict = {
        "宮島　　剛": {"EC+EC機　湖南": "OP1"},
        "竹内　正美": {"EC+EC機　湖南": "AS1"},
        "森岡　真由美": {"EC+EC機　湖南": "AS2"},
    }
    req_map = {"EC+EC機 湖南": 2}
    presets = {
        "EC+EC機　湖南": [
            (1.0, 2, ("宮島　　剛", "竹内　正美"), 101),
            (2.0, 2, ("宮島　　剛", "森岡　真由美"), 102),
        ],
    }

    t_e11_2 = _make_task("E11-2", "EC", "EC機　湖南")
    t_e11_2[pc.TASK_COL_PRODUCT] = "15025-NR28"

    res = pc._assign_one_roll_trial_order_flow(
        t_e11_2,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_e11_2],
        skills_dict,
        members,
        req_map,
        [],
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res is not None
    assert res["req_num"] == 3
    assert len(res["team"]) == 3
    assert set(res["team"]) == {"宮島　　剛", "竹内　正美", "森岡　真由美"}


def test_l2_slice_100m_still_falls_back_to_2op_speed20_when_only_2_ops_exist(
    monkeypatch,
):
    """L2（スライス×スライス機1 湖南・100m）の3名強制フェーズは2名プリセットを通さず、
    3名が組めないときは従来どおり速度20m/分の2名フォールバックへ遷移する。"""
    day, start_dt, _members, _ds, _av, _sk, _rm, _nr, _pr = _make_sec_env(monkeypatch)
    end_dt = datetime(2026, 9, 29, 17, 0)
    members = ["宮島　　剛", "竹内　正美"]
    daily_status = {
        m: {
            "start_dt": start_dt,
            "end_dt": end_dt,
            "breaks_dt": [],
            "efficiency": 1.0,
            "is_working": True,
        }
        for m in members
    }
    avail_dt = {m: start_dt for m in members}
    skills_dict = {
        "宮島　　剛": {"スライス+スライス機1　湖南": "OP1"},
        "竹内　正美": {"スライス+スライス機1　湖南": "AS1"},
    }
    req_map = {"スライス+スライス機1 湖南": 2}
    presets = {
        "スライス+スライス機1　湖南": [
            (1.0, 2, ("宮島　　剛", "竹内　正美"), 201),
        ],
    }

    t_l2 = _make_task("S11-1", "スライス", "スライス機1　湖南")
    t_l2["unit_m"] = 100.0
    t_l2[pc.TASK_COL_SPEED] = 40.0
    t_l2["base_time_per_unit"] = 2.5

    res = pc._assign_one_roll_trial_order_flow(
        t_l2,
        day,
        daily_status,
        dict(avail_dt),
        {},
        [t_l2],
        skills_dict,
        members,
        req_map,
        [],
        {},
        {},
        day,
        start_dt,
        None,
        set(),
        team_combo_presets=presets,
    )
    assert res is not None
    assert t_l2.get("_special_l2_speed20_fallback") is True
    assert float(t_l2.get(pc.TASK_COL_SPEED)) == 20.0
    assert res["req_num"] == 2
    assert len(res["team"]) == 2
    assert res["combo_sheet_row_id"] == 201


