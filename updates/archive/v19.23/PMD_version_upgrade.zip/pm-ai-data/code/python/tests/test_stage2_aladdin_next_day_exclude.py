# -*- coding: utf-8 -*-
"""段階2: アラジン当日・翌日除外 JSON と dispatch_loop 消費の最小テスト。"""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path

import pandas as pd
import pytest

from planning_core import _core as pc
from planning_core.core.columns import ENV_STAGE2_ALADDIN_TODAY_EXCLUDE_NEXT_DAY_JSON
from planning_core.core.roll_pipeline import (
    append_plan_input_rows_missing_from_dispatch_table,
)


@pytest.fixture
def _clear_apply_date():
    prev = pc._STAGE2_ALADDIN_EXCLUDE_APPLY_DATE
    pc._STAGE2_ALADDIN_EXCLUDE_APPLY_DATE = None
    yield
    pc._STAGE2_ALADDIN_EXCLUDE_APPLY_DATE = prev


def test_load_stage2_aladdin_today_exclude_next_day_overrides(tmp_path: Path, monkeypatch):
    path = tmp_path / "aladdin-exclude.json"
    path.write_text(
        json.dumps(
            {
                "version": 1,
                "entries": [
                    {
                        "task_id": "T1",
                        "process": "スリット",
                        "machine_name": "M1",
                        "exclude_next_day_m": 3045,
                    }
                ],
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv(ENV_STAGE2_ALADDIN_TODAY_EXCLUDE_NEXT_DAY_JSON, str(path))

    out = pc._load_stage2_aladdin_today_exclude_next_day_overrides()
    key = pc._stage2_in_progress_next_day_dispatch_key("T1", "スリット", "M1")
    assert key in out
    assert out[key] == pytest.approx(3045.0)


def test_aladdin_next_day_exclude_consumes_roll_on_apply_date_only(_clear_apply_date):
    pc._STAGE2_ALADDIN_EXCLUDE_APPLY_DATE = date(2026, 6, 10)
    task = {
        "task_id": "T1",
        "aladdin_today_exclude_next_day_dialog": True,
        "aladdin_next_day_exclude_remaining_m": 6090.0,
        "unit_m": 3045.0,
        "remaining_units": 4.0,
    }

    assert not pc._stage2_aladdin_next_day_exclude_consumes_roll(task, date(2026, 6, 9))
    assert task["aladdin_next_day_exclude_remaining_m"] == pytest.approx(6090.0)
    assert task["remaining_units"] == pytest.approx(4.0)

    assert pc._stage2_aladdin_next_day_exclude_consumes_roll(task, date(2026, 6, 10))
    assert task["aladdin_next_day_exclude_remaining_m"] == pytest.approx(3045.0)
    assert task["remaining_units"] == pytest.approx(3.0)

    assert pc._stage2_aladdin_next_day_exclude_consumes_roll(task, date(2026, 6, 10))
    assert task["aladdin_next_day_exclude_remaining_m"] == pytest.approx(0.0)
    assert task["remaining_units"] == pytest.approx(2.0)

    assert not pc._stage2_aladdin_next_day_exclude_consumes_roll(task, date(2026, 6, 10))
    assert task["remaining_units"] == pytest.approx(2.0)


def test_append_plan_missing_skips_stub_when_aladdin_exclude_covers_remaining(
    tmp_path: Path, monkeypatch
):
    """翌日配台0ロール（exclude=残量全量）のとき結果_配台表へ数量0スタブを載せない。"""
    path = tmp_path / "aladdin-exclude.json"
    path.write_text(
        json.dumps(
            {
                "version": 1,
                "entries": [
                    {
                        "task_id": "V9-1",
                        "process": "接続",
                        "machine_name": "熱融着機　湖南",
                        "exclude_next_day_m": 1000.0,
                    }
                ],
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv(ENV_STAGE2_ALADDIN_TODAY_EXCLUDE_NEXT_DAY_JSON, str(path))

    tasks_df = pd.DataFrame(
        [
            {
                "依頼NO": "V9-1",
                "工程名": "接続",
                "機械名": "熱融着機　湖南",
                "換算数量": 1000,
                "実加工数": 0,
                "未加工": 1000,
                "配台使用残数量": 1000,
            }
        ]
    )
    out = append_plan_input_rows_missing_from_dispatch_table(
        pd.DataFrame(), tasks_df, None
    )
    assert out is None or getattr(out, "empty", True)


def test_append_plan_missing_keeps_stub_when_aladdin_exclude_partial(
    tmp_path: Path, monkeypatch
):
    path = tmp_path / "aladdin-exclude-partial.json"
    path.write_text(
        json.dumps(
            {
                "version": 1,
                "entries": [
                    {
                        "task_id": "V9-1",
                        "process": "接続",
                        "machine_name": "熱融着機　湖南",
                        "exclude_next_day_m": 200.0,
                    }
                ],
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv(ENV_STAGE2_ALADDIN_TODAY_EXCLUDE_NEXT_DAY_JSON, str(path))

    tasks_df = pd.DataFrame(
        [
            {
                "依頼NO": "V9-1",
                "工程名": "接続",
                "機械名": "熱融着機　湖南",
                "換算数量": 1000,
                "実加工数": 0,
                "未加工": 1000,
                "配台使用残数量": 1000,
            }
        ]
    )
    out = append_plan_input_rows_missing_from_dispatch_table(
        pd.DataFrame(), tasks_df, None
    )
    assert out is not None and not out.empty
    assert len(out) == 1
    assert float(out.iloc[0]["当日配台数量"]) == pytest.approx(0.0)


def _setup_trial_order_pass_env(monkeypatch, day: date):
    monkeypatch.setattr(pc, "_STAGE2_ALADDIN_EXCLUDE_APPLY_DATE", day)
    monkeypatch.setattr(pc, "STAGE2_GLOBAL_DISPATCH_TRIAL_ORDER_STRICT", True)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_MAY_EXCEED_NEED", False)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_COMBO_SHEET_RESTRICT_TO_PRESET_MEMBERS", False)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_HEADCOUNT_FROM_NEED_ONLY", True)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_USE_NEED_SURPLUS_IN_MAIN_PASS", False)
    monkeypatch.setattr(pc, "TEAM_ASSIGN_IGNORE_NEED_SURPLUS_ROW", False)
    monkeypatch.setattr(pc, "_MACHINE_CALENDAR_BLOCKS_BY_DATE", {})
    monkeypatch.setattr(pc, "_STAGE2_REQUEST_SWITCH_PREP_BY_PROC_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_REQUEST_SWITCH_PREP_BY_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_BREAK_RESUME_PREP_BY_PROC_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_BREAK_RESUME_PREP_BY_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_POST_MACHINING_CLEANUP_BY_PROC_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_POST_MACHINING_CLEANUP_BY_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_REQUEST_INTERVAL_BUFFER_BY_PROC_MACHINE", {})
    monkeypatch.setattr(pc, "_STAGE2_REQUEST_INTERVAL_BUFFER_BY_MACHINE", {})
    monkeypatch.setattr(pc, "_MH_HANDOFF_TIMELINE_CACHE_KEY", None)
    monkeypatch.setattr(pc, "_MH_HANDOFF_TIMELINE_CACHE_STATE", None)

    start_dt = datetime.combine(day, datetime.strptime("08:45", "%H:%M").time())
    end_dt = datetime.combine(day, datetime.strptime("17:00", "%H:%M").time())
    breaks_dt = [
        (
            datetime.combine(day, datetime.strptime("12:00", "%H:%M").time()),
            datetime.combine(day, datetime.strptime("12:50", "%H:%M").time()),
        ),
        (
            datetime.combine(day, datetime.strptime("14:45", "%H:%M").time()),
            datetime.combine(day, datetime.strptime("15:00", "%H:%M").time()),
        ),
    ]
    members = ["宮島　　剛", "竹内　正美", "冨田　裕子", "図司　智子"]
    daily_status = {
        m: {
            "start_dt": start_dt,
            "end_dt": end_dt,
            "breaks_dt": list(breaks_dt),
            "efficiency": 1.0,
            "is_working": True,
            "eligible_for_assignment": True,
        }
        for m in members
    }
    skills_dict = {
        "宮島　　剛": {"EC+EC機　湖南": "OP1"},
        "竹内　正美": {"EC+EC機　湖南": "OP2"},
        "冨田　裕子": {"エンボス+エンボス　湖南": "OP1"},
        "図司　智子": {"エンボス+エンボス　湖南": "OP2"},
    }
    req_map = {
        "EC+EC機 湖南": 2,
        "エンボス+エンボス 湖南": 2,
    }
    surplus_map = {
        "EC+EC機 湖南": 0,
        "エンボス+エンボス 湖南": 0,
    }
    return {
        "day": day,
        "start_dt": start_dt,
        "members": members,
        "daily_status": daily_status,
        "avail_dt": {m: start_dt for m in members},
        "machine_avail_dt": {},
        "skills_dict": skills_dict,
        "req_map": req_map,
        "need_rules": [],
        "surplus_map": surplus_map,
        "timeline_events": [],
    }


def _make_pass_task(
    task_id: str,
    dto: int,
    proc: str,
    mach: str,
    *,
    day: date,
    due: date,
    unit_m: float,
    rolls: float,
    base_time_per_unit: float,
    exclude_m: float = 0.0,
) -> dict:
    return {
        "task_id": task_id,
        "rule_task_id": task_id,
        "dispatch_trial_order": dto,
        "machine": proc,
        "machine_name": mach,
        "equipment_line_key": f"{proc}+{mach}",
        "unit_m": unit_m,
        "total_qty_m": unit_m * rolls,
        "remaining_units": rolls,
        "initial_remaining_units": rolls,
        "base_time_per_unit": base_time_per_unit,
        "start_date_req": day,
        "due_basis_date": due,
        "assigned_history": [],
        "same_request_line_seq": 0,
        "aladdin_today_exclude_next_day_dialog": exclude_m > 1e-12,
        "aladdin_today_exclude_next_day_m": exclude_m,
        "aladdin_next_day_exclude_remaining_m": exclude_m,
    }


def _run_day_passes(env: dict, task_queue: list, *, max_passes: int = 20) -> list[bool]:
    day = env["day"]
    macro_run_date = date(day.year, day.month, day.day - 1)
    macro_now_dt = datetime.combine(
        macro_run_date, datetime.strptime("16:00", "%H:%M").time()
    )
    need_logged: set = set()
    outcomes: list[bool] = []
    for _ in range(max_passes):
        made = pc._trial_order_first_schedule_pass(
            day,
            task_queue,
            task_queue,
            env["daily_status"],
            env["machine_avail_dt"],
            env["avail_dt"],
            env["timeline_events"],
            env["skills_dict"],
            env["members"],
            env["req_map"],
            env["need_rules"],
            env["surplus_map"],
            {},
            macro_run_date,
            macro_now_dt,
            need_logged,
        )
        outcomes.append(made)
        if not made:
            break
    return outcomes


def test_full_aladdin_exclude_task_does_not_abort_same_day_later_orders(monkeypatch):
    """全量翌日除外タスク(ord=5)の消化で進捗Trueを返し、同日午後の後続(ord=7)が配台される。"""
    day = date(2026, 11, 26)
    due = date(2026, 11, 30)
    env = _setup_trial_order_pass_env(monkeypatch, day)

    t_e11 = _make_pass_task(
        "E11-3", 2, "EC", "EC機　湖南",
        day=day, due=due, unit_m=300.0, rolls=15.0, base_time_per_unit=300.0 / 22.0,
    )
    t_excl = _make_pass_task(
        "T11-5", 5, "エンボス", "エンボス　湖南",
        day=day, due=due, unit_m=400.0, rolls=2.0, base_time_per_unit=40.0,
        exclude_m=800.0,
    )
    t_next = _make_pass_task(
        "W11-20", 7, "EC", "EC機　湖南",
        day=day, due=due, unit_m=300.0, rolls=5.0, base_time_per_unit=300.0 / 22.0,
    )
    queue = [t_e11, t_excl, t_next]

    outcomes = _run_day_passes(env, queue)

    # Pass 1: E11-3 (True), Pass 2: T11-5 全量除外 (True), Pass 3: W11-20 (True), Pass 4: 残なし (False)
    assert outcomes == [True, True, True, False]
    assert t_e11["remaining_units"] == pytest.approx(0.0)
    assert t_excl["remaining_units"] == pytest.approx(0.0)
    assert t_excl["aladdin_next_day_exclude_remaining_m"] == pytest.approx(0.0)
    assert t_next["remaining_units"] == pytest.approx(0.0)

    excl_events = [e for e in env["timeline_events"] if e.get("task_id") == "T11-5"]
    next_events = [e for e in env["timeline_events"] if e.get("task_id") == "W11-20"]
    assert excl_events == []
    assert len(next_events) == 5
    assert all(e["date"] == day for e in next_events)


def test_partial_aladdin_exclude_schedules_remaining_rolls_and_terminates(monkeypatch):
    """部分除外(2R中1R除外)で残り1Rが同日配台され、無限ループせず終了する。"""
    day = date(2026, 11, 26)
    due = date(2026, 11, 30)
    env = _setup_trial_order_pass_env(monkeypatch, day)

    t_partial = _make_pass_task(
        "T11-5", 1, "エンボス", "エンボス　湖南",
        day=day, due=due, unit_m=400.0, rolls=2.0, base_time_per_unit=40.0,
        exclude_m=400.0,
    )
    outcomes = _run_day_passes(env, [t_partial])

    assert outcomes == [True, False]
    assert t_partial["aladdin_next_day_exclude_remaining_m"] == pytest.approx(0.0)
    assert t_partial["remaining_units"] == pytest.approx(0.0)
    evs = [e for e in env["timeline_events"] if e.get("task_id") == "T11-5"]
    assert len(evs) == 1


def test_partial_aladdin_exclude_with_unplaceable_remainder_does_not_loop(monkeypatch):
    """部分除外後に残ロールが当日割付不可でも、次パスへ進んで False 収束し無限ループしない。"""
    day = date(2026, 11, 26)
    due = date(2026, 11, 30)
    env = _setup_trial_order_pass_env(monkeypatch, day)

    t_partial = _make_pass_task(
        "T11-5", 1, "エンボス", "エンボス　湖南",
        day=day, due=due, unit_m=400.0, rolls=2.0, base_time_per_unit=40.0,
        exclude_m=400.0,
    )
    t_after = _make_pass_task(
        "W11-20", 2, "EC", "EC機　湖南",
        day=day, due=due, unit_m=300.0, rolls=1.0, base_time_per_unit=300.0 / 22.0,
    )
    orig_assign = pc._assign_one_roll_trial_order_flow

    def _assign_block_after_exclude(task, *args, **kwargs):
        if (
            task.get("task_id") == "T11-5"
            and float(task.get("aladdin_next_day_exclude_remaining_m") or 0.0) <= 1e-12
        ):
            return None
        return orig_assign(task, *args, **kwargs)

    monkeypatch.setattr(pc, "_assign_one_roll_trial_order_flow", _assign_block_after_exclude)

    outcomes = _run_day_passes(env, [t_partial, t_after], max_passes=10)

    # Pass 1: T11-5 が1R除外(rem 2→1, exclude 400→0)し残1Rは割付不可 → True
    # Pass 2: T11-5 はプローブ失敗でスキップされ W11-20(ord=2) が配台 → True
    # Pass 3: W11-20 完了、T11-5 は除外残0かつ割付不可 → False（無限ループしない）
    assert outcomes == [True, True, False]
    assert t_partial["aladdin_next_day_exclude_remaining_m"] == pytest.approx(0.0)
    assert t_partial["remaining_units"] == pytest.approx(1.0)
    assert t_after["remaining_units"] == pytest.approx(0.0)
