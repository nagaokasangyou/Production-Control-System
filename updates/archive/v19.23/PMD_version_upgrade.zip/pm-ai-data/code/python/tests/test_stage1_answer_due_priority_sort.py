# -*- coding: utf-8 -*-
"""段階1: 回答納期ありを優先し、回答納期なしをその後ろに並べるソート仕様の単体テスト。"""

from __future__ import annotations

from datetime import date, datetime

import pandas as pd
import pytest

from planning_core import _core as pc


def _task(
    tid: str,
    *,
    in_progress: bool = False,
    answer_due: date | None = None,
    specified_due: date | None = None,
    machine: str = "スリット",
    machine_name: str = "スリット機1　湖南",
    roll_pipeline_ec: bool = False,
    roll_pipeline_inspection: bool = False,
    roll_pipeline_rewind: bool = False,
    dto_from_sheet: float | None = None,
    row_seq: int = 0,
) -> dict:
    if answer_due is not None:
        due_basis = answer_due
        due_source = "answer_due"
        due_source_rank = 0
    elif specified_due is not None:
        due_basis = specified_due
        due_source = "specified_due"
        due_source_rank = 1
    else:
        due_basis = None
        due_source = "none"
        due_source_rank = 9
    return {
        "task_id": tid,
        "machine": machine,
        "machine_name": machine_name,
        "in_progress": in_progress,
        "answer_due_date": answer_due,
        "specified_due_date": specified_due,
        "due_basis_date": due_basis,
        "due_source": due_source,
        "due_source_rank": due_source_rank,
        "roll_pipeline_ec": roll_pipeline_ec,
        "roll_pipeline_inspection": roll_pipeline_inspection,
        "roll_pipeline_rewind": roll_pipeline_rewind,
        "dispatch_trial_order_from_sheet": dto_from_sheet,
        "planning_sheet_row_seq": row_seq,
        "same_request_line_seq": 0,
        "process_sequence_rank": None,
        "process_content_tokens": [],
    }


@pytest.mark.parametrize(
    "raw",
    [
        None,
        float("nan"),
        pd.NaT,
        "",
        "   ",
        "nan",
        "None",
        "null",
        "NaT",
        "nat",
        "-",
        "―",
        "未定",
        "確認中",
        0,
        0.0,
        46301,
        -1,
        True,
        False,
    ],
)
def test_parse_optional_date_rejects_blank_invalid_nat_and_numeric_values(raw):
    assert pc.parse_optional_date(raw) is None


def test_parse_optional_date_accepts_valid_date_representations():
    expected = date(2026, 5, 20)
    assert pc.parse_optional_date(date(2026, 5, 20)) == expected
    assert pc.parse_optional_date(datetime(2026, 5, 20, 14, 30)) == expected
    assert pc.parse_optional_date(pd.Timestamp("2026-05-20 00:00:00")) == expected
    assert pc.parse_optional_date("2026/05/20") == expected
    assert pc.parse_optional_date("2026-05-20") == expected
    assert pc.parse_optional_date("2026/5/20") == expected


def test_sort_key_places_answered_due_before_unanswered_even_if_specified_due_earlier():
    tasks = [
        _task("SPEC-EARLY", specified_due=date(2026, 5, 10)),
        _task("NONE-DUE"),
        _task("ANS-LATE", answer_due=date(2026, 5, 25), specified_due=date(2026, 5, 25)),
        _task("ANS-EARLY", answer_due=date(2026, 5, 18), specified_due=date(2026, 5, 18)),
        _task("SPEC-LATE", specified_due=date(2026, 5, 15)),
    ]
    ordered = sorted(
        tasks,
        key=lambda t: pc._generate_plan_task_queue_sort_key(t, {}, [], {}),
    )
    assert [t["task_id"] for t in ordered] == [
        "ANS-EARLY",
        "ANS-LATE",
        "SPEC-EARLY",
        "SPEC-LATE",
        "NONE-DUE",
    ]


def test_sort_key_same_due_date_prioritizes_answered_over_unanswered():
    same_day = date(2026, 5, 20)
    tasks = [
        _task("A-1", specified_due=same_day),
        _task("A-9", answer_due=same_day, specified_due=same_day),
    ]
    ordered = sorted(
        tasks,
        key=lambda t: pc._generate_plan_task_queue_sort_key(t, {}, [], {}),
    )
    assert [t["task_id"] for t in ordered] == ["A-9", "A-1"]


def test_sort_key_keeps_in_progress_highest_then_answered_due_then_tiebreakers():
    need_idx = {"スリット+スリット機1　湖南": 1, "SEC+SEC機　湖南": 2}
    tasks = [
        _task("UNSTARTED-ANS", answer_due=date(2026, 5, 10)),
        _task("IP-NO-ANS", in_progress=True, specified_due=date(2026, 5, 30)),
        _task("IP-ANS", in_progress=True, answer_due=date(2026, 5, 28)),
        _task(
            "ANS-TIE-2",
            answer_due=date(2026, 5, 20),
            machine="SEC",
            machine_name="SEC機　湖南",
        ),
        _task("ANS-TIE-10", answer_due=date(2026, 5, 20)),
        _task("ANS-TIE-2B", answer_due=date(2026, 5, 20)),
    ]
    ordered = sorted(
        tasks,
        key=lambda t: pc._generate_plan_task_queue_sort_key(t, {}, [], need_idx),
    )
    assert [t["task_id"] for t in ordered] == [
        "IP-ANS",
        "IP-NO-ANS",
        "UNSTARTED-ANS",
        "ANS-TIE-10",
        "ANS-TIE-2B",
        "ANS-TIE-2",
    ]


def test_day_schedule_task_sort_key_parity_with_queue_sort_key():
    tasks = [
        _task("SPEC-EARLY", specified_due=date(2026, 5, 10), row_seq=0),
        _task("ANS-LATE", answer_due=date(2026, 5, 25), row_seq=1),
        _task("IP-UNANS", in_progress=True, specified_due=date(2026, 5, 30), row_seq=2),
        _task("NO-DUE", row_seq=3),
    ]
    ordered = sorted(
        tasks,
        key=lambda t: pc._day_schedule_task_sort_key(t, tasks, {}),
    )
    assert [t["task_id"] for t in ordered] == [
        "IP-UNANS",
        "ANS-LATE",
        "SPEC-EARLY",
        "NO-DUE",
    ]


def test_stage1_fill_trial_order_and_sort_df_end_to_end(monkeypatch):
    monkeypatch.setattr(pc, "load_main_sheet_global_priority_override_text", lambda: "")
    monkeypatch.setattr(
        pc,
        "analyze_global_priority_override_comment",
        lambda raw, members, year, ai_sheet_sink=None: {},
    )
    monkeypatch.setattr(
        pc,
        "analyze_task_special_remarks",
        lambda df, reference_year=None, ai_sheet_sink=None: {},
    )
    monkeypatch.setattr(pc, "_load_stage2_in_progress_next_day_dispatch_overrides", lambda: {})
    monkeypatch.setattr(pc, "_load_stage2_aladdin_today_exclude_next_day_overrides", lambda: {})

    def _plan_row(
        tid: str,
        proc: str,
        mach: str,
        *,
        ans="",
        spec="",
        actual: float = 0.0,
        exclude: str = "",
        process_content: str = "",
    ) -> dict:
        return {
            pc.RESULT_TASK_COL_DISPATCH_TRIAL_ORDER: "",
            pc.PLAN_COL_EXCLUDE_FROM_ASSIGNMENT: exclude,
            pc.TASK_COL_TASK_ID: tid,
            pc.TASK_COL_MACHINE: proc,
            pc.TASK_COL_MACHINE_NAME: mach,
            pc.TASK_COL_QTY: 1000.0,
            pc.TASK_COL_UNPROCESSED: max(0.0, 1000.0 - actual),
            pc.TASK_COL_ACTUAL_DONE: actual,
            pc.TASK_COL_SPEED: 10.0,
            pc.TASK_COL_PRODUCT: "TEST 1000x500",
            pc.PLAN_COL_ROLL_UNIT_LENGTH: 500.0,
            pc.PLAN_COL_RAW_ROLL_UNIT_LENGTH: 500.0,
            pc.TASK_COL_ANSWER_DUE: ans,
            pc.TASK_COL_SPECIFIED_DUE: spec,
            pc.TASK_COL_RAW_INPUT_DATE: "",
            pc.TASK_COL_STOCK_LOCATION: "",
            pc.TASK_COL_PROCESS_CONTENT: process_content or proc,
            pc.TASK_COL_COMPLETION_FLAG: "0:未完",
            pc.PLAN_COL_SPECIAL_REMARK: "",
            pc.PLAN_COL_LIMITED_OP: "",
        }

    df = pd.DataFrame(
        [
            # Unanswered with earlier specified_due + numeric 0 / placeholder values
            _plan_row("U-1", "スリット", "スリット機1　湖南", ans="", spec="2026/05/05"),
            _plan_row("U-ZERO", "スリット", "スリット機1　湖南", ans=0, spec="2026/05/06"),
            _plan_row("U-TBD", "スリット", "スリット機1　湖南", ans="未定", spec="2026/05/07"),
            _plan_row("U-NONE", "スリット", "スリット機1　湖南", ans="", spec=""),
            # Excluded row should stay blank and sort to bottom
            _plan_row("EX-1", "スリット", "スリット機1　湖南", ans="2026/05/01", spec="2026/05/01", exclude="yes"),
            # Answered-due multi-process order (later due date than U-1, must still beat U-1)
            _plan_row(
                "A-MULTI",
                "検査",
                "熱融着機　湖南",
                ans="2026/05/20",
                spec="2026/05/20",
                process_content="スリット,検査",
            ),
            _plan_row(
                "A-MULTI",
                "スリット",
                "スリット機1　湖南",
                ans="2026/05/20",
                spec="2026/05/20",
                process_content="スリット,検査",
            ),
            # Answered-due single row (earliest among answered)
            _plan_row("A-1", "スリット", "スリット機1　湖南", ans="2026/05/18", spec="2026/05/18"),
            # In-progress row without answer_due stays #1 (1 roll completed = 500m of 1000m)
            _plan_row("IP-1", "スリット", "スリット機1　湖南", ans="", spec="2026/05/30", actual=500.0),
        ]
    )
    # stage1.py:440-442 と同じ object dtype（pandas 3.x の StringDtype では int 代入が TypeError になる）
    df[pc.RESULT_TASK_COL_DISPATCH_TRIAL_ORDER] = df[
        pc.RESULT_TASK_COL_DISPATCH_TRIAL_ORDER
    ].astype(object)

    pc.fill_plan_dispatch_trial_order_column_stage1(
        df,
        date(2026, 5, 1),
        {},
        [],
        {"スリット+スリット機1　湖南": 0, "検査+熱融着機　湖南": 1},
        ["スリット+スリット機1　湖南", "検査+熱融着機　湖南"],
        members_for_gpo=[],
    )
    sorted_df = pc._sort_stage1_plan_df_by_dispatch_trial_order_asc(df)

    got_pairs = list(
        zip(
            sorted_df[pc.TASK_COL_TASK_ID].tolist(),
            sorted_df[pc.TASK_COL_MACHINE].tolist(),
            sorted_df[pc.RESULT_TASK_COL_DISPATCH_TRIAL_ORDER].tolist(),
        )
    )
    assert got_pairs == [
        ("IP-1", "スリット", 1),
        ("A-1", "スリット", 2),
        ("A-MULTI", "スリット", 3),
        ("A-MULTI", "検査", 4),
        ("U-1", "スリット", 5),
        ("U-ZERO", "スリット", 6),
        ("U-TBD", "スリット", 7),
        ("U-NONE", "スリット", 8),
        ("EX-1", "スリット", ""),
    ]


def test_stage2_apply_dispatch_trial_order_preserves_sheet_order_and_uses_answer_due_fallback():
    # Path 1: All rows carry Stage 1 dispatch_trial_order_from_sheet -> preserved verbatim
    q_sheet = [
        _task("LATER-DTO", answer_due=date(2026, 5, 10), dto_from_sheet=2.0, row_seq=1),
        _task("EARLIER-DTO", specified_due=date(2026, 5, 30), dto_from_sheet=1.0, row_seq=0),
    ]
    pc._apply_dispatch_trial_order_for_generate_plan(q_sheet, {}, [], {})
    assert [(t["task_id"], t["dispatch_trial_order"]) for t in q_sheet] == [
        ("EARLIER-DTO", 1.0),
        ("LATER-DTO", 2.0),
    ]

    # Path 2: Missing dispatch_trial_order -> Stage 2 fallback also prioritizes 回答納期あり
    q_fallback = [
        _task("UNANS-EARLY", specified_due=date(2026, 5, 10), dto_from_sheet=None, row_seq=0),
        _task("ANS-LATE", answer_due=date(2026, 5, 25), dto_from_sheet=None, row_seq=1),
    ]
    pc._apply_dispatch_trial_order_for_generate_plan(q_fallback, {}, [], {})
    assert [(t["task_id"], t["dispatch_trial_order"]) for t in q_fallback] == [
        ("ANS-LATE", 1),
        ("UNANS-EARLY", 2),
    ]
