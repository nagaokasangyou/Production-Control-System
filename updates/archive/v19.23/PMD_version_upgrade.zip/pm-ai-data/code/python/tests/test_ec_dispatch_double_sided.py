# -*- coding: utf-8 -*-
"""両面EC の配台時間倍化（task_queue）。"""

from __future__ import annotations

from datetime import date

import pandas as pd

from planning_core import _core as pc
from planning_core.core.ec_side_classification import EC_SIDE_CLASS_DOUBLE, EC_SIDE_CLASS_SINGLE


def _minimal_ec_plan_row(*, ec_side: str) -> dict:
    return {
        pc.TASK_COL_TASK_ID: "W1-1",
        pc.TASK_COL_MACHINE: "EC",
        pc.TASK_COL_MACHINE_NAME: "EC機　湖南",
        pc.TASK_COL_QTY: 1000,
        pc.TASK_COL_UNPROCESSED: 1000,
        pc.TASK_COL_SPEED: 10,
        pc.PLAN_COL_RAW_ROLL_UNIT_LENGTH: 100,
        pc.PLAN_COL_EC_SIDE_CLASS: ec_side,
        pc.TASK_COL_ANSWER_DUE: "2026-08-20",
    }


def test_build_task_queue_double_sided_ec_doubles_base_time_per_unit(monkeypatch):
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    tasks = pd.DataFrame([_minimal_ec_plan_row(ec_side=EC_SIDE_CLASS_DOUBLE)])
    queue = pc.build_task_queue_from_planning_df(
        tasks,
        date(2026, 8, 17),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 2
    assert task["base_time_per_unit"] == 20.0


def test_build_task_queue_kokubu_double_sided_ec_keeps_base_time_per_unit(monkeypatch):
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KOKUBU")
    tasks = pd.DataFrame([_minimal_ec_plan_row(ec_side=EC_SIDE_CLASS_DOUBLE)])
    queue = pc.build_task_queue_from_planning_df(
        tasks,
        date(2026, 8, 17),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 1
    assert task["base_time_per_unit"] == 10.0


def test_build_task_queue_single_sided_ec_keeps_base_time_per_unit():
    tasks = pd.DataFrame([_minimal_ec_plan_row(ec_side=EC_SIDE_CLASS_SINGLE)])
    queue = pc.build_task_queue_from_planning_df(
        tasks,
        date(2026, 8, 17),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 1
    assert task["base_time_per_unit"] == 10.0


def test_build_task_queue_double_sided_sec_keeps_base_time_per_unit():
    row = _minimal_ec_plan_row(ec_side=EC_SIDE_CLASS_DOUBLE)
    row[pc.TASK_COL_MACHINE] = "SEC"
    row[pc.TASK_COL_MACHINE_NAME] = "SEC機　湖南"
    tasks = pd.DataFrame([row])
    queue = pc.build_task_queue_from_planning_df(
        tasks,
        date(2026, 8, 17),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 1
    assert task["base_time_per_unit"] == 10.0


def test_build_task_queue_double_sided_ec_skips_doubling_when_converted_qty_already_doubled(
    monkeypatch,
):
    """E11-2 相当: 受注数3900m に対しアラジン換算数量が既に2倍(7800m)なら二重倍化しない。"""
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    row = {
        pc.TASK_COL_TASK_ID: "E11-2",
        pc.TASK_COL_MACHINE: "EC",
        pc.TASK_COL_MACHINE_NAME: "EC機　湖南",
        pc.TASK_COL_ORDER_QTY: 3900,
        pc.TASK_COL_QTY: 7800,
        pc.TASK_COL_UNPROCESSED: 0,
        pc.TASK_COL_SPEED: 20.0,
        pc.PLAN_COL_RAW_ROLL_UNIT_LENGTH: 300,
        pc.PLAN_COL_EC_SIDE_CLASS: EC_SIDE_CLASS_DOUBLE,
        pc.TASK_COL_ANSWER_DUE: "2026-11-27",
    }
    queue = pc.build_task_queue_from_planning_df(
        pd.DataFrame([row]),
        date(2026, 11, 25),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 1
    assert task["remaining_units"] == 26.0
    assert task["base_time_per_unit"] == 15.0


def test_build_task_queue_double_sided_ec_in_progress_already_doubled_converted_qty(
    monkeypatch,
):
    """加工途中で残量が3900mに減っていても、換算数量7800/受注数3900=2倍なので二重倍化しない。"""
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    row = {
        pc.TASK_COL_TASK_ID: "E11-2",
        pc.TASK_COL_MACHINE: "EC",
        pc.TASK_COL_MACHINE_NAME: "EC機　湖南",
        pc.TASK_COL_ORDER_QTY: 3900,
        pc.TASK_COL_QTY: 7800,
        pc.TASK_COL_ACTUAL_DONE: 3900,
        pc.TASK_COL_UNPROCESSED: 3900,
        pc.TASK_COL_SPEED: 20.0,
        pc.PLAN_COL_RAW_ROLL_UNIT_LENGTH: 300,
        pc.PLAN_COL_EC_SIDE_CLASS: EC_SIDE_CLASS_DOUBLE,
        pc.TASK_COL_ANSWER_DUE: "2026-11-27",
    }
    queue = pc.build_task_queue_from_planning_df(
        pd.DataFrame([row]),
        date(2026, 11, 25),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 1
    assert task["remaining_units"] == 13.0
    assert task["base_time_per_unit"] == 15.0


def test_build_task_queue_double_sided_ec_still_doubles_when_converted_qty_equals_order_qty(
    monkeypatch,
):
    """換算数量が受注数と同値(1倍)の両面ECは従来どおり2パス分として倍化する。"""
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    row = {
        pc.TASK_COL_TASK_ID: "E11-UNCONV",
        pc.TASK_COL_MACHINE: "EC",
        pc.TASK_COL_MACHINE_NAME: "EC機　湖南",
        pc.TASK_COL_ORDER_QTY: 3900,
        pc.TASK_COL_QTY: 3900,
        pc.TASK_COL_UNPROCESSED: 0,
        pc.TASK_COL_SPEED: 20.0,
        pc.PLAN_COL_RAW_ROLL_UNIT_LENGTH: 300,
        pc.PLAN_COL_EC_SIDE_CLASS: EC_SIDE_CLASS_DOUBLE,
        pc.TASK_COL_ANSWER_DUE: "2026-11-27",
    }
    queue = pc.build_task_queue_from_planning_df(
        pd.DataFrame([row]),
        date(2026, 11, 25),
        {},
        ai_by_tid={},
        equipment_list=[],
    )
    assert len(queue) == 1
    task = queue[0]
    assert task["ec_dispatch_pass_count"] == 2
    assert task["remaining_units"] == 13.0
    assert task["base_time_per_unit"] == 30.0
