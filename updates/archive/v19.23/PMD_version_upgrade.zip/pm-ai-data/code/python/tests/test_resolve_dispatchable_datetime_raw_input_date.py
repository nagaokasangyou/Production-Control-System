"""resolve_dispatchable_datetime_from_plan_row: 原反投入日が暦日の正。"""

from __future__ import annotations

from datetime import date, datetime, time

import pandas as pd

from planning_core.core.columns import (
    PLAN_COL_DISPATCHABLE_DATETIME,
    TASK_COL_MACHINE,
    TASK_COL_MACHINE_NAME,
    TASK_COL_PRODUCT,
    TASK_COL_QTY,
    TASK_COL_RAW_INPUT_DATE,
    TASK_COL_SPEED,
    TASK_COL_STOCK_LOCATION,
    TASK_COL_TASK_ID,
    TASK_COL_UNPROCESSED,
)
from planning_core.core.dispatch_loop import _trial_order_flow_day_start_floor
from planning_core.core.gantt_excel import (
    compute_dispatchable_datetime,
    resolve_dispatchable_datetime_from_plan_row,
)
from planning_core.core.stage1 import DEFAULT_START_TIME
from planning_core.core.task_queue import build_task_queue_from_planning_df


def test_resolve_prefers_raw_input_date_when_dispatchable_column_is_stale_later():
    """W9-4 相当: 原反投入日を 9/7 にしても列が 9/9 12:45 のままなら 9/7 起算。"""
    row = {
        TASK_COL_RAW_INPUT_DATE: "2026/9/7",
        PLAN_COL_DISPATCHABLE_DATETIME: "2026/9/9 12:45",
        TASK_COL_STOCK_LOCATION: "K",
    }
    got = resolve_dispatchable_datetime_from_plan_row(row, run_date=date(2026, 9, 1))
    assert got == datetime(2026, 9, 7, 8, 45)


def test_resolve_stock_k_uses_845_even_when_column_still_1245(monkeypatch):
    """湖南工場・在庫場所K: 列が 12:45 でも配台可能は当日 8:45。"""
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    row = {
        TASK_COL_RAW_INPUT_DATE: "2026/9/7",
        PLAN_COL_DISPATCHABLE_DATETIME: "2026/9/7 12:45",
        TASK_COL_STOCK_LOCATION: "K",
    }
    got = resolve_dispatchable_datetime_from_plan_row(row, run_date=date(2026, 9, 1))
    assert got == datetime(2026, 9, 7, 8, 45)


def test_resolve_computed_time_for_konan_local_stock(monkeypatch):
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    row = {
        TASK_COL_RAW_INPUT_DATE: "2026/9/7",
        PLAN_COL_DISPATCHABLE_DATETIME: "2026/9/7 9:30",
        TASK_COL_STOCK_LOCATION: "湖南",
    }
    got = resolve_dispatchable_datetime_from_plan_row(row, run_date=date(2026, 9, 1))
    assert got == datetime(2026, 9, 7, 8, 45)


def test_resolve_column_only_when_no_raw_input_date():
    row = {
        TASK_COL_RAW_INPUT_DATE: "",
        PLAN_COL_DISPATCHABLE_DATETIME: "2026/9/9 12:45",
    }
    got = resolve_dispatchable_datetime_from_plan_row(row, run_date=date(2026, 9, 1))
    assert got == datetime(2026, 9, 9, 12, 45)


def test_resolve_enforces_raw_floor_when_column_earlier_than_raw():
    row = {
        TASK_COL_RAW_INPUT_DATE: "2026/9/9",
        PLAN_COL_DISPATCHABLE_DATETIME: "2026/9/7 12:45",
    }
    got = resolve_dispatchable_datetime_from_plan_row(row, run_date=date(2026, 9, 1))
    assert got == datetime(2026, 9, 9, 12, 45)


def test_past_raw_input_date_does_not_shift_1245_floor_to_run_date(monkeypatch):
    """E11-2 相当: 原反投入日(11/20)が計画開始日(11/25)より過去なら 11/25 に 12:45 下限を移さない。"""
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    raw_d = date(2026, 11, 20)
    run_d = date(2026, 11, 25)

    assert compute_dispatchable_datetime(
        raw_d, run_date=run_d, stock_location="S "
    ) == datetime(2026, 11, 20, 12, 45)

    row = {
        TASK_COL_RAW_INPUT_DATE: "2026/11/20",
        PLAN_COL_DISPATCHABLE_DATETIME: "2026/11/20 12:45",
        TASK_COL_STOCK_LOCATION: "S ",
    }
    assert resolve_dispatchable_datetime_from_plan_row(
        row, run_date=run_d
    ) == datetime(2026, 11, 20, 12, 45)


def test_build_task_queue_past_raw_input_date_starts_from_morning_on_run_date(monkeypatch):
    """原反投入日が計画開始日より過去なら same_day_raw_start_limit=None で朝から配台可能。
    原反投入日==計画開始日（および未来日）のみ同日 12:45 下限を維持する。"""
    monkeypatch.setenv("PM_AI_FACTORY_SITE", "KONAN")
    run_d = date(2026, 11, 25)
    df = pd.DataFrame(
        [
            {
                TASK_COL_TASK_ID: "E11-2",
                TASK_COL_MACHINE: "EC",
                TASK_COL_MACHINE_NAME: "EC機　湖南",
                TASK_COL_QTY: 7800,
                TASK_COL_UNPROCESSED: 0,
                TASK_COL_SPEED: 20.0,
                TASK_COL_PRODUCT: "15025-NR28-1440X300F-ABK0J",
                TASK_COL_RAW_INPUT_DATE: "2026/11/20",
                TASK_COL_STOCK_LOCATION: "S ",
                PLAN_COL_DISPATCHABLE_DATETIME: "2026/11/20 12:45",
            },
            {
                TASK_COL_TASK_ID: "SAME-DAY",
                TASK_COL_MACHINE: "EC",
                TASK_COL_MACHINE_NAME: "EC機　湖南",
                TASK_COL_QTY: 1800,
                TASK_COL_UNPROCESSED: 0,
                TASK_COL_SPEED: 20.0,
                TASK_COL_PRODUCT: "15020-JX5R-770X300F-A",
                TASK_COL_RAW_INPUT_DATE: "2026/11/25",
                TASK_COL_STOCK_LOCATION: "S ",
                PLAN_COL_DISPATCHABLE_DATETIME: "2026/11/25 12:45",
            },
            {
                TASK_COL_TASK_ID: "FUTURE-DAY",
                TASK_COL_MACHINE: "EC",
                TASK_COL_MACHINE_NAME: "EC機　湖南",
                TASK_COL_QTY: 1800,
                TASK_COL_UNPROCESSED: 0,
                TASK_COL_SPEED: 20.0,
                TASK_COL_PRODUCT: "15020-JX5R-770X300F-A",
                TASK_COL_RAW_INPUT_DATE: "2026/11/26",
                TASK_COL_STOCK_LOCATION: "S ",
                PLAN_COL_DISPATCHABLE_DATETIME: "2026/11/26 12:45",
            },
        ]
    )
    tq = build_task_queue_from_planning_df(
        df,
        run_date=run_d,
        req_map={"EC+EC機　湖南": 2},
        ai_by_tid={},
        global_priority_override={},
        equipment_list=["EC+EC機　湖南"],
    )
    by_tid = {t["task_id"]: t for t in tq}

    t_past = by_tid["E11-2"]
    assert t_past["start_date_req"] == run_d
    assert t_past["same_day_raw_start_limit"] is None
    assert _trial_order_flow_day_start_floor(
        t_past,
        run_d,
        date(2026, 11, 24),
        datetime(2026, 11, 24, 15, 46),
        tq,
    ) == datetime.combine(run_d, DEFAULT_START_TIME)

    t_same = by_tid["SAME-DAY"]
    assert t_same["start_date_req"] == run_d
    assert t_same["same_day_raw_start_limit"] == time(12, 45)
    assert _trial_order_flow_day_start_floor(
        t_same,
        run_d,
        date(2026, 11, 24),
        datetime(2026, 11, 24, 15, 46),
        tq,
    ) == datetime(2026, 11, 25, 12, 45)

    t_future = by_tid["FUTURE-DAY"]
    assert t_future["start_date_req"] == date(2026, 11, 26)
    assert t_future["same_day_raw_start_limit"] == time(12, 45)
    assert _trial_order_flow_day_start_floor(
        t_future,
        date(2026, 11, 26),
        date(2026, 11, 24),
        datetime(2026, 11, 24, 15, 46),
        tq,
    ) == datetime(2026, 11, 26, 12, 45)
    assert _trial_order_flow_day_start_floor(
        t_future,
        date(2026, 11, 27),
        date(2026, 11, 24),
        datetime(2026, 11, 24, 15, 46),
        tq,
    ) == datetime.combine(date(2026, 11, 27), DEFAULT_START_TIME)
