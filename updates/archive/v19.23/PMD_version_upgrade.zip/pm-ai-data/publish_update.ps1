# Differential Update Builder & Public GitHub Publisher for PMD
# Strictly excludes main application body (PMD.exe, Java runtime, Python runtime, 3rd-party JARs, source code)
# and deploys differential updates ONLY to the public GitHub repository (updates/).
# Deployment to internal factory shared folders (UNC) is NOT performed.

[CmdletBinding()]
param(
    [switch]$SkipVersionBump,
    [switch]$SkipMavenBuild,
    [switch]$SkipGitPush,
    [int]$KeepPreviousGenerations = 3,
    [string]$PublicRepoUrl = 'https://github.com/nagaokasangyou/Production-Control-System.git',
    [string]$Branch = 'main'
)

$ErrorActionPreference = 'Stop'

$WorkspaceRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$CodeJavaRoot = Join-Path $WorkspaceRoot 'code_java'
$ReleaseRoot = Join-Path $WorkspaceRoot 'pm-ai-package-release'
$PublicUpdatesDir = Join-Path $WorkspaceRoot 'updates'
$PublicArchiveDir = Join-Path $PublicUpdatesDir 'archive'
$ReleaseArchiveDir = Join-Path $ReleaseRoot 'archive'
$VersionTxtPath = Join-Path $WorkspaceRoot 'version.txt'
$RawDownloadBaseUrl = 'https://raw.githubusercontent.com/nagaokasangyou/Production-Control-System/main/updates'

. (Join-Path $CodeJavaRoot 'package_workspace_copy.ps1')
. (Join-Path $WorkspaceRoot 'scripts\pmd_release_archive.ps1')

New-Item -ItemType Directory -Path $PublicUpdatesDir -Force | Out-Null
New-Item -ItemType Directory -Path $PublicArchiveDir -Force | Out-Null
New-Item -ItemType Directory -Path $ReleaseRoot -Force | Out-Null

# 0. Preserve currently published local package into archive BEFORE bumping/overwriting,
#    and optionally sync remote archived generations so history is preserved across machines.
$preArchived = Save-PmdReleaseToArchive `
    -SourceDir $PublicUpdatesDir `
    -ArchiveRootDir $PublicArchiveDir `
    -MirrorArchiveRootDir $ReleaseArchiveDir `
    -DownloadBaseUrl $RawDownloadBaseUrl
if ($preArchived) {
    Write-Host "Preserved previous local update package in archive: v$preArchived" -ForegroundColor DarkCyan
}

$pubRepoCloneDir = Join-Path $WorkspaceRoot '.tmp\public_updates_repo'
if (-not $SkipGitPush) {
    [void](Sync-PmdArchiveFromRemoteRepo `
        -PublicRepoUrl $PublicRepoUrl `
        -Branch $Branch `
        -LocalUpdatesDir $PublicUpdatesDir `
        -LocalReleaseDir $ReleaseRoot `
        -CloneDir $pubRepoCloneDir)
}

function Write-VersionTxtUtf8NoBom {
    param([string]$SourcePath, [string]$DestPath)
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $content = [System.IO.File]::ReadAllText($SourcePath, $utf8).Trim() + "`n"
    [System.IO.File]::WriteAllText($DestPath, $content, $utf8)
}

if (-not $SkipVersionBump) {
    $bumpScript = Join-Path $WorkspaceRoot 'scripts\bump_version_txt.py'
    if (Test-Path -LiteralPath $bumpScript) {
        $before = (Get-Content -LiteralPath $VersionTxtPath -Raw -Encoding UTF8).Trim()
        & python $bumpScript $VersionTxtPath
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to bump version.txt"
        }
        $launcherVt = Join-Path $CodeJavaRoot 'src\main\resources\jp\co\pm\ai\desktop\rdp-launcher\PmAiRdpRemoteLauncher.version.txt'
        if (Test-Path -LiteralPath (Split-Path -Parent $launcherVt)) {
            Write-VersionTxtUtf8NoBom -SourcePath $VersionTxtPath -DestPath $launcherVt
        }
        $after = (Get-Content -LiteralPath $VersionTxtPath -Raw -Encoding UTF8).Trim()
        Write-Host "Bumped version.txt: $before -> $after" -ForegroundColor Cyan
    }
}

$verLine = (Get-Content -LiteralPath $VersionTxtPath -Raw -Encoding UTF8).Trim()
Write-Host "=== Building differential update package (version $verLine) ===" -ForegroundColor Cyan

if (-not $SkipMavenBuild) {
    Push-Location $CodeJavaRoot
    try {
        $mvnBin = 'C:\Users\0585\.m2\wrapper\dists\apache-maven-3.9.9\8e74001100ff70d6af083c5511fcc5ec49282d7017cde82c3698eee8fdf86698\bin\mvn.cmd'
        if (Test-Path -LiteralPath $mvnBin) {
            & $mvnBin package -DskipTests
        }
        else {
            cmd /c "mvnw.cmd package -DskipTests"
        }
        if ($LASTEXITCODE -ne 0) {
            throw "Maven package build failed (exit $LASTEXITCODE)"
        }
    }
    finally {
        Pop-Location
    }
}

$targetDir = Join-Path $CodeJavaRoot 'target'
$desktopJar = Get-ChildItem -LiteralPath $targetDir -Filter 'production-control-desktop-*.jar' -File |
    Where-Object { $_.Name -notmatch '-sources|-javadoc' } |
    Select-Object -First 1
if (-not $desktopJar) {
    throw "Main desktop JAR not found under $targetDir"
}

$stagingUpgrade = Join-Path $WorkspaceRoot '.tmp\PMD_version_upgrade_stage'
if (Test-Path -LiteralPath $stagingUpgrade) {
    Remove-Item -Recurse -Force -LiteralPath $stagingUpgrade
}
New-Item -ItemType Directory -Path $stagingUpgrade -Force | Out-Null

# 1. app/ (ONLY production-control-desktop JAR + PMD.cfg; no 3rd-party dependency JARs, no runtime, no PMD.exe)
$upgradeAppDir = Join-Path $stagingUpgrade 'app'
New-Item -ItemType Directory -Path $upgradeAppDir -Force | Out-Null
Copy-Item -LiteralPath $desktopJar.FullName -Destination (Join-Path $upgradeAppDir $desktopJar.Name) -Force

$existingCfg = Join-Path $ReleaseRoot 'PMD_initial_install\app\PMD.cfg'
if (Test-Path -LiteralPath $existingCfg) {
    Copy-Item -LiteralPath $existingCfg -Destination (Join-Path $upgradeAppDir 'PMD.cfg') -Force
}

# 2. pm-ai-data/ (differential workspace files; excludes runtime/python-embed, code_java, .tmp, master.xlsm, outputs)
$pmDataDir = Join-Path $stagingUpgrade 'pm-ai-data'
New-Item -ItemType Directory -Path $pmDataDir -Force | Out-Null
$mandatoryFile = Join-Path $CodeJavaRoot 'package_app_mandatory_code_paths.txt'
Copy-WorkspaceTreeWithExplicitExclusions -RepoRoot $WorkspaceRoot -DestRoot $pmDataDir `
    -BundleKind VersionUpgrade -MandatoryPathsFile $mandatoryFile -ReleaseFolderRelativePrefix 'pm-ai-package-release/'

$initSrc = Join-Path $WorkspaceRoot 'init_setting'
$initDst = Join-Path $pmDataDir 'init_setting'
if (Test-Path -LiteralPath $initSrc) {
    New-Item -ItemType Directory -Path $initDst -Force | Out-Null
    & robocopy $initSrc $initDst /E /XD user-profiles /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
    if ($LASTEXITCODE -ge 8) {
        throw "robocopy init_setting failed (exit $LASTEXITCODE)"
    }
}

New-Item -ItemType Directory -Path (Join-Path $pmDataDir 'input\task-input') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $pmDataDir 'input\actual-detail') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $pmDataDir 'output') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $pmDataDir 'config') -Force | Out-Null

$stage1ExcludeSrc = Join-Path $pmDataDir 'code\json\stage1_exclude_rules.json'
$excludeRulesDest = Join-Path $pmDataDir 'code\exclude_rules.json'
if (Test-Path -LiteralPath $stage1ExcludeSrc) {
    Copy-Item -LiteralPath $stage1ExcludeSrc -Destination $excludeRulesDest -Force
}

# 3. Apply script & version.txt
$applyScriptSrc = Join-Path $WorkspaceRoot 'scripts\pmd-apply-portable-update.ps1'
if (Test-Path -LiteralPath $applyScriptSrc) {
    Copy-Item -LiteralPath $applyScriptSrc -Destination (Join-Path $stagingUpgrade 'pmd-apply-portable-update.ps1') -Force
    $scriptsUnderData = Join-Path $pmDataDir 'scripts'
    New-Item -ItemType Directory -Force -Path $scriptsUnderData | Out-Null
    Copy-Item -LiteralPath $applyScriptSrc -Destination (Join-Path $scriptsUnderData 'pmd-apply-portable-update.ps1') -Force
}
Write-VersionTxtUtf8NoBom -SourcePath $VersionTxtPath -DestPath (Join-Path $stagingUpgrade 'version.txt')

$innerVer = Join-Path $pmDataDir 'version.txt'
if (Test-Path -LiteralPath $innerVer) {
    Remove-Item -LiteralPath $innerVer -Force
}

# 4. Create public updates/PMD_version_upgrade.zip with forward-slash entry paths (NO .exe)
New-Item -ItemType Directory -Path $PublicUpdatesDir -Force | Out-Null
New-Item -ItemType Directory -Path $ReleaseRoot -Force | Out-Null
$zipUpgradePath = Join-Path $PublicUpdatesDir 'PMD_version_upgrade.zip'
if (Test-Path -LiteralPath $zipUpgradePath) {
    Remove-Item -LiteralPath $zipUpgradePath -Force
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourceFull = (Resolve-Path -LiteralPath $stagingUpgrade).Path.TrimEnd('\')
$sourceLen = $sourceFull.Length
$fs = [System.IO.FileStream]::new($zipUpgradePath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
try {
    $zip = [System.IO.Compression.ZipArchive]::new($fs, [System.IO.Compression.ZipArchiveMode]::Create, $false)
    try {
        foreach ($full in [System.IO.Directory]::EnumerateFiles($sourceFull, '*', [System.IO.SearchOption]::AllDirectories)) {
            $rel = $full.Substring($sourceLen).TrimStart('\')
            $entryName = $rel -replace '\\', '/'
            $entry = $zip.CreateEntry($entryName, [System.IO.Compression.CompressionLevel]::Optimal)
            $es = $entry.Open()
            try {
                $srcFs = [System.IO.File]::OpenRead($full)
                try {
                    $srcFs.CopyTo($es)
                }
                finally {
                    $srcFs.Dispose()
                }
            }
            finally {
                $es.Dispose()
            }
        }
    }
    finally {
        $zip.Dispose()
    }
}
finally {
    $fs.Dispose()
}

Remove-Item -Recurse -Force -LiteralPath $stagingUpgrade -ErrorAction SilentlyContinue

# 5. Safety verification: Ensure main body (PMD.exe, runtime/, python.exe, code_java/) is NOT inside public updates/PMD_version_upgrade.zip
$zf = [System.IO.Compression.ZipFile]::OpenRead($zipUpgradePath)
try {
    foreach ($entry in $zf.Entries) {
        $en = $entry.FullName.Replace('\', '/')
        if ($en -ieq 'PMD.exe' -or $en.StartsWith('runtime/') -or $en.StartsWith('pm-ai-data/runtime/') -or $en.StartsWith('pm-ai-data/code_java/') -or $en.EndsWith('.exe')) {
            throw "SAFETY CHECK FAILED: Forbidden main-body or executable entry found in update ZIP: $en"
        }
    }
}
finally {
    $zf.Dispose()
}
$zipSizeMb = [Math]::Round((Get-Item -LiteralPath $zipUpgradePath).Length / 1MB, 2)
Write-Host "Verified update-only ZIP (no main body / no .exe): $zipUpgradePath ($zipSizeMb MB)" -ForegroundColor Green

# 6. Write version.txt, build-manifest.json, version.json to updates/ and pm-ai-package-release/
Write-VersionTxtUtf8NoBom -SourcePath $VersionTxtPath -DestPath (Join-Path $PublicUpdatesDir 'version.txt')
Write-VersionTxtUtf8NoBom -SourcePath $VersionTxtPath -DestPath (Join-Path $ReleaseRoot 'version.txt')

$jarSha = (Get-FileHash -LiteralPath $desktopJar.FullName -Algorithm SHA256).Hash
$manifestObj = [ordered]@{
    version            = $verLine
    desktopJarFileName = $desktopJar.Name
    desktopJarSize     = $desktopJar.Length
    desktopJarSha256   = $jarSha
}
$manifestJson = $manifestObj | ConvertTo-Json
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText((Join-Path $PublicUpdatesDir 'build-manifest.json'), $manifestJson, $utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path $ReleaseRoot 'build-manifest.json'), $manifestJson, $utf8NoBom)

$zipSha = (Get-FileHash -LiteralPath $zipUpgradePath -Algorithm SHA256).Hash
$versionJsonObj = [ordered]@{
    version      = $verLine
    released_at  = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
    download_url = 'https://raw.githubusercontent.com/nagaokasangyou/Production-Control-System/main/updates/PMD_version_upgrade.zip'
    sha256       = $zipSha
    notes        = "Version $verLine differential update (excludes main body runtime/launcher)."
}
$versionJsonText = $versionJsonObj | ConvertTo-Json
[System.IO.File]::WriteAllText((Join-Path $PublicUpdatesDir 'version.json'), $versionJsonText, $utf8NoBom)
[System.IO.File]::WriteAllText((Join-Path $ReleaseRoot 'version.json'), $versionJsonText, $utf8NoBom)

$releaseZipPath = Join-Path $ReleaseRoot 'PMD_version_upgrade.zip'
Copy-Item -LiteralPath $zipUpgradePath -Destination $releaseZipPath -Force

# 6a. Archive this new release, prune to KeepPreviousGenerations previous versions, and write history.json
[void](Save-PmdReleaseToArchive `
    -SourceDir $PublicUpdatesDir `
    -ArchiveRootDir $PublicArchiveDir `
    -MirrorArchiveRootDir $ReleaseArchiveDir `
    -DownloadBaseUrl $RawDownloadBaseUrl)
Invoke-PmdArchivePrune `
    -ArchiveRootDir $PublicArchiveDir `
    -MaxPreviousGenerations $KeepPreviousGenerations `
    -ActiveVersion $verLine `
    -MirrorArchiveRootDir $ReleaseArchiveDir
Write-PmdReleaseHistoryJson `
    -UpdatesDir $PublicUpdatesDir `
    -ReleaseDir $ReleaseRoot `
    -MaxPreviousGenerations $KeepPreviousGenerations

# 6b. Refresh PmdUserMonitor differential update package (updates/pmd-user-monitor/) so force-push preserves it
$monitorPublishScript = Join-Path $WorkspaceRoot 'tools\pmd-user-monitor\publish_monitor_update.ps1'
if (Test-Path -LiteralPath $monitorPublishScript) {
    & powershell -NoProfile -ExecutionPolicy Bypass -File $monitorPublishScript -SkipVersionBump -SkipGitPush
    if ($LASTEXITCODE -ne 0) {
        throw "publish_monitor_update.ps1 failed (exit $LASTEXITCODE)"
    }
}

# Keep pmd-apply-portable-update.ps1 in PMD_initial_install up to date,
# but NEVER overwrite app/*.jar or version.txt directly in PMD_initial_install.
# Directly overwriting version.txt/JAR in PMD_initial_install makes local version == remote GitHub version
# before PMD.exe runs its updater, preventing the GitHub differential update (pm-ai-data sync & env reset) from triggering.
$localUnpacked = Join-Path $ReleaseRoot 'PMD_initial_install'
if (Test-Path -LiteralPath (Join-Path $localUnpacked 'app')) {
    if (Test-Path -LiteralPath $applyScriptSrc) {
        Copy-Item -LiteralPath $applyScriptSrc -Destination (Join-Path $localUnpacked 'pmd-apply-portable-update.ps1') -Force
    }
}

if ($SkipGitPush) {
    Write-Host "Skipped Git push (-SkipGitPush)." -ForegroundColor Yellow
    return
}

# 7. Publish updates/ (active release + recent archived generations + history.json) to the dedicated public GitHub repository
Publish-PmdUpdatesToPublicGitHub `
    -WorkspaceRoot $WorkspaceRoot `
    -PublicUpdatesDir $PublicUpdatesDir `
    -PublicRepoUrl $PublicRepoUrl `
    -Branch $Branch `
    -CommitMessage "Release differential update v$verLine (update files only)" `
    -PreparedCloneDir $pubRepoCloneDir
Write-Host "=== Successfully published update v$verLine to $PublicRepoUrl ===" -ForegroundColor Green
