# Shared release archive & rollback helper functions for PMD differential updates.
# Pure ASCII script for full compatibility with Windows PowerShell 5.1 and PowerShell 7+.

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Write-PmdUtf8NoBomText {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    $utf8NoBom = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function Write-PmdVersionTxtUtf8NoBom {
    param(
        [Parameter(Mandatory = $true)][string]$VersionString,
        [Parameter(Mandatory = $true)][string]$DestPath
    )
    $trimmed = $VersionString.Trim().TrimStart([char]0xFEFF)
    Write-PmdUtf8NoBomText -Path $DestPath -Content ($trimmed + "`n")
}

function ConvertTo-PmdDecimalVersion {
    param([string]$VersionText)
    if ([string]::IsNullOrWhiteSpace($VersionText)) {
        return $null
    }
    $clean = $VersionText.Trim().TrimStart([char]0xFEFF)
    $firstLine = ($clean -split '\r?\n')[0].Trim()
    $dec = [decimal]0
    if ([decimal]::TryParse(
            $firstLine,
            [System.Globalization.NumberStyles]::AllowDecimalPoint,
            [System.Globalization.CultureInfo]::InvariantCulture,
            [ref]$dec)) {
        return $dec
    }
    return $null
}

function Read-PmdVersionTxt {
    param([string]$FilePath)
    if (-not $FilePath -or -not (Test-Path -LiteralPath $FilePath -PathType Leaf)) {
        return $null
    }
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $raw = [System.IO.File]::ReadAllText($FilePath, $utf8).Trim().TrimStart([char]0xFEFF)
    if ([string]::IsNullOrWhiteSpace($raw)) {
        return $null
    }
    return ($raw -split '\r?\n')[0].Trim()
}

function Test-PmdUpdateZipSafety {
    param([Parameter(Mandatory = $true)][string]$ZipPath)
    if (-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
        throw "Update ZIP does not exist: $ZipPath"
    }
    $hasAppJar = $false
    $hasPmAiData = $false
    $zf = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        foreach ($entry in $zf.Entries) {
            $en = $entry.FullName.Replace('\', '/')
            if ($en -ieq 'PMD.exe' `
                -or $en.StartsWith('runtime/', [StringComparison]::OrdinalIgnoreCase) `
                -or $en.StartsWith('pm-ai-data/runtime/', [StringComparison]::OrdinalIgnoreCase) `
                -or $en.StartsWith('pm-ai-data/code_java/', [StringComparison]::OrdinalIgnoreCase) `
                -or $en.EndsWith('.exe', [StringComparison]::OrdinalIgnoreCase)) {
                throw "SAFETY CHECK FAILED: Forbidden main-body or executable entry found in update ZIP ($ZipPath): $en"
            }
            if ($en.StartsWith('app/', [StringComparison]::OrdinalIgnoreCase) -and $en.EndsWith('.jar', [StringComparison]::OrdinalIgnoreCase)) {
                $hasAppJar = $true
            }
            if ($en.StartsWith('pm-ai-data/', [StringComparison]::OrdinalIgnoreCase) -and -not $en.EndsWith('/')) {
                $hasPmAiData = $true
            }
        }
    }
    finally {
        $zf.Dispose()
    }
    if (-not $hasAppJar) {
        throw "SAFETY CHECK FAILED: Update ZIP is missing app/*.jar: $ZipPath"
    }
    if (-not $hasPmAiData) {
        throw "SAFETY CHECK FAILED: Update ZIP is missing pm-ai-data/ entries: $ZipPath"
    }
}

function Save-PmdReleaseToArchive {
    param(
        [Parameter(Mandatory = $true)][string]$SourceDir,
        [Parameter(Mandatory = $true)][string]$ArchiveRootDir,
        [string]$MirrorArchiveRootDir = '',
        [string]$DownloadBaseUrl = 'https://raw.githubusercontent.com/nagaokasangyou/Production-Control-System/main/updates'
    )
    $verTxt = Join-Path $SourceDir 'version.txt'
    $manifestPath = Join-Path $SourceDir 'build-manifest.json'
    $zipPath = Join-Path $SourceDir 'PMD_version_upgrade.zip'
    $verJsonPath = Join-Path $SourceDir 'version.json'

    if (-not (Test-Path -LiteralPath $verTxt -PathType Leaf) `
        -or -not (Test-Path -LiteralPath $manifestPath -PathType Leaf) `
        -or -not (Test-Path -LiteralPath $zipPath -PathType Leaf)) {
        return $null
    }

    $ver = Read-PmdVersionTxt -FilePath $verTxt
    $verDec = ConvertTo-PmdDecimalVersion -VersionText $ver
    if ($null -eq $verDec) {
        return $null
    }

    Test-PmdUpdateZipSafety -ZipPath $zipPath

    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $rawManifest = [System.IO.File]::ReadAllText($manifestPath, $utf8).TrimStart([char]0xFEFF) | ConvertFrom-Json
    $manifestVer = if ($rawManifest.PSObject.Properties['version'] -and -not [string]::IsNullOrWhiteSpace([string]$rawManifest.version)) {
        ([string]$rawManifest.version).Trim()
    } else {
        $ver
    }
    if ($manifestVer -ne $ver) {
        # Keep archive consistent only when version.txt and build-manifest.json agree on version.
        return $null
    }

    $releasedAt = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
    if (Test-Path -LiteralPath $verJsonPath -PathType Leaf) {
        try {
            $rawVerJson = [System.IO.File]::ReadAllText($verJsonPath, $utf8).TrimStart([char]0xFEFF) | ConvertFrom-Json
            if ($rawVerJson.PSObject.Properties['released_at'] -and -not [string]::IsNullOrWhiteSpace([string]$rawVerJson.released_at)) {
                $releasedAt = ([string]$rawVerJson.released_at).Trim()
            }
        }
        catch {
            # Ignore malformed optional version.json
        }
    }

    $destDir = Join-Path $ArchiveRootDir "v$ver"
    New-Item -ItemType Directory -Path $destDir -Force | Out-Null

    # Preserve existing released_at if already archived
    $existingArchivedVerJson = Join-Path $destDir 'version.json'
    if (Test-Path -LiteralPath $existingArchivedVerJson -PathType Leaf) {
        try {
            $oldVj = [System.IO.File]::ReadAllText($existingArchivedVerJson, $utf8).TrimStart([char]0xFEFF) | ConvertFrom-Json
            if ($oldVj.PSObject.Properties['released_at'] -and -not [string]::IsNullOrWhiteSpace([string]$oldVj.released_at)) {
                $releasedAt = ([string]$oldVj.released_at).Trim()
            }
        }
        catch {
        }
    }

    $destZip = Join-Path $destDir 'PMD_version_upgrade.zip'
    $srcZipHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToUpperInvariant()
    $needZipCopy = $true
    if (Test-Path -LiteralPath $destZip -PathType Leaf) {
        $existingHash = (Get-FileHash -LiteralPath $destZip -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($existingHash -eq $srcZipHash) {
            $needZipCopy = $false
        }
    }
    if ($needZipCopy) {
        Copy-Item -LiteralPath $zipPath -Destination $destZip -Force
    }

    Write-PmdVersionTxtUtf8NoBom -VersionString $ver -DestPath (Join-Path $destDir 'version.txt')

    # Strip any rollback transient fields so archived manifest stays canonical for that version
    $cleanManifestObj = [ordered]@{
        version            = $ver
        desktopJarFileName = [string]$rawManifest.desktopJarFileName
        desktopJarSize     = [int64]$rawManifest.desktopJarSize
        desktopJarSha256   = ([string]$rawManifest.desktopJarSha256).ToUpperInvariant()
    }
    Write-PmdUtf8NoBomText -Path (Join-Path $destDir 'build-manifest.json') -Content ($cleanManifestObj | ConvertTo-Json)

    $baseTrim = $DownloadBaseUrl.TrimEnd('/')
    $cleanVerJsonObj = [ordered]@{
        version      = $ver
        released_at  = $releasedAt
        download_url = "$baseTrim/archive/v$ver/PMD_version_upgrade.zip"
        sha256       = $srcZipHash
        notes        = "Version $ver archived differential update (excludes main body runtime/launcher)."
    }
    Write-PmdUtf8NoBomText -Path (Join-Path $destDir 'version.json') -Content ($cleanVerJsonObj | ConvertTo-Json)

    if (-not [string]::IsNullOrWhiteSpace($MirrorArchiveRootDir)) {
        $mirrorDest = Join-Path $MirrorArchiveRootDir "v$ver"
        New-Item -ItemType Directory -Path $mirrorDest -Force | Out-Null
        foreach ($leaf in @('version.txt', 'build-manifest.json', 'version.json', 'PMD_version_upgrade.zip')) {
            $s = Join-Path $destDir $leaf
            $d = Join-Path $mirrorDest $leaf
            if ($leaf -eq 'PMD_version_upgrade.zip' -and (Test-Path -LiteralPath $d -PathType Leaf)) {
                $mh = (Get-FileHash -LiteralPath $d -Algorithm SHA256).Hash.ToUpperInvariant()
                if ($mh -eq $srcZipHash) {
                    continue
                }
            }
            Copy-Item -LiteralPath $s -Destination $d -Force
        }
    }

    return $ver
}

function Get-PmdArchivedVersions {
    param([Parameter(Mandatory = $true)][string]$ArchiveRootDir)
    $items = @()
    if (-not (Test-Path -LiteralPath $ArchiveRootDir -PathType Container)) {
        return ,$items
    }
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    foreach ($dir in (Get-ChildItem -LiteralPath $ArchiveRootDir -Directory -Filter 'v*')) {
        $vt = Join-Path $dir.FullName 'version.txt'
        $bm = Join-Path $dir.FullName 'build-manifest.json'
        $zp = Join-Path $dir.FullName 'PMD_version_upgrade.zip'
        $vj = Join-Path $dir.FullName 'version.json'
        if (-not (Test-Path -LiteralPath $vt -PathType Leaf) `
            -or -not (Test-Path -LiteralPath $bm -PathType Leaf) `
            -or -not (Test-Path -LiteralPath $zp -PathType Leaf)) {
            continue
        }
        $ver = Read-PmdVersionTxt -FilePath $vt
        $dec = ConvertTo-PmdDecimalVersion -VersionText $ver
        if ($null -eq $dec) {
            continue
        }
        try {
            $mObj = [System.IO.File]::ReadAllText($bm, $utf8).TrimStart([char]0xFEFF) | ConvertFrom-Json
            $releasedAt = ''
            $zipSha = ''
            if (Test-Path -LiteralPath $vj -PathType Leaf) {
                $vjObj = [System.IO.File]::ReadAllText($vj, $utf8).TrimStart([char]0xFEFF) | ConvertFrom-Json
                if ($vjObj.PSObject.Properties['released_at']) { $releasedAt = [string]$vjObj.released_at }
                if ($vjObj.PSObject.Properties['sha256']) { $zipSha = ([string]$vjObj.sha256).ToUpperInvariant() }
            }
            if ([string]::IsNullOrWhiteSpace($zipSha)) {
                $zipSha = (Get-FileHash -LiteralPath $zp -Algorithm SHA256).Hash.ToUpperInvariant()
            }
            $items += [pscustomobject]@{
                Version            = $ver
                VersionDecimal     = $dec
                Directory          = $dir.FullName
                ZipPath            = $zp
                ManifestPath       = $bm
                VersionJsonPath    = $vj
                VersionTxtPath     = $vt
                ReleasedAt         = $releasedAt
                ZipSha256          = $zipSha
                ZipSizeBytes       = (Get-Item -LiteralPath $zp).Length
                DesktopJarFileName = [string]$mObj.desktopJarFileName
                DesktopJarSize     = [int64]$mObj.desktopJarSize
                DesktopJarSha256   = ([string]$mObj.desktopJarSha256).ToUpperInvariant()
            }
        }
        catch {
            Write-Warning "Skipping unreadable archive folder $($dir.FullName): $($_.Exception.Message)"
        }
    }
    $sorted = @($items | Sort-Object -Property VersionDecimal -Descending)
    return ,$sorted
}

function Invoke-PmdArchivePrune {
    param(
        [Parameter(Mandatory = $true)][string]$ArchiveRootDir,
        [int]$MaxPreviousGenerations = 3,
        [string]$ActiveVersion = '',
        [string]$MirrorArchiveRootDir = ''
    )
    # Keep current latest + MaxPreviousGenerations previous versions (e.g., 1 + 3 = 4 total versions)
    $maxTotal = [Math]::Max(1, $MaxPreviousGenerations + 1)
    $all = Get-PmdArchivedVersions -ArchiveRootDir $ArchiveRootDir
    if ($all.Count -le $maxTotal) {
        return
    }

    $keepVersions = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    if (-not [string]::IsNullOrWhiteSpace($ActiveVersion)) {
        [void]$keepVersions.Add($ActiveVersion.Trim())
    }
    foreach ($entry in $all) {
        if ($keepVersions.Count -ge $maxTotal) {
            break
        }
        [void]$keepVersions.Add($entry.Version)
    }

    foreach ($entry in $all) {
        if (-not $keepVersions.Contains($entry.Version)) {
            Write-Host "Pruning old archived update v$($entry.Version): $($entry.Directory)" -ForegroundColor DarkGray
            Remove-Item -LiteralPath $entry.Directory -Recurse -Force -ErrorAction SilentlyContinue
            if (-not [string]::IsNullOrWhiteSpace($MirrorArchiveRootDir)) {
                $mirrorDir = Join-Path $MirrorArchiveRootDir "v$($entry.Version)"
                if (Test-Path -LiteralPath $mirrorDir) {
                    Remove-Item -LiteralPath $mirrorDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
}

function Write-PmdReleaseHistoryJson {
    param(
        [Parameter(Mandatory = $true)][string]$UpdatesDir,
        [string]$ReleaseDir = '',
        [int]$MaxPreviousGenerations = 3
    )
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $curVer = Read-PmdVersionTxt -FilePath (Join-Path $UpdatesDir 'version.txt')
    $isRollback = $false
    $rolledBackFrom = $null
    $manifestFile = Join-Path $UpdatesDir 'build-manifest.json'
    if (Test-Path -LiteralPath $manifestFile -PathType Leaf) {
        try {
            $mObj = [System.IO.File]::ReadAllText($manifestFile, $utf8).TrimStart([char]0xFEFF) | ConvertFrom-Json
            if ($mObj.PSObject.Properties['rollback'] -and [bool]$mObj.rollback) {
                $isRollback = $true
            }
            if ($mObj.PSObject.Properties['rolledBackFrom'] -and -not [string]::IsNullOrWhiteSpace([string]$mObj.rolledBackFrom)) {
                $rolledBackFrom = [string]$mObj.rolledBackFrom
            }
        }
        catch {
        }
    }

    $archiveDir = Join-Path $UpdatesDir 'archive'
    $archived = Get-PmdArchivedVersions -ArchiveRootDir $archiveDir
    $verList = @()
    foreach ($a in $archived) {
        $verList += [ordered]@{
            version            = $a.Version
            is_active          = ($a.Version -eq $curVer)
            released_at        = $a.ReleasedAt
            zip_sha256         = $a.ZipSha256
            zip_size           = $a.ZipSizeBytes
            desktopJarFileName = $a.DesktopJarFileName
            desktopJarSize     = $a.DesktopJarSize
            desktopJarSha256   = $a.DesktopJarSha256
            archive_rel_path   = "updates/archive/v$($a.Version)"
        }
    }

    $historyObj = [ordered]@{
        current_version          = $curVer
        is_rollback              = $isRollback
        rolled_back_from         = $rolledBackFrom
        updated_at               = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
        max_previous_generations = $MaxPreviousGenerations
        available_versions       = $verList
    }
    $json = $historyObj | ConvertTo-Json -Depth 6
    Write-PmdUtf8NoBomText -Path (Join-Path $UpdatesDir 'history.json') -Content $json
    if (-not [string]::IsNullOrWhiteSpace($ReleaseDir) -and (Test-Path -LiteralPath $ReleaseDir -PathType Container)) {
        Write-PmdUtf8NoBomText -Path (Join-Path $ReleaseDir 'history.json') -Content $json
    }
}

function Sync-PmdArchiveFromRemoteRepo {
    param(
        [Parameter(Mandatory = $true)][string]$PublicRepoUrl,
        [string]$Branch = 'main',
        [Parameter(Mandatory = $true)][string]$LocalUpdatesDir,
        [string]$LocalReleaseDir = '',
        [Parameter(Mandatory = $true)][string]$CloneDir
    )
    if (Test-Path -LiteralPath $CloneDir) {
        Remove-Item -LiteralPath $CloneDir -Recurse -Force
    }
    $parent = Split-Path -Parent $CloneDir
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }

    Write-Host "Fetching existing update archive metadata from $PublicRepoUrl ($Branch) ..." -ForegroundColor DarkCyan
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & git clone --depth 1 --branch $Branch $PublicRepoUrl $CloneDir 2>&1 | Out-Host
        $cloneExit = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $prevEap
    }

    if ($cloneExit -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $CloneDir '.git'))) {
        Write-Warning "Could not clone $PublicRepoUrl ($Branch); proceeding with local archive only."
        if (Test-Path -LiteralPath $CloneDir) {
            Remove-Item -LiteralPath $CloneDir -Recurse -Force -ErrorAction SilentlyContinue
        }
        return $false
    }

    $localArchiveRoot = Join-Path $LocalUpdatesDir 'archive'
    $mirrorArchiveRoot = if ([string]::IsNullOrWhiteSpace($LocalReleaseDir)) { '' } else { Join-Path $LocalReleaseDir 'archive' }
    New-Item -ItemType Directory -Path $localArchiveRoot -Force | Out-Null

    $remoteUpdates = Join-Path $CloneDir 'updates'
    if (Test-Path -LiteralPath $remoteUpdates -PathType Container) {
        $remoteCurVer = Read-PmdVersionTxt -FilePath (Join-Path $remoteUpdates 'version.txt')
        if ($remoteCurVer -and -not (Test-Path -LiteralPath (Join-Path $localArchiveRoot "v$remoteCurVer\PMD_version_upgrade.zip"))) {
            $importedCur = Save-PmdReleaseToArchive -SourceDir $remoteUpdates -ArchiveRootDir $localArchiveRoot -MirrorArchiveRootDir $mirrorArchiveRoot
            if ($importedCur) {
                Write-Host "Imported remote active release v$importedCur into local archive." -ForegroundColor DarkCyan
            }
        }
        $remoteArchiveRoot = Join-Path $remoteUpdates 'archive'
        if (Test-Path -LiteralPath $remoteArchiveRoot -PathType Container) {
            foreach ($rDir in (Get-ChildItem -LiteralPath $remoteArchiveRoot -Directory -Filter 'v*')) {
                $rVer = Read-PmdVersionTxt -FilePath (Join-Path $rDir.FullName 'version.txt')
                if ($rVer -and -not (Test-Path -LiteralPath (Join-Path $localArchiveRoot "v$rVer\PMD_version_upgrade.zip"))) {
                    $imported = Save-PmdReleaseToArchive -SourceDir $rDir.FullName -ArchiveRootDir $localArchiveRoot -MirrorArchiveRootDir $mirrorArchiveRoot
                    if ($imported) {
                        Write-Host "Imported remote archived release v$imported into local archive." -ForegroundColor DarkCyan
                    }
                }
            }
        }
    }
    return $true
}

function Publish-PmdUpdatesToPublicGitHub {
    param(
        [Parameter(Mandatory = $true)][string]$WorkspaceRoot,
        [Parameter(Mandatory = $true)][string]$PublicUpdatesDir,
        [Parameter(Mandatory = $true)][string]$PublicRepoUrl,
        [string]$Branch = 'main',
        [Parameter(Mandatory = $true)][string]$CommitMessage,
        [string]$PreparedCloneDir = ''
    )
    $pubRepoDir = if (-not [string]::IsNullOrWhiteSpace($PreparedCloneDir)) {
        $PreparedCloneDir
    } else {
        Join-Path $WorkspaceRoot '.tmp\public_updates_repo'
    }

    $hasExistingGit = Test-Path -LiteralPath (Join-Path $pubRepoDir '.git')
    if (-not $hasExistingGit) {
        if (Test-Path -LiteralPath $pubRepoDir) {
            Remove-Item -LiteralPath $pubRepoDir -Recurse -Force
        }
        $prevEap = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            & git clone --depth 1 --branch $Branch $PublicRepoUrl $pubRepoDir 2>&1 | Out-Host
            $hasExistingGit = ($LASTEXITCODE -eq 0) -and (Test-Path -LiteralPath (Join-Path $pubRepoDir '.git'))
        }
        finally {
            $ErrorActionPreference = $prevEap
        }
        if (-not $hasExistingGit) {
            if (Test-Path -LiteralPath $pubRepoDir) {
                Remove-Item -LiteralPath $pubRepoDir -Recurse -Force
            }
            New-Item -ItemType Directory -Path $pubRepoDir -Force | Out-Null
        }
    }

    # Preserve remote monitor artifacts if local workspace doesn't have them built yet
    $localMonitorDir = Join-Path $PublicUpdatesDir 'pmd-user-monitor'
    $remoteMonitorDir = Join-Path $pubRepoDir 'updates\pmd-user-monitor'
    $tempMonitorBackup = Join-Path $WorkspaceRoot '.tmp\public_updates_monitor_bak'
    if (Test-Path -LiteralPath $tempMonitorBackup) {
        Remove-Item -LiteralPath $tempMonitorBackup -Recurse -Force
    }
    if (-not (Test-Path -LiteralPath (Join-Path $localMonitorDir 'PmdUserMonitor_upgrade.zip')) `
        -and (Test-Path -LiteralPath (Join-Path $remoteMonitorDir 'PmdUserMonitor_upgrade.zip'))) {
        New-Item -ItemType Directory -Path $tempMonitorBackup -Force | Out-Null
        Copy-Item -Path (Join-Path $remoteMonitorDir '*') -Destination $tempMonitorBackup -Recurse -Force
    }

    # Clean working tree except .git so pruned archive versions are removed cleanly
    foreach ($child in (Get-ChildItem -LiteralPath $pubRepoDir -Force)) {
        if ($child.Name -eq '.git') {
            continue
        }
        Remove-Item -LiteralPath $child.FullName -Recurse -Force
    }

    New-Item -ItemType Directory -Path (Join-Path $pubRepoDir 'updates') -Force | Out-Null

    $utf8NoBom = [System.Text.UTF8Encoding]::new($false)
    $readmeLines = @(
        '# Production Control System - Differential Updates',
        '',
        'Public differential update distribution repository for PMD.',
        '- Main application body (PMD.exe, Java runtime, Python runtime, dependency JARs, source code) is NOT included in this repository.',
        '- Clients automatically check and download differential updates (and authorized rollbacks) from `updates/` on startup and periodically.',
        '',
        '## Published Update Artifacts',
        '- `updates/version.txt`',
        '- `updates/build-manifest.json`',
        '- `updates/version.json`',
        '- `updates/history.json`',
        '- `updates/PMD_version_upgrade.zip`',
        '- `updates/archive/v<ver>/` (recent 3 previous generations for instant rollback)',
        '- `updates/pmd-user-monitor/version.txt`',
        '- `updates/pmd-user-monitor/version.json`',
        '- `updates/pmd-user-monitor/PmdUserMonitor_upgrade.zip`'
    )
    [System.IO.File]::WriteAllLines((Join-Path $pubRepoDir 'README.md'), $readmeLines, $utf8NoBom)

    $gitignoreLines = @(
        '# Only allow README.md, .gitignore, and updates/ differential files',
        '*',
        '!.gitignore',
        '!README.md',
        '!updates/',
        '!updates/version.txt',
        '!updates/build-manifest.json',
        '!updates/version.json',
        '!updates/history.json',
        '!updates/PMD_version_upgrade.zip',
        '!updates/archive/',
        '!updates/archive/**',
        '!updates/pmd-user-monitor/',
        '!updates/pmd-user-monitor/version.txt',
        '!updates/pmd-user-monitor/version.json',
        '!updates/pmd-user-monitor/PmdUserMonitor_upgrade.zip',
        'PMD_initial_install*',
        '*.exe'
    )
    [System.IO.File]::WriteAllLines((Join-Path $pubRepoDir '.gitignore'), $gitignoreLines, $utf8NoBom)

    foreach ($f in @('version.txt', 'build-manifest.json', 'version.json', 'history.json', 'PMD_version_upgrade.zip')) {
        $srcFile = Join-Path $PublicUpdatesDir $f
        if (Test-Path -LiteralPath $srcFile -PathType Leaf) {
            Copy-Item -LiteralPath $srcFile -Destination (Join-Path $pubRepoDir "updates\$f") -Force
        }
    }

    # Copy archived generations (up to pruned count) and verify every archived ZIP is safe
    $localArchiveRoot = Join-Path $PublicUpdatesDir 'archive'
    if (Test-Path -LiteralPath $localArchiveRoot -PathType Container) {
        $pubArchiveRoot = Join-Path $pubRepoDir 'updates\archive'
        New-Item -ItemType Directory -Path $pubArchiveRoot -Force | Out-Null
        foreach ($arch in (Get-PmdArchivedVersions -ArchiveRootDir $localArchiveRoot)) {
            Test-PmdUpdateZipSafety -ZipPath $arch.ZipPath
            $dstArchDir = Join-Path $pubArchiveRoot "v$($arch.Version)"
            New-Item -ItemType Directory -Path $dstArchDir -Force | Out-Null
            foreach ($af in @('version.txt', 'build-manifest.json', 'version.json', 'PMD_version_upgrade.zip')) {
                $srcAf = Join-Path $arch.Directory $af
                if (Test-Path -LiteralPath $srcAf -PathType Leaf) {
                    Copy-Item -LiteralPath $srcAf -Destination (Join-Path $dstArchDir $af) -Force
                }
            }
        }
    }

    # Copy monitor artifacts
    $effectiveMonitorSrc = if (Test-Path -LiteralPath (Join-Path $localMonitorDir 'PmdUserMonitor_upgrade.zip')) {
        $localMonitorDir
    } elseif (Test-Path -LiteralPath (Join-Path $tempMonitorBackup 'PmdUserMonitor_upgrade.zip')) {
        $tempMonitorBackup
    } else {
        ''
    }
    if (-not [string]::IsNullOrWhiteSpace($effectiveMonitorSrc)) {
        $monitorDstDir = Join-Path $pubRepoDir 'updates\pmd-user-monitor'
        New-Item -ItemType Directory -Path $monitorDstDir -Force | Out-Null
        foreach ($mf in @('version.txt', 'version.json', 'PmdUserMonitor_upgrade.zip')) {
            $srcMf = Join-Path $effectiveMonitorSrc $mf
            if (Test-Path -LiteralPath $srcMf -PathType Leaf) {
                Copy-Item -LiteralPath $srcMf -Destination (Join-Path $monitorDstDir $mf) -Force
            }
        }
    }
    if (Test-Path -LiteralPath $tempMonitorBackup) {
        Remove-Item -LiteralPath $tempMonitorBackup -Recurse -Force -ErrorAction SilentlyContinue
    }

    # Final safety verification on active ZIP
    Test-PmdUpdateZipSafety -ZipPath (Join-Path $pubRepoDir 'updates\PMD_version_upgrade.zip')

    Push-Location $pubRepoDir
    try {
        if (-not $hasExistingGit) {
            & git init -b $Branch | Out-Host
            & git remote add origin $PublicRepoUrl
        }
        & git config user.name "hosokawanagaokasangyou-dotcom"
        & git config user.email "hosokawanagaokasangyou@users.noreply.github.com"
        & git add -A
        if ($hasExistingGit) {
            # Amend single commit so unchanged archived ZIP blobs already on GitHub are not re-uploaded
            # while keeping public repository history at 1 commit (no repository bloat).
            & git commit --amend --allow-empty -m $CommitMessage | Out-Host
        }
        else {
            & git commit -m $CommitMessage | Out-Host
        }
        if ($LASTEXITCODE -ne 0) {
            throw "git commit failed (exit $LASTEXITCODE)"
        }
        & git push -u origin $Branch --force | Out-Host
        if ($LASTEXITCODE -ne 0) {
            throw "git push to $PublicRepoUrl failed (exit $LASTEXITCODE)"
        }
    }
    finally {
        Pop-Location
    }
}
