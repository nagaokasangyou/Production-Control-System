# Fleet-wide Rollback Publisher for PMD Differential Updates
# Restores a previously archived differential update version (up to 3 previous generations)
# as the canonical GitHub release with rollback=true so all client PCs automatically revert
# to the stable version until a newer fixed version is published.
# Pure ASCII script for full compatibility with Windows PowerShell 5.1 and PowerShell 7+.

[CmdletBinding()]
param(
    [string]$TargetVersion = '',
    [switch]$List,
    [switch]$SkipGitPush,
    [switch]$FetchRemoteArchive,
    [int]$KeepPreviousGenerations = 3,
    [string]$PublicRepoUrl = 'https://github.com/nagaokasangyou/Production-Control-System.git',
    [string]$Branch = 'main'
)

$ErrorActionPreference = 'Stop'

$WorkspaceRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$ReleaseRoot = Join-Path $WorkspaceRoot 'pm-ai-package-release'
$PublicUpdatesDir = Join-Path $WorkspaceRoot 'updates'
$PublicArchiveDir = Join-Path $PublicUpdatesDir 'archive'
$ReleaseArchiveDir = Join-Path $ReleaseRoot 'archive'
$RawDownloadBaseUrl = 'https://raw.githubusercontent.com/nagaokasangyou/Production-Control-System/main/updates'

. (Join-Path $WorkspaceRoot 'scripts\pmd_release_archive.ps1')

New-Item -ItemType Directory -Path $PublicUpdatesDir -Force | Out-Null
New-Item -ItemType Directory -Path $PublicArchiveDir -Force | Out-Null

# Ensure current active package in updates/ is saved in archive before switching
[void](Save-PmdReleaseToArchive `
    -SourceDir $PublicUpdatesDir `
    -ArchiveRootDir $PublicArchiveDir `
    -MirrorArchiveRootDir $ReleaseArchiveDir `
    -DownloadBaseUrl $RawDownloadBaseUrl)

$pubRepoCloneDir = Join-Path $WorkspaceRoot '.tmp\public_updates_repo'
if ((-not $SkipGitPush) -or $FetchRemoteArchive) {
    [void](Sync-PmdArchiveFromRemoteRepo `
        -PublicRepoUrl $PublicRepoUrl `
        -Branch $Branch `
        -LocalUpdatesDir $PublicUpdatesDir `
        -LocalReleaseDir $ReleaseRoot `
        -CloneDir $pubRepoCloneDir)
}

$currentPublishedVer = Read-PmdVersionTxt -FilePath (Join-Path $PublicUpdatesDir 'version.txt')
$currentDec = ConvertTo-PmdDecimalVersion -VersionText $currentPublishedVer
$archived = Get-PmdArchivedVersions -ArchiveRootDir $PublicArchiveDir

if ($List) {
    Write-Host "=== PMD Release Archive Status ===" -ForegroundColor Cyan
    Write-Host ("Current published version : " + ($(if ($currentPublishedVer) { "v$currentPublishedVer" } else { "(none)" })))
    if ($archived.Count -eq 0) {
        Write-Host "Archived versions         : (none)" -ForegroundColor Yellow
    }
    else {
        Write-Host "Available archived versions (newest first):" -ForegroundColor Cyan
        foreach ($item in $archived) {
            $marker = if ($item.Version -eq $currentPublishedVer) { " [ACTIVE]" } else { "" }
            $sizeMb = [Math]::Round($item.ZipSizeBytes / 1MB, 2)
            Write-Host ("  - v{0}{1} | released={2} | zip={3} MB | jarSha256={4}..." -f `
                $item.Version, `
                $marker, `
                ($(if ($item.ReleasedAt) { $item.ReleasedAt } else { "-" })), `
                $sizeMb, `
                $item.DesktopJarSha256.Substring(0, [Math]::Min(12, $item.DesktopJarSha256.Length)))
        }
    }
    Write-PmdReleaseHistoryJson `
        -UpdatesDir $PublicUpdatesDir `
        -ReleaseDir $ReleaseRoot `
        -MaxPreviousGenerations $KeepPreviousGenerations
    return
}

if ($archived.Count -eq 0) {
    throw "No archived PMD versions found under $PublicArchiveDir. Run publish_update.ps1 first or pass -FetchRemoteArchive."
}

$normalizedTarget = $TargetVersion.Trim()
if ($normalizedTarget.StartsWith('v', [StringComparison]::OrdinalIgnoreCase)) {
    $normalizedTarget = $normalizedTarget.Substring(1).Trim()
}

$selectedEntry = $null
if ([string]::IsNullOrWhiteSpace($normalizedTarget)) {
    # Auto-select the immediately preceding version strictly older than currentPublishedVer
    if ($null -eq $currentDec) {
        throw "Current published version could not be determined from updates/version.txt. Specify -TargetVersion explicitly."
    }
    $olderCandidates = @($archived | Where-Object { $_.VersionDecimal -lt $currentDec } | Sort-Object -Property VersionDecimal -Descending)
    if ($olderCandidates.Count -eq 0) {
        $availList = ($archived | ForEach-Object { "v$($_.Version)" }) -join ', '
        throw "No archived version older than current v$currentPublishedVer is available. Archived versions: $availList"
    }
    $selectedEntry = $olderCandidates[0]
}
else {
    $selectedEntry = $archived | Where-Object { $_.Version -eq $normalizedTarget } | Select-Object -First 1
    if (-not $selectedEntry) {
        $availList = ($archived | ForEach-Object { "v$($_.Version)" }) -join ', '
        throw "Target version v$normalizedTarget was not found in archive ($PublicArchiveDir). Available versions: $availList"
    }
}

$targetVer = $selectedEntry.Version
Write-Host "=== Rolling back PMD published update: v$currentPublishedVer -> v$targetVer ===" -ForegroundColor Cyan

# Safety verification on archived ZIP before activating
Test-PmdUpdateZipSafety -ZipPath $selectedEntry.ZipPath

$activeZipDest = Join-Path $PublicUpdatesDir 'PMD_version_upgrade.zip'
Copy-Item -LiteralPath $selectedEntry.ZipPath -Destination $activeZipDest -Force
Write-PmdVersionTxtUtf8NoBom -VersionString $targetVer -DestPath (Join-Path $PublicUpdatesDir 'version.txt')

$rolledBackAt = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssK')
$rolledBackFromVal = if ($currentPublishedVer -and $currentPublishedVer -ne $targetVer) { $currentPublishedVer } else { '' }

# Write build-manifest.json with rollback=true so clients on newer versions downgrade to targetVer
$rollbackManifestObj = [ordered]@{
    version            = $targetVer
    desktopJarFileName = $selectedEntry.DesktopJarFileName
    desktopJarSize     = [int64]$selectedEntry.DesktopJarSize
    desktopJarSha256   = $selectedEntry.DesktopJarSha256
    rollback           = $true
    rolledBackFrom     = $rolledBackFromVal
    rolledBackAt       = $rolledBackAt
}
$manifestJson = $rollbackManifestObj | ConvertTo-Json
Write-PmdUtf8NoBomText -Path (Join-Path $PublicUpdatesDir 'build-manifest.json') -Content $manifestJson

$versionJsonObj = [ordered]@{
    version          = $targetVer
    released_at      = ($(if ($selectedEntry.ReleasedAt) { $selectedEntry.ReleasedAt } else { $rolledBackAt }))
    rolled_back_at   = $rolledBackAt
    rollback         = $true
    rolled_back_from = $rolledBackFromVal
    download_url     = "$RawDownloadBaseUrl/PMD_version_upgrade.zip"
    sha256           = $selectedEntry.ZipSha256
    notes            = "Rollback to v$targetVer" + ($(if ($rolledBackFromVal) { " from v$rolledBackFromVal" } else { "" })) + " (excludes main body runtime/launcher)."
}
$versionJsonText = $versionJsonObj | ConvertTo-Json
Write-PmdUtf8NoBomText -Path (Join-Path $PublicUpdatesDir 'version.json') -Content $versionJsonText

if (Test-Path -LiteralPath $ReleaseRoot -PathType Container) {
    Copy-Item -LiteralPath $activeZipDest -Destination (Join-Path $ReleaseRoot 'PMD_version_upgrade.zip') -Force
    Write-PmdVersionTxtUtf8NoBom -VersionString $targetVer -DestPath (Join-Path $ReleaseRoot 'version.txt')
    Write-PmdUtf8NoBomText -Path (Join-Path $ReleaseRoot 'build-manifest.json') -Content $manifestJson
    Write-PmdUtf8NoBomText -Path (Join-Path $ReleaseRoot 'version.json') -Content $versionJsonText
}

Invoke-PmdArchivePrune `
    -ArchiveRootDir $PublicArchiveDir `
    -MaxPreviousGenerations $KeepPreviousGenerations `
    -ActiveVersion $targetVer `
    -MirrorArchiveRootDir $ReleaseArchiveDir

Write-PmdReleaseHistoryJson `
    -UpdatesDir $PublicUpdatesDir `
    -ReleaseDir $ReleaseRoot `
    -MaxPreviousGenerations $KeepPreviousGenerations

$zipSizeMb = [Math]::Round((Get-Item -LiteralPath $activeZipDest).Length / 1MB, 2)
Write-Host "Verified rollback ZIP (no main body / no .exe): $activeZipDest ($zipSizeMb MB)" -ForegroundColor Green
Write-Host "Workspace version.txt remains unchanged so the next fix build will supersede v$currentPublishedVer." -ForegroundColor DarkCyan

if ($SkipGitPush) {
    Write-Host "Skipped Git push (-SkipGitPush). Local updates/ switched to rollback v$targetVer." -ForegroundColor Yellow
    return
}

$commitMsg = if ($rolledBackFromVal) {
    "Rollback differential update to v$targetVer (from v$rolledBackFromVal)"
} else {
    "Rollback differential update to v$targetVer"
}

Publish-PmdUpdatesToPublicGitHub `
    -WorkspaceRoot $WorkspaceRoot `
    -PublicUpdatesDir $PublicUpdatesDir `
    -PublicRepoUrl $PublicRepoUrl `
    -Branch $Branch `
    -CommitMessage $commitMsg `
    -PreparedCloneDir $pubRepoCloneDir

Write-Host "=== Successfully rolled back published update to v$targetVer on $PublicRepoUrl ===" -ForegroundColor Green
