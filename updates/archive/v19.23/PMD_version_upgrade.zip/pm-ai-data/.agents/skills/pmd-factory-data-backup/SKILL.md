---
name: pmd-factory-data-backup
description: >-
  湖南工場（共有DATA）と国分工場（DATA）を Google ドライブ（`H:\マイドライブ\システムデータファイルバックアップ`）へ
  高速増分フルミラー＆日時付きZIPアーカイブでバックアップし、直近N世代（既定14世代）を世代管理・ローテーションするスキル。
  ユーザーが「DATAバックアップ」「工場データバックアップ」「世代管理バックアップ」「共有DATAの退避・復元」や
  定期バックアップ Automation の実行・確認・復元を指示したときに使用する。
---

# 湖南・国分工場 DATA バックアップ＆世代管理スキル (`pmd-factory-data-backup`)

湖南工場（`共有DATA`）および国分工場（`DATA`）の配台AIシステム共有データを、`H:\マイドライブ\システムデータファイルバックアップ` へ安全・高速にバックアップし、世代管理（既定：直近14世代保持）を行う標準手順。

---

## 1. バックアップ対象と保存先アーキテクチャ

### バックアップ元（`M:` ドライブ優先、未接続時は UNC へ自動フォールバック）

| 工場コード | 工場名 | 優先パス (`M:` ドライブ) | フォールバック UNC パス |
|---|---|---|---|
| `KONAN` | 湖南工場 (共有DATA) | `M:\湖南工場\湖南共有\002  加工G\●配台AIシステム\共有DATA` | `\\192.168.0.101\共有フォルダ\湖南工場\湖南共有\002  加工G\●配台AIシステム\共有DATA` |
| `KOKUBU` | 国分工場 (DATA) | `M:\国分工場\国分共有\●配台AIシステム\DATA` | `\\192.168.0.101\共有フォルダ\国分工場\国分共有\●配台AIシステム\DATA` |

### 保存先ディレクトリ構造 (`H:\マイドライブ\システムデータファイルバックアップ`)

Google ドライブ（`H:`）の空き容量圧迫と小ファイル同期遅延を防ぎつつ、**単体ファイルの即時復元**と**過去世代へのロールバック**を両立する 2 層ハイブリッド方式を採用している：

```text
H:\マイドライブ\システムデータファイルバックアップ\
├── 最新フルミラー\                      # (1) robocopy /MIR による差分ミラー（解凍不要で即座に単体ファイル参照・復元可能）
│   ├── 湖南工場_共有DATA\
│   └── 国分工場_DATA\
├── 世代バックアップ\                    # (2) 日時付き ZIP 圧縮アーカイブ（既定で直近 14 世代を保持し古い世代を自動削除）
│   ├── 湖南工場_共有DATA\
│   │   └── KONAN_DATA_YYYYMMDD_HHMMSS.zip
│   └── 国分工場_DATA\
│       └── KOKUBU_DATA_YYYYMMDD_HHMMSS.zip
├── 最新バックアップ状況.md              # 人間向けステータス＆保持世代一覧レポート
└── backup_status.json                   # 機械可読実行結果マニフェスト
```

### 除外フィルタ仕様（容量肥大化防止）
- **除外対象**:
  - `PmAiRpaLuncher_portable`（約 1.78 GB：Java ポータブル実行環境バイナリ）
  - `PmAiRdpRemoteLauncher.exe`（約 65 MB：実行バイナリ）
  - `dispatch-snapshots` / `summary-ai-dispatch-generations`（計約 1.90 GB：それ自体が過去スナップショット履歴の巨大フォルダ）
  - 一時ロックファイル（`*.save.lock`, `~$*`, `Thumbs.db`, `desktop.ini`）
- **保護対象（完全バックアップ）**:
  - マスタ類（`master.xlsm`, `国分master.xlsm`, `master-dispatch-sheets.json`, `アラジンマスタ`, `*-history`）
  - 勤怠・機械カレンダー（`attendance-data.json`, `machine-calendar-data.json`, `勤怠カレンダー.xlsx`, `勤怠_表示用.xlsx`）
  - 操作者・PIN・RDP設定（`factory-operator-users.bin`, `factory-operator-users-backups`, `*_RPA設定.ini`, `*_RDPスケジュール.json`, `RDP起動プロファイル.json`）
  - 業務データ（`加工依頼書入力.xlsm`, `TPI依頼書`, `加工日報`, `実績`, `月次実績`, `計画`, `サマリ_AI配台.xlsx`, `dispatch_special_rules`, `juchu_header_aliases.json`, `操作ログ`, `remote_log` 等すべて）

---

## 2. 標準バックアップ実行コマンド

バックアップスクリプト [`tools/backup_factory_data.py`](../../../tools/backup_factory_data.py)（スキル同梱コピー: [`scripts/backup_factory_data.py`](./scripts/backup_factory_data.py)）を実行する：

```powershell
python "c:\システム開発\工程管理AIプロジェクト_JAVA\tools\backup_factory_data.py" --dest "H:\マイドライブ\システムデータファイルバックアップ" --keep 14
```

### コマンドライン引数
- `--dest <PATH>`: バックアップ先ルート（既定: `H:\マイドライブ\システムデータファイルバックアップ`）
- `--keep <N>`: 各工場で保持する世代 ZIP 数（既定: `14` 世代。超過した古い世代は自動削除）
- `--skip-mirror`: `最新フルミラー` の `robocopy` 同期をスキップし、世代 ZIP の作成とローテーションのみ行う

---

## 3. 実行後の検証手順

1. コマンド標準出力の JSON で `"all_ok": true` であることを確認する。
2. 各工場（`KONAN`, `KOKUBU`）について以下を確認しユーザーへ報告する：
   - `mirror.ok == true`（`robocopy` 終了コード `0`〜`7` は正常終了）
   - `generation_zip.zip_name`、`file_count`、`raw_mb` → `zip_mb`
   - `rotation.kept_count`（現在の保持世代数）および `rotation.deleted_files`（今回ローテーション削除された古い世代）
3. レポートファイル [`H:\マイドライブ\システムデータファイルバックアップ\最新バックアップ状況.md`](file:///H:/マイドライブ/システムデータファイルバックアップ/最新バックアップ状況.md) が最新日時で更新されていることを確認する。

---

## 4. バックアップからの復元手順（リストア時）

- **最新時点の単体ファイルを復元する場合**:
  - `H:\マイドライブ\システムデータファイルバックアップ\最新フルミラー\{湖南工場_共有DATA|国分工場_DATA}\` から該当ファイルを直接コピーする。
- **過去の日時世代（1〜14世代前）から復元する場合**:
  - `H:\マイドライブ\システムデータファイルバックアップ\世代バックアップ\{湖南工場_共有DATA|国分工場_DATA}\` 内の対象日時の `.zip` から該当ファイルを抽出する。
- **注意（絶対遵守）**:
  - 工場共有フォルダ側へ書き戻す際は、既存の現行ファイルを上書きする前に必ず退避コピー（または `pmd-control` MCP の `pmd_data_write_json_or_text(..., create_backup=True)`）を取ってから復元すること。

---

## 5. 定期実行 Automation 連携 (`factory-data-daily-backup`)

- **Automation 定義ファイル**: `C:\Users\0585\.gemini\config\sidecars\factory-data-daily-backup\sidecar.json`
- **表示名**: `湖南・国分工場 DATA 日次世代バックアップ`
- **スケジュール**: `CRON_TZ=Asia/Tokyo 0 18 * * *`（毎日 18:00 実行）
- スケジュールや保持世代数を変更する場合は上記 `sidecar.json` の `args` を更新し、`[Open Automations Dashboard](sidecar://dashboard)` から状態を確認する。
