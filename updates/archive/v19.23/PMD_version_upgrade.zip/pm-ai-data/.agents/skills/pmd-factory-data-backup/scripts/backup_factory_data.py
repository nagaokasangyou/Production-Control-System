# -*- coding: utf-8 -*-
"""
湖南工場（共有DATA）・国分工場（DATA） 定期バックアップ＆世代管理スクリプト
==========================================================================
保存先: H:\\マイドライブ\\システムデータファイルバックアップ

構成:
1. 最新フルミラー (`最新フルミラー/湖南工場_共有DATA`, `最新フルミラー/国分工場_DATA`)
   - `robocopy /MIR` により、不変アーカイブ (`dispatch-snapshots`, `summary-ai-dispatch-generations` 等) を含む
     全DATAファイルを差分同期し、エクスプローラーからいつでも即座に単体ファイルを復元可能にする
     （ポータブル実行バイナリ `PmAiRpaLuncher_portable` のみ除外設定可能）。
2. 日次世代バックアップ (`世代バックアップ/湖南工場_共有DATA/*.zip`, `世代バックアップ/国分工場_DATA/*.zip`)
   - 毎回の実行時に日時付きZIPアーカイブ (`KONAN_共有DATA_YYYYMMDD_HHMMSS.zip`, `KOKUBU_DATA_YYYYMMDD_HHMMSS.zip`) を作成。
   - マスタ (`master.xlsm`, `国分master.xlsm`, `master-dispatch-sheets.json`, `アラジンマスタ`)、
     カレンダー (`attendance-data.json`, `machine-calendar-data.json`, `勤怠カレンダー.xlsx`)、
     操作者・PIN・RDP設定 (`factory-operator-users.bin`, `*_RPA設定.ini`, `*_RDPスケジュール.json`, `RDP起動プロファイル.json`)、
     各種ルール・設定・日報・実績・TPI依頼書・履歴類をすべてZIP圧縮して保存。
   - 各工場につき直近 N 世代（既定: 14世代）を保持し、古い世代ZIPを自動削除（ローテーション）。
3. ステータスレポート出力 (`backup_status.json`, `最新バックアップ状況.md`)
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import subprocess
import sys
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

os.environ.setdefault("PYTHONIOENCODING", "utf-8")


@dataclass(frozen=True)
class FactoryBackupTarget:
    code: str
    folder_label: str
    display_name: str
    primary_dir: str
    fallback_unc_dir: str


TARGETS: tuple[FactoryBackupTarget, ...] = (
    FactoryBackupTarget(
        code="KONAN",
        folder_label="湖南工場_共有DATA",
        display_name="湖南工場 (共有DATA)",
        primary_dir=r"M:\湖南工場\湖南共有\002  加工G\●配台AIシステム\共有DATA",
        fallback_unc_dir=r"\\192.168.0.101\共有フォルダ\湖南工場\湖南共有\002  加工G\●配台AIシステム\共有DATA",
    ),
    FactoryBackupTarget(
        code="KOKUBU",
        folder_label="国分工場_DATA",
        display_name="国分工場 (DATA)",
        primary_dir=r"M:\国分工場\国分共有\●配台AIシステム\DATA",
        fallback_unc_dir=r"\\192.168.0.101\共有フォルダ\国分工場\国分共有\●配台AIシステム\DATA",
    ),
)

DEFAULT_DEST_ROOT = r"H:\マイドライブ\システムデータファイルバックアップ"
DEFAULT_KEEP_GENERATIONS = 14

# ポータブル実行環境バイナリ（1.8GBのJavaランタイム等）および
# 自体が過去スナップショット履歴である巨大フォルダ（計1.9GB）はGoogleドライブ圧迫防止のため既定で除外
# （マスタ・勤怠・機械カレンダー・PIN・設定・特別ルール・日報・実績・TPI依頼書・履歴等はすべて対象）
EXCLUDE_DIRS_DEFAULT = {
    "PmAiRpaLuncher_portable",
    "dispatch-snapshots",
    "summary-ai-dispatch-generations",
}
EXCLUDE_FILES_COMMON = {"PmAiRdpRemoteLauncher.exe", "Thumbs.db", "desktop.ini"}


def resolve_source_dir(target: FactoryBackupTarget) -> str:
    if os.path.isdir(target.primary_dir):
        return target.primary_dir
    if os.path.isdir(target.fallback_unc_dir):
        return target.fallback_unc_dir
    raise FileNotFoundError(
        f"{target.display_name} のソースフォルダにアクセスできません: "
        f"{target.primary_dir} / {target.fallback_unc_dir}"
    )


def run_incremental_mirror(src_dir: str, mirror_dir: str) -> dict[str, Any]:
    """robocopy による高速増分ミラーリング（変更があったファイルのみコピー）"""
    os.makedirs(mirror_dir, exist_ok=True)
    cmd = [
        "robocopy",
        src_dir,
        mirror_dir,
        "/MIR",
        "/FFT",
        "/R:2",
        "/W:2",
        "/MT:8",
        "/NP",
        "/NFL",
        "/NDL",
        "/XD",
        *sorted(EXCLUDE_DIRS_DEFAULT),
        "/XF",
        *sorted(EXCLUDE_FILES_COMMON),
        "*.save.lock",
        "~$*",
    ]
    t0 = time.time()
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="cp932", errors="replace")
    elapsed = round(time.time() - t0, 2)
    # robocopy return code < 8 means success
    ok = proc.returncode < 8
    return {
        "ok": ok,
        "returncode": proc.returncode,
        "elapsed_sec": elapsed,
        "mirror_dir": mirror_dir,
    }


def create_generation_zip(
    src_dir: str,
    gen_dir: str,
    factory_code: str,
    timestamp_str: str,
) -> dict[str, Any]:
    """世代管理用の日時付きZIPアーカイブを作成"""
    os.makedirs(gen_dir, exist_ok=True)
    zip_name = f"{factory_code}_DATA_{timestamp_str}.zip"
    zip_path = os.path.join(gen_dir, zip_name)
    tmp_zip_path = zip_path + ".tmp"

    file_count = 0
    raw_bytes = 0
    skipped_errors: list[str] = []
    t0 = time.time()

    with zipfile.ZipFile(tmp_zip_path, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root, dirs, files in os.walk(src_dir):
            # トップレベルおよびサブディレクトリの除外フィルタ
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS_DEFAULT]
            for fname in files:
                if fname in EXCLUDE_FILES_COMMON or fname.endswith(".save.lock") or fname.startswith("~$"):
                    continue
                full_path = os.path.join(root, fname)
                rel_path = os.path.relpath(full_path, src_dir)
                try:
                    st = os.stat(full_path)
                    zf.write(full_path, arcname=rel_path)
                    file_count += 1
                    raw_bytes += st.st_size
                except OSError as exc:
                    skipped_errors.append(f"{rel_path}: {exc}")

    if os.path.exists(zip_path):
        os.remove(zip_path)
    os.replace(tmp_zip_path, zip_path)

    zip_bytes = os.path.getsize(zip_path)
    elapsed = round(time.time() - t0, 2)
    return {
        "zip_name": zip_name,
        "zip_path": zip_path,
        "file_count": file_count,
        "raw_mb": round(raw_bytes / (1024 * 1024), 2),
        "zip_mb": round(zip_bytes / (1024 * 1024), 2),
        "elapsed_sec": elapsed,
        "skipped_errors": skipped_errors,
    }


def rotate_generations(gen_dir: str, factory_code: str, keep_generations: int) -> dict[str, Any]:
    """直近 keep_generations 世代を残し、古い世代ZIPを削除"""
    prefix = f"{factory_code}_DATA_"
    zips = []
    if os.path.isdir(gen_dir):
        for fname in os.listdir(gen_dir):
            if fname.startswith(prefix) and fname.endswith(".zip"):
                fpath = os.path.join(gen_dir, fname)
                try:
                    st = os.stat(fpath)
                    zips.append((fname, fpath, st.st_mtime, st.st_size))
                except OSError:
                    pass
    # ファイル名（YYYYMMDD_HHMMSS）順で新しい順にソート
    zips.sort(key=lambda x: x[0], reverse=True)
    kept = zips[:keep_generations]
    to_delete = zips[keep_generations:]

    deleted_files: list[str] = []
    for fname, fpath, _, _ in to_delete:
        try:
            os.remove(fpath)
            deleted_files.append(fname)
        except OSError:
            pass

    return {
        "kept_count": len(kept),
        "kept_generations": [
            {
                "name": fname,
                "size_mb": round(sz / (1024 * 1024), 2),
                "modified": datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S"),
            }
            for fname, _, mtime, sz in kept
        ],
        "deleted_count": len(deleted_files),
        "deleted_files": deleted_files,
    }


def write_status_reports(dest_root: str, summary: dict[str, Any]) -> None:
    json_path = os.path.join(dest_root, "backup_status.json")
    md_path = os.path.join(dest_root, "最新バックアップ状況.md")

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    lines = [
        "# 湖南工場・国分工場 DATA 定期バックアップ＆世代管理ステータス",
        "",
        f"- **最終実行日時**: `{summary['executed_at']}`",
        f"- **保存先ルート**: `{dest_root}`",
        f"- **世代保持上限**: 直近 **{summary['keep_generations']} 世代**",
        "",
        "## 各工場バックアップ結果",
        "",
    ]
    for f_res in summary["factories"]:
        status_icon = "OK" if f_res.get("ok") else "ERROR"
        lines.append(f"### [{status_icon}] {f_res['display_name']} (`{f_res['code']}`)")
        lines.append(f"- **コピー元**: `{f_res.get('source_dir', '')}`")
        if "mirror" in f_res:
            m = f_res["mirror"]
            lines.append(
                f"- **最新フルミラー**: `{m['mirror_dir']}` (robocopy code={m['returncode']}, {m['elapsed_sec']}秒)"
            )
        if "generation_zip" in f_res:
            z = f_res["generation_zip"]
            lines.append(
                f"- **今回作成世代ZIP**: `{z['zip_name']}` "
                f"({z['file_count']} ファイル / 元容量 {z['raw_mb']} MB -> 圧縮後 {z['zip_mb']} MB / {z['elapsed_sec']}秒)"
            )
        if "rotation" in f_res:
            r = f_res["rotation"]
            lines.append(
                f"- **保持世代数**: {r['kept_count']} / {summary['keep_generations']} 世代 "
                f"(今回自動削除: {r['deleted_count']} 件)"
            )
            lines.append("")
            lines.append("| 世代番号 | アーカイブ名 | 作成日時 | サイズ (MB) |")
            lines.append("|---:|---|---|---:|")
            for idx, g in enumerate(r["kept_generations"], start=1):
                lines.append(f"| {idx} | `{g['name']}` | {g['modified']} | {g['size_mb']} MB |")
        lines.append("")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def main() -> int:
    parser = argparse.ArgumentParser(description="湖南工場・国分工場 DATA 日次世代バックアップ")
    parser.add_argument("--dest", default=DEFAULT_DEST_ROOT, help="バックアップ先ルートフォルダ")
    parser.add_argument(
        "--keep",
        type=int,
        default=DEFAULT_KEEP_GENERATIONS,
        help="保持する世代数（デフォルト: 14）",
    )
    parser.add_argument(
        "--skip-mirror",
        action="store_true",
        help="最新フルミラー同期をスキップし世代ZIPのみ作成する",
    )
    args = parser.parse_args()

    dest_root = os.path.abspath(args.dest)
    os.makedirs(dest_root, exist_ok=True)

    now = datetime.datetime.now()
    timestamp_str = now.strftime("%Y%m%d_%H%M%S")

    summary: dict[str, Any] = {
        "executed_at": now.strftime("%Y-%m-%d %H:%M:%S"),
        "dest_root": dest_root,
        "keep_generations": args.keep,
        "all_ok": True,
        "factories": [],
    }

    for target in TARGETS:
        f_entry: dict[str, Any] = {
            "code": target.code,
            "display_name": target.display_name,
            "ok": False,
        }
        try:
            src_dir = resolve_source_dir(target)
            f_entry["source_dir"] = src_dir

            zip_src_dir = src_dir
            if not args.skip_mirror:
                mirror_dir = os.path.join(dest_root, "最新フルミラー", target.folder_label)
                mirror_res = run_incremental_mirror(src_dir, mirror_dir)
                f_entry["mirror"] = mirror_res
                if mirror_res.get("ok") and os.path.isdir(mirror_dir):
                    zip_src_dir = mirror_dir

            gen_dir = os.path.join(dest_root, "世代バックアップ", target.folder_label)
            zip_res = create_generation_zip(zip_src_dir, gen_dir, target.code, timestamp_str)
            f_entry["generation_zip"] = zip_res

            rot_res = rotate_generations(gen_dir, target.code, args.keep)
            f_entry["rotation"] = rot_res

            f_entry["ok"] = True
        except Exception as exc:
            f_entry["error"] = str(exc)
            summary["all_ok"] = False

        summary["factories"].append(f_entry)

    write_status_reports(dest_root, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["all_ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
