---
name: juchu-excel-form-column-mapping
description: >-
  Maps 受注ファイル（Excel「受注ﾌｧｲﾙ」シート）見出し行と依頼書フォーム項目の対応を設計・修正する方法論。
  列定義ウィザード、JuchuHeaderAliasRegistry、見出し行変更、REDEFINE/別名/除外の運用。
  Use when implementing or fixing 受注シート列定義, header mismatch, 転記/吸出し, masterBase列,
  JuchuSheetColumnLayout, JuchuSheetHeaderRepairWizard, or Excel↔フォーム列対応。
---

# 受注 Excel ↔ 依頼書フォーム列対応

## 設計思想（必読）

| 原則 | 内容 |
|------|------|
| **列位置は固定** | 転記・読込は `JuchuSheetColumnLayout.Col` の **列 index（A, AP, AQ…）** が正本。Excel 上で見出しが別列に移っても、**物理列位置は変えない**。 |
| **見出しは検証用** | 行3（既定）の見出し文字列は「その列に何と書いてあるか」の検証。不一致は警告・ウィザードで解消。 |
| **Excel を書き換えない** | 受注 xlsm の見出しセルをアプリから直書きしない。期待定義の上書き・別名・除外で吸収。 |
| **ファイル別設定** | 別名・期待上書き・除外・見出し行は **受注ファイル絶対パス** 単位で `JuchuHeaderAliasRegistry` に保存。 |
| **工場別永続化** | ユーザーホーム `~/.pm-ai-desktop/request-form-juchu-header-aliases_<工場>.properties`。出荷既定は `init_setting/juchu_header_aliases_<工場>.json`。 |

## 正本ファイル

| 役割 | パス |
|------|------|
| 列 enum・検証・読込 | `code_java/.../reconciliation/JuchuSheetColumnLayout.java` |
| 別名・期待上書き・見出し行 | `code_java/.../reconciliation/JuchuHeaderAliasRegistry.java` |
| ウィザード UI | `code_java/.../reconciliation/JuchuSheetHeaderRepairWizard.java` |
| 転記・読込・警告 | `code_java/.../reconciliation/ReconciliationApp.java` |
| 起動・レジストリ注入 | `RequestFormInputTabController.java`, `MainShellController.java` |
| init_setting パス | `InitSettingPaths.juchuHeaderAliasesFileForFactory` |

## 検証ロジック（`headerMatches`）

1. 列が **exclude** なら不一致収集から除外。
2. **`expected` override** あり: 実見出しが空 → OK。実見出し == override → OK。
3. 上記以外は **`Col.matchesHeader(actual, registry 別名)`**。
4. **REDEFINE** で実際の列見出しと採用見出しが異なるときは、実見出しを自動で `alias` 登録するロジックを維持する。

## 実装・変更チェックリスト

```
- [ ] 見出し行を読む箇所は registry.headerRowIndexFor(path) 経由か
- [ ] データ行走査は firstDataRow = headerRowIndex + 1 か
- [ ] REDEFINE で actual ≠ 採用見出しのとき alias 自動登録が維持されているか
- [ ] resolvePick が列文字で一意解決できるか（同見出し複数列）
- [ ] ComboBox が boundRow パターンか（getIndex() 直参照禁止）
- [ ] 永続化: properties / init_setting JSON export に headerRow が含まれるか
- [ ] テスト: JuchuSheetColumnLayoutTest, JuchuHeaderAliasRegistryHeaderRowTest, JuchuSheetHeaderRepairWizardResolvePickTest
- [ ] Excel 見出しセルの直書きを追加していないか
```

## 追加詳細

ファイル別キー形式・JSON 例・主要 API 一覧は [reference.md](./reference.md) を参照。
