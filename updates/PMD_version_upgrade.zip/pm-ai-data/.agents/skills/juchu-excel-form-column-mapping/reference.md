# 受注 Excel ↔ フォーム列対応 — リファレンス

## properties キー例（UTF-8）

```properties
# 工場既定見出し行（1-based）
@default|headerRow=3

# ファイル別見出し行
C\:\\data\\juchu.xlsm|headerRow=5

# 期待見出し上書き（AP = MASTER_BASE_SHOHIN_PRODUCT）
C\:\\data\\juchu.xlsm|expected|MASTER_BASE_SHOHIN_RAW=商品(原反)

# 別名（区切り \u0001）
C\:\\data\\juchu.xlsm|alias|MASTER_BASE_SHOHIN_PRODUCT=タイプ

# 転記除外
C\:\\data\\juchu.xlsm|exclude|IRO=1

# 未知列無視（列文字）
C\:\\data\\juchu.xlsm|ignored|BX=1
```

## init_setting JSON 例

```json
{
  "defaultHeaderRowOneBased": 3,
  "entries": {
    "C:\\data\\juchu.xlsm|headerRow": "5",
    "C:\\data\\juchu.xlsm|expected|MASTER_BASE_SHOHIN_PRODUCT": "商品(製品)",
    "C:\\data\\juchu.xlsm|alias|MASTER_BASE_SHOHIN_PRODUCT": "タイプ"
  }
}
```

## 主要 API 一覧

| API | 用途 |
|-----|------|
| `JuchuSheetColumnLayout.collectHeaderMismatches` | 不一致一覧 |
| `JuchuSheetColumnLayout.collectAllKnownColumns` | ウィザード既知列一覧 |
| `JuchuSheetColumnLayout.collectUnknownExcelColumns` | 定義外見出し |
| `JuchuSheetColumnLayout.readExcelHeaderPicks` | ComboBox 候補 |
| `JuchuSheetColumnLayout.headerMatches` | 1列の一致判定 |
| `JuchuSheetColumnLayout.resolveHeaderRowIndex` | 見出し行 0-based |
| `JuchuHeaderAliasRegistry.setExpectedOverride` | REDEFINE 保存 |
| `JuchuHeaderAliasRegistry.addAlias` | 別名追加 |
| `JuchuHeaderAliasRegistry.setHeaderRowOneBasedFor` | 見出し行 |
| `JuchuSheetHeaderRepairWizard.showTransferPrompt` | 転記前フロー |
| `JuchuSheetHeaderRepairWizard.resolvePick` | ComboBox → pick 解決 |
