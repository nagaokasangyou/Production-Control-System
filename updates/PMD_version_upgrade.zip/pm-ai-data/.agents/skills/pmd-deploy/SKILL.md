---
name: pmd-deploy
description: >-
  工程管理AIシステム（PMD）のビルド・バージョンアップ配備（デプロイ）を実行するスキル。
  ユーザーが「配備」「デプロイ」「リリース」「バージョンアップ配布」「GitHubへ配備」等を指示したときに使用する。
---

# PMD 配備（GitHub 差分アップデート専用配信）手順

工程管理AIデスクトップアプリ（PMD）の配備は、ワークスペース直下の [`publish_update.ps1`](../../publish_update.ps1) を実行し、**GitHub 公開リポジトリへのみ**一括配信する。
※社内共有フォルダ（湖南・国分 UNC パス）への配備は不要（実施しない）。

---

## 1. 標準配備コマンド（MCP ツールまたはワンコマンド実行）

`pmd-control` MCP サーバーが有効な場合は、以下の MCP ツール 1 回で配備できる：

- **PMD 本体配備**: `pmd_deploy_publish_update(component="pmd_main")`
- **PMD ユーザー監視ツール配備**: `pmd_deploy_publish_update(component="user_monitor")`

PowerShell から直接実行する場合は、ワークスペースルート（`c:\システム開発\工程管理AIプロジェクト_JAVA`）で以下を実行する：

```powershell
Set-Location 'c:\システム開発\工程管理AIプロジェクト_JAVA'
powershell -ExecutionPolicy Bypass -File .\publish_update.ps1
```

### オプションスイッチ（必要時のみ指定）
- `-SkipVersionBump`: `version.txt` がすでに手動更新済みのときに版数インクリメント（`+0.01`）をスキップする。
- `-SkipMavenBuild`: すでに最新の `code_java/target/production-control-desktop-0.1.0-SNAPSHOT.jar` がビルド済みのときに Maven ビルドをスキップする。
- `-SkipGitPush`: GitHub（`Production-Control-System`）へのプッシュをスキップし、ローカルのパッケージ生成のみ行う。

---

## 2. `publish_update.ps1` が自動実行する処理の全体像

1. **バージョン番号の更新（`version.txt`）**
   - `scripts/bump_version_txt.py` により `version.txt` を `+0.01` インクリメント（UTF-8 BOMなし）し、RDPランチャー用 `PmAiRdpRemoteLauncher.version.txt` も同期する。
2. **Java デスクトップ本体のビルド**
   - `code_java` で `mvn package -DskipTests` を実行し、`target/production-control-desktop-0.1.0-SNAPSHOT.jar` を生成する。
3. **差分アップデートZIPの生成（`updates/PMD_version_upgrade.zip`）**
   - **本体（`PMD.exe`、`runtime/`、`python-embed`、サードパーティ依存JAR、`code_java/` ソース）を一切含めない**差分更新専用ZIP（約32MB）を生成する。
   - スクリプト内の安全検査（Step 5）で `.exe` や `runtime/` が混入していないことを自動検証する。
4. **マニフェスト・バージョン情報の生成**
   - `version.txt`、`build-manifest.json`（JARのファイルサイズとSHA-256）、`version.json`（ZIPのSHA-256とダウンロードURL）を `updates/` に出力する。
5. **GitHub 公開リポジトリへの配備（社内共有フォルダへのコピーは行わない）**
   - `.tmp/public_updates_repo` にクリーンなリポジトリを初期化し、`README.md`・`.gitignore`・`updates/{version.txt, build-manifest.json, version.json, PMD_version_upgrade.zip}` のみをコミットして `https://github.com/hosokawanagaokasangyou-dotcom/Production-Control-System.git`（`main` ブランチ）へ `git push --force` する。

---

## 3. 配備後の検証チェックリスト

`publish_update.ps1` 実行後、以下が出力ログに含まれていることを確認してユーザーへ報告する：

1. `Bumped version.txt: <旧版> -> <新版>`
2. `Verified update-only ZIP (no main body / no .exe): ...\updates\PMD_version_upgrade.zip`
3. `=== Successfully published update v<新版> to https://github.com/hosokawanagaokasangyou-dotcom/Production-Control-System.git ===`

---

## 4. クライアント側の自動更新・ボタン発光仕様（参考）

- **起動時およびバックグラウンド定期チェック（3分周期）**:
  - [`MainShellController`](../../code_java/src/main/java/jp/co/pm/ai/desktop/MainShellController.java) が [`AppPaths.shouldUseGitHubUpdateSource`](../../code_java/src/main/java/jp/co/pm/ai/desktop/config/AppPaths.java) に従い GitHub（`https://raw.githubusercontent.com/hosokawanagaokasangyou-dotcom/Production-Control-System/main/updates`）の `version.txt` と `build-manifest.json` を確認する。
- **ツールバー左端「バージョンアップ」ボタン**:
  - 工場名の左隣にある [`shellVersionUpgradeButton`](../../code_java/src/main/java/jp/co/pm/ai/desktop/ui/ShellFactoryOperatorToolbar.java) が、新バージョン検出時に `✨ バージョンアップ (v旧 → v新)` へ切り替わり、ゴールドのグラデーション＋`DropShadow` で明滅発光する。
  - クリックすると即座にアップデートを取得・展開・ステージングし、アプリを再起動して最新版を適用する。
