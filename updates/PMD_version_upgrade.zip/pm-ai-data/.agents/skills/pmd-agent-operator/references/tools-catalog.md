# `pmd-control` MCP ツールカタログ & JavaFX ブリッジ仕様

実装正本:
- MCP サーバー: [`tools/pmd-mcp-server/pmd_mcp_server.py`](../../../../tools/pmd-mcp-server/pmd_mcp_server.py)
- JavaFX ブリッジ: [`PmdAgentBridgeServer.java`](../../../../code_java/src/main/java/jp/co/pm/ai/desktop/PmdAgentBridgeServer.java)

---

## 1. 全 27 ツール一覧

### A. JavaFX ライブ UI 操作（12 ツール）

| ツール名 | 用途 | 主な引数 |
|---|---|---|
| `pmd_ui_status` | 起動中アプリの工場・操作者・選択中タブ・版数・段階実行状態・ウィンドウ座標取得 | `app_kind` (`auto` / `desktop` / `rdp_launcher`) |
| `pmd_ui_launch` | PMD 本体または RDP ランチャーをバックグラウンド起動しブリッジ接続待機 | `app_kind`, `wait_seconds` |
| `pmd_ui_list_tabs` | 全タブの ID・日本語名・選択状態・無効化状態を取得 | `app_kind` |
| `pmd_ui_select_tab` | タブ切替（enum名・キー・日本語タイトルいずれも可） | `tab_id`, `app_kind` |
| `pmd_ui_inspect_tree` | 現在タブ（`active_tab`）または画面全体（`scene`）の JavaFX コントロール階層取得 | `scope`, `max_depth`, `only_visible` |
| `pmd_ui_interact` | ボタン押下・テキスト入力・チェック切替・コンボ選択・前面化 | `action`, `target`, `value`, `selected` |
| `pmd_ui_screenshot` | JavaFX `Scene.snapshot` による高精細 PNG スクリーンショット保存 | `output_path`, `app_kind` |
| `pmd_ui_get_logs` | 「実行・ログ」タブのライブログ取得 | `limit`, `contains` |
| `pmd_ui_get_env` | 「環境変数」タブの設定一覧取得 | `filter_keyword` |
| `pmd_ui_set_env` | 「環境変数」タブの指定キー更新 | `key`, `value` |
| `pmd_ui_switch_factory` | 起動中 PMD の工場切替（`KONAN` / `KOKUBU`） | `factory` |
| `pmd_ui_run_stage` | 起動中 PMD 上で `stage1` / `stage2` / `stage2_1` 実行開始または中断 | `stage`, `cancel` |

### B. 工場ユーザー稼働・内部エラー監視（3 ツール）

| ツール名 | 用途 | 主な引数 |
|---|---|---|
| `pmd_monitor_scan_snapshot` | 湖南・国分共有フォルダを増分スキャンし稼働・版数・エラー集計を返す | `lookback_days`, `factory_filter`, `force_version_check` |
| `pmd_monitor_list_errors` | 内部エラー・例外スタックトレース・直前操作付きの AI 診断レポート取得 | `lookback_days`, `factory_filter`, `operator_filter`, `min_severity` |
| `pmd_monitor_operator_timeline` | 指定操作者の時系列イベント履歴取得 | `operator`, `factory`, `lookback_days`, `limit` |

### C. 操作者 PIN・セッション・RDP 管理（6 ツール）

| ツール名 | 用途 | 主な引数 |
|---|---|---|
| `pmd_operator_list_pins` | `factory-operator-users.bin` の操作者一覧・PIN・ロック・管理者権限取得 | `factory` (`KONAN` / `KOKUBU` / `ALL`) |
| `pmd_operator_manage_pin` | PIN変更・ランダム再発行・ロック解除・管理者権限・追加/削除・バックアップ復元 | `action`, `factory`, `operator_name`, `pin`, `is_admin` |
| `pmd_session_list_active` | `operator-active-sessions` の複数 PC ログインリース一覧取得 | `factory`, `include_expired` |
| `pmd_session_release_lease` | 残存した操作者アクティブセッションのリース解放 | `factory`, `operator`, `host_name` |
| `pmd_rdp_inspect_profiles_and_schedules` | `RDP起動プロファイル.json`・`*_RDPスケジュール.json`・`launcher-*.log` 確認 | `factory`, `operator` |
| `pmd_rdp_update_operator_schedule` | 操作者別 RDP 定時スケジュール JSON のバックアップ付きアトミック更新 | `operator`, `master_schedule_enabled`, `tasks_json`, `factory` |

### D. データ照会・CLI 実行・単体テスト・GitHub 配備（6 ツール）

| ツール名 | 用途 | 主な引数 |
|---|---|---|
| `pmd_data_workspace_overview` | ローカル版数・`output/` 最新成果物・工場共有フォルダ疎通俯瞰 | なし |
| `pmd_data_query_dispatch_result` | `output/` の最新配台結果 JSON からキーワード・号機・日付でレコード抽出 | `json_path`, `keyword`, `machine_filter`, `date_filter`, `limit` |
| `pmd_data_write_json_or_text` | 設定/DATA ファイルのバックアップ付き更新（依頼書原本フォルダは書込拒否） | `file_path`, `content`, `validate_json`, `create_backup` |
| `pmd_pipeline_run_cli` | `task_extract_stage1.py` / `plan_simulation_stage2.py` 等の CLI 実行 | `script_name`, `factory`, `skip_gemini_api`, `extra_args_json` |
| `pmd_dev_run_tests` | Maven (`java_compile`, `java_test`) / pytest (`python_planning`, `python_monitor`) 実行 | `target`, `test_pattern`, `timeout_sec` |
| `pmd_deploy_publish_update` | `publish_update.ps1` または `publish_monitor_update.ps1` による GitHub 即時配備 | `component` (`pmd_main` / `user_monitor`), `skip_*` |

---

## 2. JavaFX ローカルブリッジ (`PmdAgentBridgeServer`) エンドポイント仕様

- バインド先: `127.0.0.1` のみ（外部ネットワーク非公開）
- 既定ポート: `PmAiFxApp` = `47822`、`RemoteDesktopFxApp` = `47823`（競合時は空きポートへ自動退避）
- ディスカバリファイル:
  - `~/.pm-ai-desktop/agent-bridge.json`
  - `~/.pm-ai-desktop-rdp/agent-bridge.json`
- エンドポイント:
  - `GET /status`
  - `GET /tabs`, `POST /tabs/select` (`{"tabId": "..."}`)
  - `GET /ui/tree?scope=active_tab&maxDepth=8&onlyVisible=true`
  - `POST /ui/action` (`{"action": "click|set_text|set_checkbox|set_combo|focus_window", "target": "...", "value": "..."}`)
  - `GET|POST /screenshot` (`{"outputPath": "..."}`)
  - `GET /logs?limit=200&contains=...`, `POST /logs/append`
  - `GET /env?filter=...`, `POST /env` (`{"key": "...", "value": "..."}`)
  - `POST /factory/switch` (`{"factory": "KONAN|KOKUBU"}`)
  - `POST /pipeline/run` (`{"stage": "stage1|stage2|stage2_1"}`), `POST /pipeline/cancel`
