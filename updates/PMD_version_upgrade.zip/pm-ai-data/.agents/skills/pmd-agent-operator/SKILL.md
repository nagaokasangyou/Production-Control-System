---
name: pmd-agent-operator
description: >-
  工程管理AIシステム（PMD）を `pmd-control` MCPサーバー経由で統合操作・監視・診断するスキル。
  起動中のJavaFXデスクトップ画面やRDPランチャーのライブ操作（タブ切替・ボタン押下・入力・スクリーンショット・ログ確認）、
  湖南/国分工場のユーザー稼働・内部エラー監視、操作者PIN・ロック解除・複数PC同時ログインセッション解放・RDP定時スケジュール変更、
  段階1/段階2シミュレーション実行、配台結果JSON・マスタ照会、共有DATA設定更新を行うときに使用する。
---

# PMD 統合エージェント操作ランブック（`pmd-control` MCP）

`pmd-control` MCPサーバー（全27ツール）を用いて、PMD の UI・工場監視・操作者/PIN/RDP管理・配台パイプラインを一元操作する手順書。
全ツールの引数・戻り値一覧と JavaFX ブリッジ仕様は [tools-catalog.md](./references/tools-catalog.md) を参照。

---

## 1. 絶対遵守ガードレール

- **依頼書原本フォルダ（`PM_AI_REQUEST_FORM_ORIGINAL_DIR`）は完全読み取り専用**:
  - 配下のファイル・サブフォルダに対する作成・上書き・リネーム・削除は厳禁（`pmd_data_write_json_or_text` でも自動ブロックされる）。
- **共有 DATA 更新時の安全確保**:
  - 湖南・国分工場の共有フォルダ配下を更新する際は `pmd_data_write_json_or_text(..., create_backup=True)` または `pmd_operator_manage_pin` を使い、`~/.pm-ai-desktop/mcp-backups` または `pin-store-backups` に世代バックアップを残す。

---

## 2. 起動中 JavaFX デスクトップ画面 / RDP ランチャーのライブ操作

`PmAiFxApp`（既定 `127.0.0.1:47822`）および `RemoteDesktopFxApp`（既定 `127.0.0.1:47823`）は起動時に `PmdAgentBridgeServer` を自動公開し、`~/.pm-ai-desktop/agent-bridge.json`（RDPは `~/.pm-ai-desktop-rdp/agent-bridge.json`）へ接続先を記録する。

### 標準操作フロー

1. **接続・状態確認**: `pmd_ui_status(app_kind="auto")` を呼び、工場・操作者・現在タブ・段階処理実行中フラグを確認する。
2. **未起動時の起動**: `running=false` の場合は `pmd_ui_launch(app_kind="desktop")`（RDP専用画面は `"rdp_launcher"`）でバックグラウンド起動し、ブリッジ応答まで自動待機する。
3. **工場・タブ切替**:
   - 工場切替: `pmd_ui_switch_factory(factory="KONAN")` または `"KOKUBU"`
   - タブ一覧/切替: `pmd_ui_list_tabs()` → `pmd_ui_select_tab(tab_id="equipmentGanttGraphic")`（`run` / `requestFormInput` / `dispatchInteractive` 等のキー、または `設備ガントチャート` / `実行・ログ` 等の日本語名どちらも指定可）
4. **画面コントロール検査・操作**:
   - `pmd_ui_inspect_tree(scope="active_tab")` で `fx:id` や表示ラベルを取得する。
   - `pmd_ui_interact(action="click" | "set_text" | "set_checkbox" | "set_combo" | "focus_window", target="...", value="...")` で操作する。
5. **視覚・ログ検証**:
   - `pmd_ui_screenshot()` で JavaFX `Scene.snapshot` PNG を保存し、`read_file` で画像を目視確認する。
   - `pmd_ui_get_logs(limit=200)` で「実行・ログ」タブの出力を確認する。

---

## 3. 湖南・国分工場のユーザー稼働監視・内部エラー診断フロー

1. **全体スナップショット取得**:
   - `pmd_monitor_scan_snapshot(lookback_days=7)` で湖南・国分両工場の疎通状況、最新配信版数と各操作者の利用版数、現在オンラインPC、本日の操作回数・エラー件数を一括把握する。
2. **内部エラー詳細と直前操作の特定**:
   - `pmd_monitor_list_errors(lookback_days=7, min_severity="error", include_ai_report=True)` を呼ぶ。
   - `aiDiagnosticReport` に含まれるスタックトレース・発生コード箇所・直前操作タイムラインをもとに原因箇所を特定する。
   - 必要に応じて `pmd_monitor_operator_timeline(operator="...", lookback_days=3)` で該当操作者の前後イベントを追跡する。
3. **修正・検証・配備**:
   - コード修正後、`pmd_dev_run_tests(target="java_test")` / `pmd_dev_run_tests(target="python_planning")` で回帰テストを通す。
   - 配備指示がある場合は `pmd_deploy_publish_update(component="pmd_main")`（監視ツール自身は `"user_monitor"`）を実行する。

---

## 4. 操作者 PIN・複数 PC セッション競合・RDP 定時スケジュール管理

- **PIN 確認・ロック解除・再発行・管理者付与**:
  1. `pmd_operator_list_pins(factory="KONAN")`（または `"KOKUBU"` / `"ALL"`）で登録者・ロック状態・失敗回数を確認する。
  2. `pmd_operator_manage_pin(action="unlock_pin" | "set_pin" | "reissue_random_pin" | "set_admin" | "add_user", factory="...", operator_name="...")` で更新する（自動世代バックアップ付き）。
- **複数 PC ログイン競合・残存リースの解放**:
  1. `pmd_session_list_active(factory="ALL", include_expired=True)` で `operator-active-sessions/<操作者>/<PC名>.json` のハートビート状態を確認する。
  2. クラッシュ等でリースが残っている場合は `pmd_session_release_lease(factory="...", operator="...", host_name="...")` で解放する。
- **RDP ランチャー設定・定時スケジュール変更**:
  1. `pmd_rdp_inspect_profiles_and_schedules(factory="KONAN")` で共有 `RDP起動プロファイル.json`・各操作者の `*_RDPスケジュール.json`・直近 `launcher-*.log` を確認する。
  2. `pmd_rdp_update_operator_schedule(operator="...", master_schedule_enabled=True, tasks_json='[...]')` で定時実行スケジュールを更新する。

---

## 5. 配台シミュレーション実行・結果分析

- **UI 経由で実行**: 起動中の PMD に対して `pmd_ui_run_stage(stage="stage1" | "stage2" | "stage2_1")` を呼び、`pmd_ui_get_logs()` で進捗を確認する。
- **ヘッドレス CLI で実行**: `pmd_pipeline_run_cli(script_name="task_extract_stage1.py" | "plan_simulation_stage2.py", factory="KONAN", skip_gemini_api=True)` で直接実行する。
- **成果物・配台レコード検索**:
  - `pmd_data_workspace_overview()` で `output/` 内の最新 JSON / Excel 成果物とタイムスタンプを確認する。
  - `pmd_data_query_dispatch_result(keyword="...", machine_filter="...", date_filter="...")` で最新の `計画*一覧.json` / `計画*設.json` から対象オーダーや設備割付を抽出する。
