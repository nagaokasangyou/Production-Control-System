---
name: pmd-windows-excel-github
description: >-
  Windowsデスクトップ上の外部アプリ（アラジン・mstscリモートデスクトップ・Explorer・ダイアログ等）のウィンドウ制御・UIAutomation操作・画面キャプチャ、
  Excelブック（`.xlsx` / `.xlsm`）の読取・編集・VBAマクロ実行、およびGitHub公開リポジトリ（`Production-Control-System` 等）の参照・操作を
  `windows-desktop` / `excel` / `github` MCPサーバー連携で行うときに使用する。
---

# Windows デスクトップ・Excel・GitHub MCP 連携スキル

Antigravity グローバル設定（`~/.gemini/config/mcp_config.json`）に登録済みの汎用・外部連携 MCP サーバー群を使い分ける実践ガイド。
※ PMD JavaFX 本体・工場監視・PIN/RDP設定の操作は [`pmd-agent-operator`](../pmd-agent-operator/SKILL.md)（`pmd-control` MCP）を優先する。

---

## 1. Windows デスクトップ画面・UIAutomation 操作（`windows-desktop` MCP）

実装正本: [`tools/pmd-mcp-server/windows_desktop_mcp_server.py`](../../../tools/pmd-mcp-server/windows_desktop_mcp_server.py)

1. **ウィンドウ特定・配置**:
   - `win_list_windows(title_filter="...")` で表示中ウィンドウの `hwnd`・PID・座標を取得する。
   - `win_manage_window(action="activate" | "maximize" | "restore" | "move_resize" | "minimize" | "close", hwnd=...)` で前面化やリサイズを行う。
2. **UI コントロール検査と自動操作**:
   - `win_uia_inspect(title_contains="...", max_depth=3)` で UIAutomation ツリー（`controlType`, `name`, `automationId`）を取得する。
   - `win_uia_interact(action="invoke" | "click_input" | "set_edit_text" | "type_keys", ...)` でボタン押下やテキスト入力を実行する。
3. **画面キャプチャ・クリップボード**:
   - `win_capture_screenshot(title_contains="...")` で対象ウィンドウまたは全画面 PNG を撮影し、`read_file` で視覚確認する。
   - `win_clipboard(action="read" | "write", text="...")` でクリップボード連携を行う。

---

## 2. Excel ブック操作・VBA マクロ連携（`windows-desktop` + `excel` MCP）

用途に応じて 2 系統の MCP ツールを使い分ける：

| やりたいこと | 推奨ツール | 備考 |
|---|---|---|
| シート構成・先頭行プレビュー・現在 Excel で開いているブック一覧確認 | `windows-desktop`: `excel_inspect_workbook` | `openpyxl` + `xlwings` 併用で高速 |
| `.xlsx` / `.xlsm` の指定範囲の値・数式読み取り | `windows-desktop`: `excel_read_range` または `excel`: `excel_read_sheet` | 読み取り専用で安全 |
| 書式変更・テーブル作成・シートコピー・Excel画面キャプチャ | `excel` (`@negokaz/excel-mcp-server`): `excel_write_to_sheet`, `excel_format_range`, `excel_screen_capture` 等 | 構造化編集に最適 |
| **起動中ブックへの COM 直接書込・`.xlsm` の VBA マクロ実行** | `windows-desktop`: `excel_live_write_or_macro` | `xlwings` 経由で `wb.macro(...)` 実行可 |

### Excel 操作時の重要ルール
- **`PM_AI_REQUEST_FORM_ORIGINAL_DIR`（依頼書原本フォルダ）配下の Excel ブックは変更厳禁**（`excel_live_write_or_macro` は `PermissionError` で自動遮断する）。
- **受注ファイル（`受注ﾌｧｲﾙ` シート）の見出しセルは直接書き換えない**。列ズレ・見出し不一致は [`juchu-excel-form-column-mapping`](../juchu-excel-form-column-mapping/SKILL.md) に従い `JuchuHeaderAliasRegistry` で吸収する。
- VBA モジュール（`code/VBA/`）を変更した場合は VBE 上でコンパイル確認を行う。

---

## 3. GitHub リポジトリ連携（`github` MCP）

ランチャー正本: [`tools/pmd-mcp-server/github_mcp_launcher.mjs`](../../../tools/pmd-mcp-server/github_mcp_launcher.mjs)
（`gh auth token` からログイン済みの GitHub CLI 認証トークンを実行時に動的取得するため、設定ファイル上に平文トークンを保持しない）

- **主な対象リポジトリ**:
  - 配信用公開リポジトリ: `hosokawanagaokasangyou-dotcom/Production-Control-System`（`updates/version.txt`, `updates/version.json`, `updates/build-manifest.json` 等）
- **注意**: PMD 本体や監視ツールのアップデート配信そのものは、手動の `push_files` ではなく必ず [`pmd-deploy`](../pmd-deploy/SKILL.md) の `publish_update.ps1` / `pmd_deploy_publish_update` ツールを使う（ZIP 安全検査・SHA-256 マニフェスト生成を通すため）。
