# -*- coding: utf-8 -*-
"""同一納期・同一工程・同一実機械では、先の試行順に残があるあいだ後続を載せない。"""
from datetime import date

from planning_core import _core as pc


DUE = date(2026, 5, 20)
DAY = date(2026, 5, 1)


def _row(tid, dto, *, due=DUE, process="SEC", machine_name="SEC機　湖南", remaining=4.0):
    return {
        "task_id": tid,
        "dispatch_trial_order": dto,
        "due_basis_date": due,
        "machine": process,
        "machine_name": machine_name,
        "remaining_units": remaining,
        "start_date_req": DAY,
    }


def _blocked(task, queue, min_order):
    return pc._task_blocked_by_global_dispatch_trial_order(
        task,
        queue,
        DAY,
        min_dispatch_effective=min_order,
    )


def test_later_same_machine_blocked_even_if_earlier_not_placeable_today():
    earlier = _row("A-1", 1, remaining=10.0)
    later = _row("B-2", 2, remaining=2.0)
    assert _blocked(later, [earlier, later], min_order=2) is True


def test_other_machine_is_not_held_for_same_due():
    earlier = _row("A-1", 1, machine_name="SEC機　湖南")
    later = _row("B-2", 2, machine_name="SEC機　国分")
    assert _blocked(later, [earlier, later], min_order=2) is False


def test_different_due_is_not_held():
    earlier = _row("A-1", 1, due=date(2026, 5, 21))
    later = _row("B-2", 2, due=DUE)
    assert _blocked(later, [earlier, later], min_order=2) is False


def test_different_process_on_same_machine_is_not_held():
    earlier = _row("A-1", 1, process="スリット")
    later = _row("B-2", 2, process="SEC")
    assert _blocked(later, [earlier, later], min_order=2) is False


def test_same_request_lines_do_not_block_each_other():
    first = _row("A-1", 1)
    second = _row("A-1", 2)
    assert _blocked(second, [first, second], min_order=2) is False


def test_finished_earlier_request_does_not_block():
    earlier = _row("A-1", 1, remaining=0.0)
    later = _row("B-2", 2, remaining=2.0)
    assert _blocked(later, [earlier, later], min_order=2) is False


def test_earlier_trial_itself_is_not_blocked():
    earlier = _row("A-1", 1, remaining=10.0)
    later = _row("B-2", 2, remaining=2.0)
    assert _blocked(earlier, [earlier, later], min_order=1) is False
