# -*- coding: utf-8 -*-
"""
PMD 工場ユーザー・エラー監視トレイ — GitHub 差分アップデーター
====================================================================
- 公開 GitHub リポジトリ (`updates/pmd-user-monitor/`) から軽量差分ZIP（Pythonモジュール・アイコンのみ、
  `.exe` / `.dll` / `.pyd` 等のバイナリ一切不含）を取得・SHA-256検証・アトミック展開する。
- Qt 非依存の純粋 Python モジュールのため単体テスト可能。
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import io
import json
import os
import re
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

from monitor_core import compare_versions

DEFAULT_PUBLIC_REPO = "nagaokasangyou/Production-Control-System"
LEGACY_PUBLIC_REPO = "hosokawanagaokasangyou-dotcom/Production-Control-System"

DEFAULT_MONITOR_GITHUB_BASE_URLS: tuple[str, ...] = (
    f"https://raw.githubusercontent.com/{DEFAULT_PUBLIC_REPO}/main/updates/pmd-user-monitor",
    f"https://raw.githubusercontent.com/{LEGACY_PUBLIC_REPO}/main/updates/pmd-user-monitor",
)

ENV_MONITOR_UPDATE_URL = "PMD_MONITOR_GITHUB_UPDATE_URL"
UPGRADE_ZIP_FILENAME = "PmdUserMonitor_upgrade.zip"

FORBIDDEN_ZIP_EXTENSIONS: tuple[str, ...] = (
    ".exe",
    ".dll",
    ".pyd",
    ".msi",
    ".bat",
    ".cmd",
    ".ps1",
    ".vbs",
    ".scr",
    ".com",
)

REQUIRED_ZIP_ENTRIES: tuple[str, ...] = (
    "monitor_version.txt",
    "monitor_core.py",
    "pmd_user_monitor.pyw",
)

VERSION_LINE_RE = re.compile(r"^\d+(?:\.\d+)+$")


@dataclass
class MonitorUpdateInfo:
    current_version: str
    remote_version: str
    update_available: bool
    download_url: str
    sha256: str
    released_at: str
    notes: str
    source_url: str
    checked_at_epoch: float
    error: str = ""


def read_local_monitor_version(app_dir: str, fallback: str = "1.00") -> str:
    """`app_dir/monitor_version.txt` から現在の監視ツールバージョンを読み取る。"""
    if app_dir:
        ver_path = os.path.join(app_dir, "monitor_version.txt")
        if os.path.isfile(ver_path):
            try:
                with open(ver_path, "r", encoding="utf-8-sig") as f:
                    line = f.readline().strip()
                if VERSION_LINE_RE.match(line):
                    return line
            except OSError:
                pass
    return fallback


def is_git_working_tree(path: str) -> bool:
    """対象パスが Git リポジトリ作業ツリー配下かどうかを返す（開発環境の誤上書き防止用）。"""
    if not path:
        return False
    cur = os.path.abspath(path)
    for _ in range(8):
        if os.path.exists(os.path.join(cur, ".git")):
            return True
        parent = os.path.dirname(cur)
        if not parent or parent == cur:
            break
        cur = parent
    return False


def normalize_github_update_url(url: str) -> str:
    if not url:
        return ""
    u = url.strip().rstrip("/")
    return u.replace(LEGACY_PUBLIC_REPO, DEFAULT_PUBLIC_REPO)


def _append_cache_buster(url: str) -> str:
    if not url:
        return url
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ("http", "https"):
        return url
    sep = "&" if parsed.query else "?"
    # 15秒粒度のキャッシュバスターを付与し、GitHub Raw CDN の古いキャッシュ取得を防ぐ
    return f"{url}{sep}cb={int(time.time() // 15)}"


def _http_get_bytes(url: str, timeout_sec: float = 6.0) -> bytes:
    req_url = _append_cache_buster(url)
    req = urllib.request.Request(
        req_url,
        headers={
            "User-Agent": "PmdUserMonitor-Updater/1.0",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
        return resp.read()


def resolve_candidate_base_urls(custom_base_url: str = "") -> list[str]:
    candidates: list[str] = []
    env_override = os.environ.get(ENV_MONITOR_UPDATE_URL, "").strip()
    for raw in (custom_base_url.strip(), env_override):
        if raw:
            norm = normalize_github_update_url(raw)
            if norm not in candidates:
                candidates.append(norm)
            raw_clean = raw.rstrip("/")
            if raw_clean not in candidates:
                candidates.append(raw_clean)
    for default_url in DEFAULT_MONITOR_GITHUB_BASE_URLS:
        if default_url not in candidates:
            candidates.append(default_url)
    return candidates


def check_github_differential_update(
    current_version: str,
    custom_base_url: str = "",
    timeout_sec: float = 6.0,
) -> MonitorUpdateInfo:
    """GitHub 公開アップデートリポジトリの `version.json` / `version.txt` を確認する。"""
    now = time.time()
    base_urls = resolve_candidate_base_urls(custom_base_url)
    last_error = ""

    for base_url in base_urls:
        ver_json_url = f"{base_url}/version.json"
        try:
            raw_bytes = _http_get_bytes(ver_json_url, timeout_sec=timeout_sec)
            payload = json.loads(raw_bytes.decode("utf-8-sig"))
            remote_ver = str(payload.get("version") or "").strip()
            if VERSION_LINE_RE.match(remote_ver):
                dl_url = str(payload.get("download_url") or "").strip()
                if not dl_url:
                    dl_url = f"{base_url}/{UPGRADE_ZIP_FILENAME}"
                sha256 = str(payload.get("sha256") or "").strip().upper()
                released_at = str(payload.get("released_at") or "").strip()
                notes = str(payload.get("notes") or "").strip()
                has_update = compare_versions(current_version, remote_ver) < 0
                return MonitorUpdateInfo(
                    current_version=current_version,
                    remote_version=remote_ver,
                    update_available=has_update,
                    download_url=dl_url,
                    sha256=sha256,
                    released_at=released_at,
                    notes=notes,
                    source_url=ver_json_url,
                    checked_at_epoch=now,
                )
        except Exception as exc:
            last_error = f"{ver_json_url}: {exc}"

        # フォールバック: version.txt
        ver_txt_url = f"{base_url}/version.txt"
        try:
            txt_bytes = _http_get_bytes(ver_txt_url, timeout_sec=timeout_sec)
            remote_ver = txt_bytes.decode("utf-8-sig", errors="replace").splitlines()[0].strip()
            if VERSION_LINE_RE.match(remote_ver):
                has_update = compare_versions(current_version, remote_ver) < 0
                return MonitorUpdateInfo(
                    current_version=current_version,
                    remote_version=remote_ver,
                    update_available=has_update,
                    download_url=f"{base_url}/{UPGRADE_ZIP_FILENAME}",
                    sha256="",
                    released_at="",
                    notes="",
                    source_url=ver_txt_url,
                    checked_at_epoch=now,
                )
        except Exception as exc:
            if not last_error:
                last_error = f"{ver_txt_url}: {exc}"

    return MonitorUpdateInfo(
        current_version=current_version,
        remote_version="",
        update_available=False,
        download_url="",
        sha256="",
        released_at="",
        notes="",
        source_url=base_urls[0] if base_urls else "",
        checked_at_epoch=now,
        error=last_error or "GitHub アップデート情報の取得に失敗しました。",
    )


def _validate_safe_relpath(entry_name: str) -> str:
    norm = entry_name.replace("\\", "/").strip("/")
    if not norm:
        return ""
    if norm.startswith("/") or ":" in norm:
        raise ValueError(f"不正な絶対パスエントリが検出されました: {entry_name}")
    parts = norm.split("/")
    if any(p in ("", ".", "..") for p in parts):
        raise ValueError(f"不正なパストラバーサルエントリが検出されました: {entry_name}")
    lower = norm.lower()
    if any(lower.endswith(ext) for ext in FORBIDDEN_ZIP_EXTENSIONS):
        raise ValueError(f"差分アップデート禁止対象のバイナリ/実行ファイルが含まれています: {entry_name}")
    return norm


def verify_and_stage_differential_zip(
    zip_bytes: bytes,
    expected_sha256: str,
    target_app_dir: str,
    backup_dir: str | None = None,
) -> tuple[str, list[str]]:
    """
    差分ZIPバイト列を SHA-256 検証・安全検査した上で `target_app_dir` へアトミック適用する。
    戻り値: `(適用後バージョン文字列, 更新された相対ファイル一覧)`
    """
    if not zip_bytes:
        raise ValueError("ダウンロードされた差分ZIPが空です。")

    actual_sha = hashlib.sha256(zip_bytes).hexdigest().upper()
    exp_clean = (expected_sha256 or "").strip().upper()
    if exp_clean and actual_sha != exp_clean:
        raise ValueError(
            f"差分ZIPの SHA-256 ハッシュが一致しません（期待={exp_clean[:16]}..., 実際={actual_sha[:16]}...）。"
        )

    target_abs = os.path.abspath(target_app_dir)
    parent_dir = os.path.dirname(target_abs)
    os.makedirs(target_abs, exist_ok=True)

    staging_dir = os.path.join(parent_dir, f"app_staging_{os.getpid()}_{int(time.time() * 1000)}")
    if os.path.exists(staging_dir):
        shutil.rmtree(staging_dir, ignore_errors=True)
    os.makedirs(staging_dir, exist_ok=True)

    extracted_files: list[str] = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                rel = _validate_safe_relpath(info.filename)
                if not rel:
                    continue
                dest_path = os.path.join(staging_dir, *rel.split("/"))
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                with zf.open(info, "r") as src, open(dest_path, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                extracted_files.append(rel)

        extracted_set = set(extracted_files)
        missing = [req for req in REQUIRED_ZIP_ENTRIES if req not in extracted_set]
        if missing:
            raise ValueError(f"差分ZIPに必須ファイルが含まれていません: {', '.join(missing)}")

        staged_ver = read_local_monitor_version(staging_dir, fallback="")
        if not staged_ver:
            raise ValueError("差分ZIP内の monitor_version.txt が不正または読み取れません。")

        # バックアップ作成（ロールバック用）
        resolved_backup = backup_dir or os.path.join(parent_dir, "app_backup")
        if os.path.abspath(resolved_backup) != target_abs:
            os.makedirs(resolved_backup, exist_ok=True)
            for rel in extracted_files:
                cur_file = os.path.join(target_abs, *rel.split("/"))
                if os.path.isfile(cur_file):
                    bak_file = os.path.join(resolved_backup, *rel.split("/"))
                    os.makedirs(os.path.dirname(bak_file), exist_ok=True)
                    shutil.copy2(cur_file, bak_file)

        # ステージングから本番 app_dir へ上書き反映（Pythonスクリプトは実行中でもロックされない）
        for rel in extracted_files:
            staged_file = os.path.join(staging_dir, *rel.split("/"))
            dest_file = os.path.join(target_abs, *rel.split("/"))
            os.makedirs(os.path.dirname(dest_file), exist_ok=True)
            tmp_dest = dest_file + f".upd_{os.getpid()}"
            shutil.copy2(staged_file, tmp_dest)
            os.replace(tmp_dest, dest_file)

        return staged_ver, sorted(extracted_files)
    finally:
        shutil.rmtree(staging_dir, ignore_errors=True)


def download_and_apply_differential_update(
    update_info: MonitorUpdateInfo,
    target_app_dir: str,
    custom_base_url: str = "",
    backup_dir: str | None = None,
    timeout_sec: float = 20.0,
) -> tuple[str, list[str]]:
    """GitHub から差分ZIPをダウンロードし、検証・ステージング・適用を行う。"""
    candidate_urls: list[str] = []
    if update_info.download_url:
        norm_dl = normalize_github_update_url(update_info.download_url)
        if norm_dl not in candidate_urls:
            candidate_urls.append(norm_dl)
        if update_info.download_url not in candidate_urls:
            candidate_urls.append(update_info.download_url)

    for base in resolve_candidate_base_urls(custom_base_url):
        fallback_zip = f"{base}/{UPGRADE_ZIP_FILENAME}"
        if fallback_zip not in candidate_urls:
            candidate_urls.append(fallback_zip)

    zip_bytes = b""
    last_err: Exception | None = None
    for url in candidate_urls:
        try:
            zip_bytes = _http_get_bytes(url, timeout_sec=timeout_sec)
            if zip_bytes:
                break
        except Exception as exc:
            last_err = exc

    if not zip_bytes:
        raise RuntimeError(f"差分アップデートZIPのダウンロードに失敗しました: {last_err}")

    return verify_and_stage_differential_zip(
        zip_bytes=zip_bytes,
        expected_sha256=update_info.sha256,
        target_app_dir=target_app_dir,
        backup_dir=backup_dir,
    )
