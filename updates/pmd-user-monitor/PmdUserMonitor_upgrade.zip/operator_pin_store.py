# -*- coding: utf-8 -*-
"""
PMD 工場別操作者・PIN管理ストア (`factory-operator-users.bin` 読み書き互換モジュール)
====================================================================================
Java 側 `jp.co.pm.ai.desktop.config.FactoryOperatorUserStore` (`PMOU` バイナリ形式 v1 / schemaVersion=8)
および `FactoryOperatorUserBackupStore` と 100% 互換の読み書き・バックアップ・PIN管理を提供する。

重要な安全設計:
- 保存時は既存の全フィールド（他工場データ・`rdpDepartments`・`aladdinLoginIds`・`aladdinPasswordCiphertext` 等）
  を一切欠落させずに保持する。
- 更新前には必ずローカル退避フォルダおよび共有 `factory-operator-users-backups/`（Java世代管理互換）へ
  自動バックアップを作成した上で、一時ファイル経由のアトミック置換 (`os.replace`) を行う。
"""
from __future__ import annotations

from dataclasses import dataclass
import datetime
import hashlib
import json
import os
import shutil
import struct
import time
import unicodedata
import uuid
from typing import Any

try:
    import secrets as _secrets
except ImportError:  # pragma: no cover
    _secrets = None  # type: ignore[assignment]

PMOU_MAGIC = b"PMOU"
PMOU_FORMAT_VERSION = 1
SCHEMA_VERSION = 8

MIN_PIN_LENGTH = 4
MAX_PIN_LENGTH = 10
MAX_CONSECUTIVE_PIN_FAILURES = 20
MAX_NAMES_PER_FACTORY = 50
MAX_NAME_LENGTH = 40

GUEST_OPERATOR_NAME = "ゲスト"
DEFAULT_RDP_DEPARTMENT_LABEL = "既定"
DEFAULT_KONAN_NAMES: tuple[str, ...] = ("砂田", "古家", "図司", "細川")

BACKUP_DIR_NAME = "factory-operator-users-backups"
MAX_SHARED_BACKUPS = 30
MAX_LOCAL_BACKUPS = 50

FACTORY_LABELS_JA: dict[str, str] = {
    "KONAN": "湖南工場",
    "KOKUBU": "国分工場",
    "RDP_LAUNCHER": "RDPランチャー",
}


@dataclass
class OperatorPinRecord:
    factory_code: str
    factory_label: str
    name: str
    has_pin: bool
    pin_plaintext: str
    failed_attempts: int
    is_locked: bool
    must_change: bool
    is_admin: bool
    aladdin_login_id: str
    has_aladdin_password: bool
    store_path: str

    @property
    def pin_status_ja(self) -> str:
        if self.is_locked:
            return f"🔒 ロック中 ({self.failed_attempts}回失敗)"
        if self.must_change:
            if self.failed_attempts > 0:
                return f"🆕 初回変更待 (失敗{self.failed_attempts}回)"
            return "🆕 初回変更待"
        if self.has_pin:
            if self.failed_attempts > 0:
                return f"⚠️ 設定済 (失敗{self.failed_attempts}回)"
            return "✅ 設定済"
        return "⚪ 未設定"

    @property
    def pin_display_text(self) -> str:
        if self.pin_plaintext:
            return self.pin_plaintext
        if self.has_pin:
            return "（平文未記録・再設定可）"
        return "—"


@dataclass
class PinBackupEntry:
    backup_id: str
    label: str
    created_at_ms: int
    folder_name: str
    created_by: str
    bin_path: str

    @property
    def created_at_display(self) -> str:
        if self.created_at_ms <= 0:
            return "-"
        dt = datetime.datetime.fromtimestamp(self.created_at_ms / 1000.0)
        return dt.strftime("%Y-%m-%d %H:%M:%S")


def normalize_operator_name(raw: str | None) -> str:
    if not raw:
        return ""
    t = raw.strip()
    if len(t) > MAX_NAME_LENGTH:
        t = t[:MAX_NAME_LENGTH]
    return t


def is_guest_operator(name: str | None) -> bool:
    return normalize_operator_name(name) == GUEST_OPERATOR_NAME


def normalize_pin(raw: str | None) -> str | None:
    """
    全角数字（０-９）も半角 ASCII 数字へ正規化した上で、4～10桁の数字であることを検証する。
    不正な場合は None を返す。
    """
    if raw is None:
        return None
    norm = unicodedata.normalize("NFKC", str(raw)).strip()
    if len(norm) < MIN_PIN_LENGTH or len(norm) > MAX_PIN_LENGTH:
        return None
    if not (norm.isascii() and norm.isdigit()):
        return None
    return norm


def _secure_randbelow(upper: int) -> int:
    if _secrets is not None:
        return _secrets.randbelow(upper)
    limit = (1 << 64) - ((1 << 64) % upper)
    while True:
        val = int.from_bytes(os.urandom(8), "big")
        if val < limit:
            return val % upper


def generate_random_pin(digits: int = 4) -> str:
    d = max(MIN_PIN_LENGTH, min(MAX_PIN_LENGTH, int(digits)))
    val = _secure_randbelow(10**d)
    return f"{val:0{d}d}"


def compute_pin_hash(factory_code: str, operator_name: str, pin: str) -> str:
    """
    `FactoryOperatorUserStore.hashPin` と完全同一の SHA-256 ハッシュ（小文字16進64文字）を計算する。
    payload = `<FactorySite.name()>|<normalizeName(name)>|<pin>`
    """
    norm_name = normalize_operator_name(operator_name)
    pin_norm = normalize_pin(pin)
    if pin_norm is None:
        raise ValueError(f"PIN は {MIN_PIN_LENGTH}～{MAX_PIN_LENGTH}桁の数字で指定してください。")
    payload = f"{factory_code.strip().upper()}|{norm_name}|{pin_norm}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def decode_pmou_bytes(raw: bytes) -> dict[str, Any]:
    if not raw:
        raise ValueError("ユーザー管理ファイルが空です。")
    if len(raw) >= 10 and raw[:4] == PMOU_MAGIC:
        fmt_ver, payload_len = struct.unpack(">HI", raw[4:10])
        if fmt_ver != PMOU_FORMAT_VERSION:
            raise ValueError(f"未対応の PMOU バイナリ形式バージョンです: formatVersion={fmt_ver}")
        if payload_len < 0 or len(raw) - 10 < payload_len:
            raise ValueError("PMOU バイナリファイルのペイロード長が破損しています。")
        json_text = raw[10 : 10 + payload_len].decode("utf-8")
    else:
        json_text = raw.decode("utf-8-sig")

    doc = json.loads(json_text)
    if not isinstance(doc, dict):
        raise ValueError("ユーザー管理データのルートが JSON オブジェクトではありません。")
    schema_ver = int(doc.get("schemaVersion") or 1)
    if schema_ver > SCHEMA_VERSION:
        raise ValueError(
            f"より新しいスキーマバージョンのファイルです (schemaVersion={schema_ver} > {SCHEMA_VERSION})。"
        )
    return doc


def encode_pmou_bytes(doc: dict[str, Any]) -> bytes:
    out_doc = dict(doc)
    out_doc["schemaVersion"] = max(int(out_doc.get("schemaVersion") or SCHEMA_VERSION), SCHEMA_VERSION)
    payload = json.dumps(out_doc, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    header = PMOU_MAGIC + struct.pack(">HI", PMOU_FORMAT_VERSION, len(payload))
    return header + payload


def _ensure_factory_dict(doc: dict[str, Any], factory_code: str) -> dict[str, Any]:
    fcode = factory_code.strip().upper()
    factories = doc.setdefault("factories", {})
    if not isinstance(factories, dict):
        factories = {}
        doc["factories"] = factories

    fnode = factories.get(fcode)
    if not isinstance(fnode, dict):
        fnode = {}
        factories[fcode] = fnode

    raw_names = fnode.get("names")
    names: list[str] = []
    if isinstance(raw_names, list):
        for item in raw_names:
            if isinstance(item, str):
                nm = normalize_operator_name(item)
                if nm and nm not in names:
                    names.append(nm)
    if not names and fcode in ("KONAN", "KOKUBU"):
        names = list(DEFAULT_KONAN_NAMES)
    fnode["names"] = names
    fnode["lastSelected"] = ""

    for map_key in (
        "pinHashes",
        "pinFailedAttempts",
        "pinPlaintextAdmin",
        "aladdinLoginIds",
        "aladdinPasswordCiphertext",
    ):
        if not isinstance(fnode.get(map_key), dict):
            fnode[map_key] = {}

    for arr_key in ("pinMustChange", "adminOperatorNames"):
        if not isinstance(fnode.get(arr_key), list):
            fnode[arr_key] = []

    if "rdpDepartmentOrder" not in doc or not isinstance(doc.get("rdpDepartmentOrder"), list):
        doc["rdpDepartmentOrder"] = [DEFAULT_RDP_DEPARTMENT_LABEL]
    if "rdpDepartments" not in doc or not isinstance(doc.get("rdpDepartments"), dict):
        doc["rdpDepartments"] = {
            DEFAULT_RDP_DEPARTMENT_LABEL: {
                "names": [],
                "lastSelected": "",
                "pinHashes": {},
                "pinFailedAttempts": {},
                "pinMustChange": [],
                "pinPlaintextAdmin": {},
                "aladdinLoginIds": {},
                "aladdinPasswordCiphertext": {},
                "adminOperatorNames": [],
            }
        }
    return fnode


def _sanitize_factory_dict_in_place(fnode: dict[str, Any]) -> None:
    """Java `serializeFactoryUsers` と同様に、`names` に含まれる操作者キーのみ整合維持する。"""
    names: list[str] = []
    for nm in fnode.get("names", []):
        norm = normalize_operator_name(nm)
        if norm and norm not in names:
            names.append(norm)
    fnode["names"] = names
    fnode["lastSelected"] = ""
    name_set = set(names)

    pin_hashes = {
        k: str(v).strip()
        for k, v in (fnode.get("pinHashes") or {}).items()
        if k in name_set and str(v).strip()
    }
    fnode["pinHashes"] = pin_hashes

    attempts: dict[str, int] = {}
    for k, v in (fnode.get("pinFailedAttempts") or {}).items():
        if k in name_set:
            try:
                cnt = int(v)
                if cnt > 0:
                    attempts[k] = cnt
            except (TypeError, ValueError):
                pass
    fnode["pinFailedAttempts"] = attempts

    must_change: list[str] = []
    for nm in fnode.get("pinMustChange") or []:
        norm = normalize_operator_name(nm)
        if norm in name_set and norm not in must_change:
            must_change.append(norm)
    fnode["pinMustChange"] = must_change

    plain_admin: dict[str, str] = {}
    for k, v in (fnode.get("pinPlaintextAdmin") or {}).items():
        if k in name_set:
            p = normalize_pin(str(v))
            if p is not None:
                plain_admin[k] = p
    fnode["pinPlaintextAdmin"] = plain_admin

    aladdin_ids = {
        k: str(v).strip()
        for k, v in (fnode.get("aladdinLoginIds") or {}).items()
        if k in name_set and str(v).strip()
    }
    fnode["aladdinLoginIds"] = aladdin_ids

    aladdin_pw = {
        k: str(v).strip()
        for k, v in (fnode.get("aladdinPasswordCiphertext") or {}).items()
        if k in name_set and str(v).strip()
    }
    fnode["aladdinPasswordCiphertext"] = aladdin_pw

    admins: list[str] = []
    for nm in fnode.get("adminOperatorNames") or []:
        norm = normalize_operator_name(nm)
        if norm in name_set and not is_guest_operator(norm) and norm not in admins:
            admins.append(norm)
    fnode["adminOperatorNames"] = admins


def read_document_from_file(store_path: str) -> dict[str, Any]:
    with open(store_path, "rb") as f:
        raw = f.read()
    return decode_pmou_bytes(raw)


def load_factory_pin_records(factory_code: str, store_path: str) -> list[OperatorPinRecord]:
    """指定工場の `factory-operator-users.bin` から全操作者のPIN・権限・ロック状態を読み取る。"""
    fcode = factory_code.strip().upper()
    flabel = FACTORY_LABELS_JA.get(fcode, fcode)
    if not store_path or not os.path.isfile(store_path):
        return []

    doc = read_document_from_file(store_path)
    fnode = _ensure_factory_dict(doc, fcode)

    names = fnode.get("names") or []
    pin_hashes = fnode.get("pinHashes") or {}
    attempts = fnode.get("pinFailedAttempts") or {}
    must_change_set = set(fnode.get("pinMustChange") or [])
    plain_map = fnode.get("pinPlaintextAdmin") or {}
    aladdin_ids = fnode.get("aladdinLoginIds") or {}
    aladdin_pws = fnode.get("aladdinPasswordCiphertext") or {}
    admin_set = set(fnode.get("adminOperatorNames") or [])

    records: list[OperatorPinRecord] = []
    for raw_name in names:
        nm = normalize_operator_name(raw_name)
        if not nm or is_guest_operator(nm):
            continue
        h = str(pin_hashes.get(nm) or "").strip()
        plain = normalize_pin(plain_map.get(nm)) or ""
        fail_cnt = 0
        try:
            fail_cnt = max(0, int(attempts.get(nm) or 0))
        except (TypeError, ValueError):
            fail_cnt = 0
        aid = str(aladdin_ids.get(nm) or "").strip()
        apw = str(aladdin_pws.get(nm) or "").strip()

        records.append(
            OperatorPinRecord(
                factory_code=fcode,
                factory_label=flabel,
                name=nm,
                has_pin=bool(h),
                pin_plaintext=plain,
                failed_attempts=fail_cnt,
                is_locked=(fail_cnt >= MAX_CONSECUTIVE_PIN_FAILURES),
                must_change=(nm in must_change_set),
                is_admin=(nm in admin_set),
                aladdin_login_id=aid,
                has_aladdin_password=bool(apw),
                store_path=store_path,
            )
        )
    return records


def _get_local_backup_dir() -> str:
    base = os.path.join(
        os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
        "PmdUserMonitor",
        "pin_store_backups",
    )
    os.makedirs(base, exist_ok=True)
    return base


def create_store_backup(
    store_path: str,
    label: str = "",
    admin_actor: str = "監視ツール管理者",
    local_backup_dir: str | None = None,
) -> PinBackupEntry | None:
    """
    `factory-operator-users.bin` 更新前に、ローカル退避と共有 `factory-operator-users-backups/`
    （Java `FactoryOperatorUserBackupStore` 互換フォーマット）の両方へバックアップを作成する。
    """
    if not store_path or not os.path.isfile(store_path):
        return None

    abs_store = os.path.abspath(store_path)
    bin_basename = os.path.basename(abs_store)
    now_ms = int(time.time() * 1000)
    ts_str = datetime.datetime.fromtimestamp(now_ms / 1000.0).strftime("%Y%m%d-%H%M%S")

    # 1. ローカルPC退避コピー
    try:
        loc_dir = local_backup_dir or _get_local_backup_dir()
        os.makedirs(loc_dir, exist_ok=True)
        loc_name = f"{ts_str}_{uuid.uuid4().hex[:6]}_{bin_basename}"
        shutil.copy2(abs_store, os.path.join(loc_dir, loc_name))
        existing_local = sorted(
            [os.path.join(loc_dir, f) for f in os.listdir(loc_dir) if f.endswith(".bin")],
            key=lambda p: os.path.getmtime(p),
            reverse=True,
        )
        for old_p in existing_local[MAX_LOCAL_BACKUPS:]:
            try:
                os.remove(old_p)
            except OSError:
                pass
    except OSError:
        pass

    # 2. 共有フォルダ側 Java 互換世代バックアップ (`factory-operator-users-backups/`)
    parent_dir = os.path.dirname(abs_store)
    backups_root = os.path.join(parent_dir, BACKUP_DIR_NAME)
    backup_id = uuid.uuid4().hex
    folder_name = f"backup-{backup_id}"
    entry_dir = os.path.join(backups_root, folder_name)
    resolved_label = label.strip() if label and label.strip() else f"{ts_str} 自動バックアップ ({admin_actor})"

    os.makedirs(entry_dir, exist_ok=True)
    dest_bin = os.path.join(entry_dir, bin_basename)
    shutil.copy2(abs_store, dest_bin)

    index_path = os.path.join(backups_root, "index.json")
    entries_raw: list[dict[str, Any]] = []
    if os.path.isfile(index_path):
        try:
            with open(index_path, "r", encoding="utf-8-sig") as f:
                idx_obj = json.load(f)
            if isinstance(idx_obj, dict) and isinstance(idx_obj.get("entries"), list):
                entries_raw = [e for e in idx_obj["entries"] if isinstance(e, dict) and e.get("id")]
        except Exception:
            entries_raw = []

    max_existing_ms = max((int(e.get("createdAtMillis") or 0) for e in entries_raw), default=0)
    effective_ms = max(now_ms, max_existing_ms + 1)

    manifest_obj = {
        "id": backup_id,
        "label": resolved_label,
        "createdAtMillis": effective_ms,
        "createdByOperator": admin_actor,
        "sourcePath": abs_store,
    }
    with open(os.path.join(entry_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest_obj, f, ensure_ascii=False, indent=2)

    new_idx_item = {
        "id": backup_id,
        "label": resolved_label,
        "createdAtMillis": effective_ms,
        "folderName": folder_name,
        "createdByOperator": admin_actor,
    }
    entries_raw.append(new_idx_item)
    entries_raw.sort(key=lambda x: int(x.get("createdAtMillis") or 0), reverse=True)

    kept = entries_raw[:MAX_SHARED_BACKUPS]
    removed = entries_raw[MAX_SHARED_BACKUPS:]
    for rem in removed:
        rem_folder = str(rem.get("folderName") or rem.get("id") or "").strip()
        if rem_folder:
            shutil.rmtree(os.path.join(backups_root, rem_folder), ignore_errors=True)

    tmp_idx = index_path + f".tmp_{os.getpid()}"
    with open(tmp_idx, "w", encoding="utf-8") as f:
        json.dump({"entries": kept}, f, ensure_ascii=False, indent=2)
    os.replace(tmp_idx, index_path)

    return PinBackupEntry(
        backup_id=backup_id,
        label=resolved_label,
        created_at_ms=effective_ms,
        folder_name=folder_name,
        created_by=admin_actor,
        bin_path=dest_bin,
    )


def list_store_backups(store_path: str) -> list[PinBackupEntry]:
    if not store_path:
        return []
    abs_store = os.path.abspath(store_path)
    bin_basename = os.path.basename(abs_store)
    backups_root = os.path.join(os.path.dirname(abs_store), BACKUP_DIR_NAME)
    index_path = os.path.join(backups_root, "index.json")
    if not os.path.isfile(index_path):
        return []
    try:
        with open(index_path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        out: list[PinBackupEntry] = []
        for item in data.get("entries") or []:
            if not isinstance(item, dict):
                continue
            bid = str(item.get("id") or "").strip()
            if not bid:
                continue
            folder = str(item.get("folderName") or bid).strip()
            bpath = os.path.join(backups_root, folder, bin_basename)
            if os.path.isfile(bpath):
                out.append(
                    PinBackupEntry(
                        backup_id=bid,
                        label=str(item.get("label") or bid),
                        created_at_ms=int(item.get("createdAtMillis") or 0),
                        folder_name=folder,
                        created_by=str(item.get("createdByOperator") or ""),
                        bin_path=bpath,
                    )
                )
        out.sort(key=lambda e: e.created_at_ms, reverse=True)
        return out
    except Exception:
        return []


def _atomic_write_document(
    store_path: str,
    doc: dict[str, Any],
    backup_label: str,
    admin_actor: str = "監視ツール管理者",
) -> None:
    abs_store = os.path.abspath(store_path)
    parent = os.path.dirname(abs_store)
    os.makedirs(parent, exist_ok=True)

    if os.path.isfile(abs_store):
        create_store_backup(abs_store, label=backup_label, admin_actor=admin_actor)

    encoded = encode_pmou_bytes(doc)
    # 書込データの自己検証デコードテストを行ってから本番ファイルへ置換
    decode_pmou_bytes(encoded)

    tmp_path = f"{abs_store}.tmp_{os.getpid()}_{int(time.time() * 1000)}"
    try:
        with open(tmp_path, "wb") as f:
            f.write(encoded)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, abs_store)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def restore_store_from_backup(
    store_path: str,
    backup_bin_path: str,
    admin_actor: str = "監視ツール管理者",
) -> None:
    if not os.path.isfile(backup_bin_path):
        raise FileNotFoundError(f"バックアップファイルが見つかりません: {backup_bin_path}")
    with open(backup_bin_path, "rb") as f:
        raw = f.read()
    doc = decode_pmou_bytes(raw)
    _atomic_write_document(
        store_path=store_path,
        doc=doc,
        backup_label="バックアップ復元前の自動退避",
        admin_actor=admin_actor,
    )


def set_operator_pin(
    store_path: str,
    factory_code: str,
    operator_name: str,
    new_pin: str,
    require_change_on_login: bool = False,
    admin_actor: str = "監視ツール管理者",
) -> str:
    """指定ユーザーのPINを設定・変更し、ロック/失敗回数をリセットして保存する。"""
    fcode = factory_code.strip().upper()
    norm_name = normalize_operator_name(operator_name)
    if not norm_name or is_guest_operator(norm_name):
        raise ValueError("対象ユーザー名が不正です（ゲストにはPINを設定できません）。")

    pin_norm = normalize_pin(new_pin)
    if pin_norm is None:
        raise ValueError(f"PIN は {MIN_PIN_LENGTH}～{MAX_PIN_LENGTH}桁の数字（0〜9）で入力してください。")

    doc = read_document_from_file(store_path)
    fnode = _ensure_factory_dict(doc, fcode)
    if norm_name not in fnode["names"]:
        raise ValueError(f"ユーザー「{norm_name}」は {FACTORY_LABELS_JA.get(fcode, fcode)} に登録されていません。")

    fnode["pinHashes"][norm_name] = compute_pin_hash(fcode, norm_name, pin_norm)
    fnode["pinPlaintextAdmin"][norm_name] = pin_norm
    fnode["pinFailedAttempts"].pop(norm_name, None)

    must_list: list[str] = list(fnode.get("pinMustChange") or [])
    if require_change_on_login:
        if norm_name not in must_list:
            must_list.append(norm_name)
    else:
        must_list = [x for x in must_list if x != norm_name]
    fnode["pinMustChange"] = must_list

    _sanitize_factory_dict_in_place(fnode)
    _atomic_write_document(
        store_path=store_path,
        doc=doc,
        backup_label=f"PIN変更 ({norm_name})",
        admin_actor=admin_actor,
    )
    return pin_norm


def reissue_random_pin(
    store_path: str,
    factory_code: str,
    operator_name: str,
    digits: int = 4,
    require_change_on_login: bool = True,
    admin_actor: str = "監視ツール管理者",
) -> str:
    """ランダムPINを再発行して保存し、発行したPIN文字列を返す。"""
    new_pin = generate_random_pin(digits=digits)
    return set_operator_pin(
        store_path=store_path,
        factory_code=factory_code,
        operator_name=operator_name,
        new_pin=new_pin,
        require_change_on_login=require_change_on_login,
        admin_actor=admin_actor,
    )


def unlock_operator_pin(
    store_path: str,
    factory_code: str,
    operator_name: str,
    clear_must_change: bool = False,
    admin_actor: str = "監視ツール管理者",
) -> None:
    """PIN自体は変えずに失敗回数・ロック状態をクリアする。"""
    fcode = factory_code.strip().upper()
    norm_name = normalize_operator_name(operator_name)
    doc = read_document_from_file(store_path)
    fnode = _ensure_factory_dict(doc, fcode)
    if norm_name not in fnode["names"]:
        raise ValueError(f"ユーザー「{norm_name}」が見つかりません。")

    fnode["pinFailedAttempts"].pop(norm_name, None)
    if clear_must_change:
        fnode["pinMustChange"] = [x for x in (fnode.get("pinMustChange") or []) if x != norm_name]

    _sanitize_factory_dict_in_place(fnode)
    _atomic_write_document(
        store_path=store_path,
        doc=doc,
        backup_label=f"PINロック解除 ({norm_name})",
        admin_actor=admin_actor,
    )


def set_operator_admin_role(
    store_path: str,
    factory_code: str,
    operator_name: str,
    is_admin: bool,
    admin_actor: str = "監視ツール管理者",
) -> None:
    fcode = factory_code.strip().upper()
    norm_name = normalize_operator_name(operator_name)
    if not norm_name or is_guest_operator(norm_name):
        raise ValueError("対象ユーザー名が不正です。")

    doc = read_document_from_file(store_path)
    fnode = _ensure_factory_dict(doc, fcode)
    if norm_name not in fnode["names"]:
        raise ValueError(f"ユーザー「{norm_name}」が見つかりません。")

    admins = list(fnode.get("adminOperatorNames") or [])
    if is_admin:
        if norm_name not in admins:
            admins.append(norm_name)
    else:
        admins = [x for x in admins if x != norm_name]
    fnode["adminOperatorNames"] = admins

    _sanitize_factory_dict_in_place(fnode)
    role_txt = "付与" if is_admin else "解除"
    _atomic_write_document(
        store_path=store_path,
        doc=doc,
        backup_label=f"管理者権限{role_txt} ({norm_name})",
        admin_actor=admin_actor,
    )


def add_operator_user(
    store_path: str,
    factory_code: str,
    operator_name: str,
    initial_pin: str | None = None,
    require_change_on_login: bool | None = None,
    is_admin: bool = False,
    admin_actor: str = "監視ツール管理者",
) -> str:
    """新規ユーザーを追加し、設定された初期PINを返す。"""
    fcode = factory_code.strip().upper()
    norm_name = normalize_operator_name(operator_name)
    if not norm_name:
        raise ValueError("ユーザー名を入力してください。")
    if is_guest_operator(norm_name):
        raise ValueError(f"「{GUEST_OPERATOR_NAME}」はシステム予約名のため追加できません。")
    if any(ch in norm_name for ch in '\\/:*?"<>|'):
        raise ValueError('ユーザー名に使用できない記号（\\ / : * ? " < > |）が含まれています。')

    if initial_pin and initial_pin.strip():
        pin_norm = normalize_pin(initial_pin)
        if pin_norm is None:
            raise ValueError(f"PIN は {MIN_PIN_LENGTH}～{MAX_PIN_LENGTH}桁の数字で入力してください。")
        req_change = False if require_change_on_login is None else bool(require_change_on_login)
    else:
        pin_norm = generate_random_pin(4)
        req_change = True if require_change_on_login is None else bool(require_change_on_login)

    if os.path.isfile(store_path):
        doc = read_document_from_file(store_path)
    else:
        doc = {"schemaVersion": SCHEMA_VERSION, "factories": {}}

    fnode = _ensure_factory_dict(doc, fcode)
    if norm_name in fnode["names"]:
        raise ValueError(f"ユーザー「{norm_name}」は既に登録されています。")
    if len(fnode["names"]) >= MAX_NAMES_PER_FACTORY:
        raise ValueError(f"1工場あたりの最大登録数（{MAX_NAMES_PER_FACTORY}名）に達しています。")

    fnode["names"].append(norm_name)
    fnode["pinHashes"][norm_name] = compute_pin_hash(fcode, norm_name, pin_norm)
    fnode["pinPlaintextAdmin"][norm_name] = pin_norm
    if req_change and norm_name not in fnode["pinMustChange"]:
        fnode["pinMustChange"].append(norm_name)
    if is_admin and norm_name not in fnode["adminOperatorNames"]:
        fnode["adminOperatorNames"].append(norm_name)

    _sanitize_factory_dict_in_place(fnode)
    _atomic_write_document(
        store_path=store_path,
        doc=doc,
        backup_label=f"新規ユーザー追加 ({norm_name})",
        admin_actor=admin_actor,
    )
    return pin_norm


def remove_operator_user(
    store_path: str,
    factory_code: str,
    operator_name: str,
    admin_actor: str = "監視ツール管理者",
) -> None:
    """登録ユーザーを削除する（最後の1名は削除不可）。"""
    fcode = factory_code.strip().upper()
    norm_name = normalize_operator_name(operator_name)
    if not norm_name:
        raise ValueError("削除対象のユーザー名が空です。")

    doc = read_document_from_file(store_path)
    fnode = _ensure_factory_dict(doc, fcode)
    if norm_name not in fnode["names"]:
        raise ValueError(f"ユーザー「{norm_name}」は一覧に存在しません。")
    if len(fnode["names"]) <= 1:
        raise ValueError("工場内の最後の1名は削除できません。")

    fnode["names"] = [x for x in fnode["names"] if x != norm_name]
    _sanitize_factory_dict_in_place(fnode)
    _atomic_write_document(
        store_path=store_path,
        doc=doc,
        backup_label=f"ユーザー削除 ({norm_name})",
        admin_actor=admin_actor,
    )

    # 同フォルダに operator-aladdin-credentials.launcher.json がある場合は削除ユーザーの残骸も除去
    launcher_json = os.path.join(os.path.dirname(os.path.abspath(store_path)), "operator-aladdin-credentials.launcher.json")
    if os.path.isfile(launcher_json):
        try:
            with open(launcher_json, "r", encoding="utf-8-sig") as f:
                l_doc = json.load(f)
            if isinstance(l_doc, dict):
                changed = False
                f_map = (l_doc.get("factories") or {}).get(fcode)
                if isinstance(f_map, dict) and norm_name in f_map:
                    f_map.pop(norm_name, None)
                    changed = True
                if changed:
                    tmp_lj = launcher_json + f".tmp_{os.getpid()}"
                    with open(tmp_lj, "w", encoding="utf-8") as f:
                        json.dump(l_doc, f, ensure_ascii=False, indent=2)
                    os.replace(tmp_lj, launcher_json)
        except Exception:
            pass
