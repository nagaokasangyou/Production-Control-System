# -*- coding: utf-8 -*-
"""
PMD 国分・湖南工場 ユーザー稼働・操作・内部エラー監視コアエンジン
====================================================================
- 監視対象:
  1. 湖南工場 (KONAN): M:\\湖南工場\\湖南共有\\002  加工G\\●配台AIシステム\\共有DATA
     (フォールバック: \\\\192.168.0.101\\共有フォルダ\\湖南工場\\湖南共有\\002  加工G\\●配台AIシステム\\共有DATA)
  2. 国分工場 (KOKUBU): M:\\国分工場\\国分共有\\●配台AIシステム\\DATA
     (フォールバック: \\\\192.168.0.101\\共有フォルダ\\国分工場\\国分共有\\●配台AIシステム\\DATA)
- 解析対象データ:
  - 操作ログ/<操作者>/YYYY-MM-DD.ndjson (OperatorActionLogStore)
  - remote_log/<操作者>/ui_daily/YYYY-MM-DD.txt (RemoteSupportLogArchive 日次UIログ・未捕捉例外スタックトレース)
  - remote_log/<操作者>/<yyyyMMdd-HHmmss_stage>/{meta.json, ui_run_log.txt, execution_log.txt}
  - launcher-logs/launcher-YYYYMMDD.log (RDPリモートランチャー稼働・エラー)
  - *_RPA設定.ini (登録操作者名の補完)
- 特徴:
  - ファイル単位 (mtime_ns, size) 増分キャッシュにより、SMB/UNC 共有フォルダの定期ポーリング負荷を極小化
  - ui_daily と世代スナップショット間の重複ログ行をシグネチャ集約し、水増し・多重通知を防止
  - エラー発生時の直前ユーザー操作履歴（最大5件）を自動相関付けし、AI調査用Markdownレポートをワンクリック生成
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
import re
import struct
import time
import unicodedata
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from operator_pin_store import OperatorPinRecord, load_factory_pin_records


# ---------------------------------------------------------------------------
# 定数・工場定義・日本語ラベル辞書
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class FactoryTarget:
    code: str
    label_ja: str
    short_ja: str
    primary_data_dir: str
    unc_data_dir: str


FACTORY_TARGETS: tuple[FactoryTarget, ...] = (
    FactoryTarget(
        code="KONAN",
        label_ja="湖南工場",
        short_ja="湖南",
        primary_data_dir=r"M:\湖南工場\湖南共有\002  加工G\●配台AIシステム\共有DATA",
        unc_data_dir=r"\\192.168.0.101\共有フォルダ\湖南工場\湖南共有\002  加工G\●配台AIシステム\共有DATA",
    ),
    FactoryTarget(
        code="KOKUBU",
        label_ja="国分工場",
        short_ja="国分",
        primary_data_dir=r"M:\国分工場\国分共有\●配台AIシステム\DATA",
        unc_data_dir=r"\\192.168.0.101\共有フォルダ\国分工場\国分共有\●配台AIシステム\DATA",
    ),
)

GITHUB_VERSION_URLS: tuple[str, ...] = (
    "https://raw.githubusercontent.com/nagaokasangyou/Production-Control-System/main/updates/version.txt",
    "https://raw.githubusercontent.com/hosokawanagaokasangyou-dotcom/Production-Control-System/main/updates/version.txt",
)

TAB_LABELS: dict[str, str] = {
    "equipmentStatusDashboard": "設備稼働ダッシュボード",
    "kouchin": "東レ後加工賃検証",
    "processingTrend": "加工トレンド",
    "run": "実行・ログ",
    "uiBadgeDesign": "UIバッジデザイン",
    "pushButtonDesign": "ボタンデザイン",
    "env": "環境変数",
    "memorySettings": "メモリ設定",
    "globalSettings": "グローバル設定",
    "userProfiles": "ユーザープロファイル",
    "operatorUserManagement": "操作者・ユーザー管理",
    "companyCalendar": "会社カレンダー",
    "memberAttendance": "メンバー勤怠",
    "machineCalendar": "機械カレンダー",
    "masterDispatchSheets": "MASTER(配台4シート)",
    "masterSummary": "マスタ集計",
    "planInput": "配台計画_タスク入力",
    "requestFormInput": "加工依頼書入力",
    "requestFormPipelineCheck": "原本転記・計画確認",
    "remoteDesktop": "リモートデスクトップ(RPA)",
    "stage1Preview": "段階1整形プレビュー",
    "codeLookupTables": "材料・製品種類情報",
    "excludeRules": "配台不要工程設定",
    "specialRules": "特別ルール",
    "actualsStatus": "加工実績ステータス",
    "dailyReportCsvView": "加工日報CSV閲覧",
    "deliveryCalendarView": "納期管理ビュー",
    "resultDispatch": "結果_配台表",
    "planResultViewer": "計画結果ビューワー",
    "equipmentGanttGraphic": "設備ガントチャート",
    "ganttPersonBadgeDesign": "ガント人員バッジ設定",
    "requestFormPreviewBadgeDesign": "依頼書バッジ設定",
    "operatorCard": "作業指示カード印刷",
    "planWorkspaceHistory": "配台履歴スナップショット",
    "cacheHistory": "キャッシュ退避履歴",
    "operatorActionLog": "操作ログ閲覧",
    "identityCheckHistory": "同一化チェック履歴",
    "apiModelBenchmark": "AIモデル応答計測",
    "pipelineExecutionTiming": "実行時間トレンド",
    "developer": "開発・エラー解析",
    "tabOrganizer": "タブ整理",
    "session": "セッション",
    "rpa": "RPAランチャー",
    "startup": "起動・更新",
}

ACTION_LABELS: dict[str, str] = {
    "session_start": "🚀 アプリ起動・ログイン",
    "tab_select": "📑 画面切替",
    "stage1_start": "▶️ 段階1(データ抽出)開始",
    "stage1_complete": "✅ 段階1(データ抽出)完了",
    "stage2_start": "▶️ 段階2(AI配台)開始",
    "stage2_complete": "✅ 段階2(AI配台)完了",
    "stage2_1_complete": "✅ 段階2.1(残業シミュ)完了",
    "excel_export": "📊 Excel出力",
    "identity_check": "🔍 同一化チェック",
    "dispatch_cell_edit": "✏️ 手動配台セル編集",
    "kouchin_drop": "📥 東レCSVドロップ",
    "kouchin_verify": "🧮 東レ後加工賃検証",
    "processing_trend_run": "📈 加工トレンド実行",
    "env_change": "⚙️ 環境変数変更",
    "factory_share_backup": "💾 工場共有バックアップ",
    "close_warning": "⚠️ 終了時警告表示",
    "rpa_launch": "🖥️ RPAリモート実行",
    "auto_upgrade": "⬆️ 自動バージョンアップ",
    "pipeline_check_mark": "☑️ 計画確認チェック一括付与",
}

RESULT_LABELS: dict[str, str] = {
    "ok": "成功",
    "mismatch": "差異あり",
    "error": "エラー",
    "shown": "表示",
    "empty": "空",
    "none": "なし",
    "warn": "警告",
}

SEVERITY_ORDER: dict[str, int] = {
    "critical": 3,
    "error": 2,
    "warn": 1,
}

SEVERITY_LABELS: dict[str, str] = {
    "critical": "重大(クラッシュ/異常終了)",
    "error": "エラー",
    "warn": "警告",
}

# 誤検知を除外するパターン
FALSE_POSITIVE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"失敗\s*0\s*(バッチ|件|回)"),
    re.compile(r"エラー\s*0\s*(件|個|回)"),
    re.compile(r"warnings?\s*=\s*0\b", re.IGNORECASE),
    re.compile(r"^\[portable-sync\]\s*同期:"),
    re.compile(r"^\[remote_log\]"),
    re.compile(r"exitCode=0\b"),
    re.compile(r'"exit_code"\s*:\s*0\b'),
)

# スタックトレース継続行判定
STACK_CONTINUATION_RE = re.compile(
    r"^(\s+at\s+\S+|\t+at\s+\S+|Caused by:\s+|Suppressed:\s+|\s+\.\.\.\s+\d+\s+more|\s+File\s+\".*\", line \d+)"
)
PM_AI_FRAME_RE = re.compile(r"jp\.co\.pm\.ai\.[A-Za-z0-9_.$]+\(([A-Za-z0-9_]+\.java:\d+)\)")
PYTHON_FRAME_RE = re.compile(r'File "([^"]*planning_core[^"]*)", line (\d+)')
PYTHON_LOG_TS_RE = re.compile(r"^(?:\[child\]\s*)?(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})(?:,\d+)?\s*-\s*(ERROR|CRITICAL|WARNING|INFO)\s*-\s*(.*)$")
LAUNCHER_LOG_RE = re.compile(r"^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+\[(INFO|WARN|WARNING|ERROR)\]\s+(.*)$")
GEN_DIR_RE = re.compile(r"^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})_(.+)$")
DAILY_FILE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})\.(?:ndjson|txt)$")
LAUNCHER_FILE_RE = re.compile(r"^launcher-(\d{4})(\d{2})(\d{2})\.log$")
RPA_INI_RE = re.compile(r"^(.+)_RPA設定\.ini$")
ISO_IN_BRACKETS_RE = re.compile(r"\[(\d{4}-\d{2}-\d{2}T[0-9:.]+(?:Z|[+-]\d{2}:\d{2}))\]")


# ---------------------------------------------------------------------------
# ユーティリティ関数
# ---------------------------------------------------------------------------
def nfkc_lower(text: str) -> str:
    if not text:
        return ""
    return unicodedata.normalize("NFKC", text).lower()


def clean_version(ver: str) -> str:
    if not ver:
        return ""
    v = ver.strip()
    if v.lower().startswith("v"):
        v = v[1:].strip()
    return v


def parse_version_tuple(ver: str) -> tuple[int, ...]:
    cleaned = clean_version(ver)
    if not cleaned:
        return ()
    parts: list[int] = []
    for token in re.split(r"[^0-9]+", cleaned):
        if token:
            try:
                parts.append(int(token))
            except ValueError:
                pass
    return tuple(parts)


def compare_versions(v1: str, v2: str) -> int:
    """
    v1 < v2 -> -1, v1 == v2 -> 0, v1 > v2 -> 1.
    片方が空の場合は空の方を小さいとみなす。
    """
    t1 = parse_version_tuple(v1)
    t2 = parse_version_tuple(v2)
    if not t1 and not t2:
        return 0
    if not t1:
        return -1
    if not t2:
        return 1
    max_len = max(len(t1), len(t2))
    p1 = t1 + (0,) * (max_len - len(t1))
    p2 = t2 + (0,) * (max_len - len(t2))
    if p1 < p2:
        return -1
    if p1 > p2:
        return 1
    return 0


def parse_iso_or_local_ts(ts_str: str, fallback_epoch: float = 0.0) -> float:
    """ISO8601 または 'YYYY-MM-DD HH:MM:SS' を epoch 秒に変換する。"""
    if not ts_str:
        return fallback_epoch
    s = ts_str.strip()
    try:
        # Python 3.11+ handles Z and nanosecond ISO strings in fromisoformat
        # Trim >6 fractional digits if needed for safety
        s_norm = re.sub(r"\.(\d{6})\d+", r".\1", s)
        dt = datetime.datetime.fromisoformat(s_norm)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=datetime.datetime.now().astimezone().tzinfo)
        return dt.timestamp()
    except ValueError:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.datetime.strptime(s, fmt)
            dt = dt.replace(tzinfo=datetime.datetime.now().astimezone().tzinfo)
            return dt.timestamp()
        except ValueError:
            continue
    return fallback_epoch


def format_epoch(epoch: float, include_seconds: bool = True) -> str:
    if epoch <= 0:
        return "-"
    dt = datetime.datetime.fromtimestamp(epoch)
    return dt.strftime("%Y-%m-%d %H:%M:%S" if include_seconds else "%Y-%m-%d %H:%M")


def format_short_ts(epoch: float) -> str:
    if epoch <= 0:
        return "-"
    dt = datetime.datetime.fromtimestamp(epoch)
    now = datetime.datetime.now()
    if dt.date() == now.date():
        return dt.strftime("今日 %H:%M:%S")
    return dt.strftime("%m/%d %H:%M:%S")


def format_relative_ago(epoch: float, now_epoch: float | None = None) -> str:
    if epoch <= 0:
        return "履歴なし"
    now_val = now_epoch if now_epoch is not None else time.time()
    diff = max(0.0, now_val - epoch)
    if diff < 60:
        return f"{int(diff)}秒前"
    if diff < 3600:
        return f"{int(diff // 60)}分前"
    if diff < 86400:
        return f"{int(diff // 3600)}時間前"
    return f"{int(diff // 86400)}日前"


def feature_label_ja(feature: str) -> str:
    if not feature:
        return ""
    return TAB_LABELS.get(feature.strip(), feature.strip())


def action_label_ja(action: str, feature: str = "", detail: str = "") -> str:
    act = (action or "").strip()
    base = ACTION_LABELS.get(act, act)
    if act == "tab_select":
        target = feature_label_ja(detail or feature)
        return f"📑 画面切替 → {target}" if target else base
    if detail:
        # detail が feature キーそのものの場合は日本語化
        det_ja = TAB_LABELS.get(detail.strip(), detail.strip())
        return f"{base} ({det_ja})"
    return base


def result_label_ja(result: str) -> str:
    if not result:
        return ""
    return RESULT_LABELS.get(result.strip(), result.strip())


def resolve_accessible_dir(primary: str, unc: str) -> tuple[str, bool]:
    if primary and os.path.isdir(primary):
        return primary, True
    if unc and os.path.isdir(unc):
        return unc, True
    return (unc or primary), False


def is_false_positive_line(line: str) -> bool:
    if not line:
        return True
    s = line.strip()
    if not s or s.startswith("#"):
        return True
    for pat in FALSE_POSITIVE_PATTERNS:
        if pat.search(s):
            return True
    return False


# ---------------------------------------------------------------------------
# データモデル
# ---------------------------------------------------------------------------
@dataclass
class OperationEvent:
    factory_code: str
    factory_label: str
    operator: str
    epoch: float
    ts_display: str
    action: str
    feature: str
    result: str
    detail: str
    app_version: str
    host: str
    os_user: str
    source_kind: str = "action_log"  # "action_log" | "ui_daily" | "stage_meta" | "rpa_launcher"

    @property
    def is_tab_select(self) -> bool:
        return self.action == "tab_select"

    @property
    def summary_ja(self) -> str:
        return action_label_ja(self.action, self.feature, self.detail)

    @property
    def feature_ja(self) -> str:
        return feature_label_ja(self.feature)

    @property
    def result_ja(self) -> str:
        return result_label_ja(self.result)


@dataclass
class ErrorEvent:
    signature_id: str
    factory_code: str
    factory_label: str
    operator: str
    epoch: float
    first_seen_epoch: float
    ts_display: str
    date_str: str
    severity: str  # "critical" | "error" | "warn"
    category: str  # "Java未捕捉例外" | "Stage異常終了" | "Python実行エラー" | "UI/業務エラー" | "RDPランチャー" | "起動/通信警告"
    headline: str
    code_location: str
    stack_trace: str
    app_version: str
    host: str
    os_user: str
    source_path: str
    occurrence_count: int = 1
    preceding_ops: list[OperationEvent] = field(default_factory=list)

    @property
    def severity_rank(self) -> int:
        return SEVERITY_ORDER.get(self.severity, 0)

    @property
    def severity_ja(self) -> str:
        return SEVERITY_LABELS.get(self.severity, self.severity)

    @property
    def is_error_or_critical(self) -> bool:
        return self.severity in ("critical", "error")


@dataclass
class UserStatusSummary:
    factory_code: str
    factory_label: str
    operator: str
    current_version: str
    version_status: str  # "latest" | "ahead" | "outdated" | "unknown"
    last_active_epoch: float
    last_action_summary: str
    last_feature_ja: str
    host: str
    os_user: str
    today_op_count: int
    today_error_count: int
    today_warn_count: int
    recent_error_count: int
    recent_warn_count: int
    is_online_now: bool  # 直近30分以内に操作あり
    is_active_today: bool
    action_log_dir: str
    remote_log_dir: str
    pin_plaintext: str = ""
    has_pin: bool = False
    pin_status_ja: str = "⚪ 未設定"
    pin_is_locked: bool = False
    pin_must_change: bool = False
    pin_failed_attempts: int = 0
    is_admin_user: bool = False
    aladdin_login_id: str = ""
    has_aladdin_password: bool = False
    operator_store_path: str = ""
    is_registered_in_store: bool = False


@dataclass
class FactoryReachability:
    code: str
    label_ja: str
    resolved_dir: str
    online: bool
    operator_count: int


@dataclass
class MonitorSnapshot:
    scanned_at_epoch: float
    scan_duration_ms: float
    latest_published_version: str
    local_repo_version: str
    version_source_note: str
    factories: dict[str, FactoryReachability]
    users: list[UserStatusSummary]
    operations: list[OperationEvent]
    errors: list[ErrorEvent]
    pin_records: list[OperatorPinRecord] = field(default_factory=list)
    operator_store_paths: dict[str, str] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# AI調査・修正用レポート整形
# ---------------------------------------------------------------------------
def format_ai_diagnostic_report(err: ErrorEvent, latest_version: str = "") -> str:
    ver_note = f"v{err.app_version}" if err.app_version else "不明"
    if latest_version and err.app_version:
        cmp_val = compare_versions(err.app_version, latest_version)
        if cmp_val < 0:
            ver_note += f"（※旧バージョン / 現在の配信最新: v{latest_version}）"
        elif cmp_val == 0:
            ver_note += "（配信最新版）"

    lines = [
        f"## PMD 内部エラー監視レポート ({err.factory_label} / {err.operator})",
        f"- **発生日時**: {err.ts_display} (検知回数: {err.occurrence_count}回)",
        f"- **重要度 / 分類**: {err.severity_ja} / {err.category}",
        f"- **工場 / 操作者**: {err.factory_label} (`{err.factory_code}`) / `{err.operator}`",
        f"- **使用バージョン**: {ver_note}",
        f"- **端末 / OSユーザー**: `{err.host or '-'}` / `{err.os_user or '-'}`",
    ]
    if err.code_location:
        lines.append(f"- **推定発生コード位置**: `{err.code_location}`")
    lines.append(f"- **元ログファイル**: `{err.source_path}`")
    lines.append("")
    lines.append("### エラー概要")
    lines.append(f"`{err.headline}`")

    if err.preceding_ops:
        lines.append("")
        lines.append("### エラー直前のユーザー操作履歴（新しい順）")
        for op in err.preceding_ops[:5]:
            lines.append(
                f"- `{op.ts_display}` | {op.summary_ja} | 結果={op.result_ja} | v{op.app_version or '-'}"
            )

    if err.stack_trace and err.stack_trace.strip() != err.headline.strip():
        lines.append("")
        lines.append("### スタックトレース / 詳細ログ抜粋")
        lines.append("```text")
        lines.append(err.stack_trace.strip())
        lines.append("```")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 単一ファイルパーサ群
# ---------------------------------------------------------------------------
@dataclass
class _CachedFileResult:
    mtime_ns: int
    size: int
    operations: list[OperationEvent]
    errors: list[ErrorEvent]
    header_meta: dict[str, str] = field(default_factory=dict)


def _make_signature_id(factory_code: str, operator: str, date_str: str, category: str, headline: str) -> str:
    # 数値や一時パス・ミリ秒などの揺れを正規化して同一エラーを集約する
    norm = re.sub(r"\b\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:\d{2})?\b", "<TS>", headline)
    norm = re.sub(r"試行\s*\d+/\d+", "試行N/M", norm)
    norm = re.sub(r"retry in [0-9m.s]+", "retry", norm, flags=re.IGNORECASE)
    raw = f"{factory_code}|{operator}|{date_str}|{category}|{norm[:180]}"
    return hashlib.sha1(raw.encode("utf-8", errors="replace")).hexdigest()[:16]


def _extract_code_location(lines: list[str]) -> str:
    joined = "\n".join(lines)
    m = PM_AI_FRAME_RE.search(joined)
    if m:
        return m.group(1)
    m2 = PYTHON_FRAME_RE.search(joined)
    if m2:
        return f"{os.path.basename(m2.group(1))}:{m2.group(2)}"
    return ""


def parse_action_ndjson_file(
    filepath: str,
    factory_code: str,
    factory_label: str,
    fallback_operator: str,
    file_mtime: float,
) -> tuple[list[OperationEvent], list[ErrorEvent], dict[str, str]]:
    ops: list[OperationEvent] = []
    errs: list[ErrorEvent] = []
    latest_meta: dict[str, str] = {}

    fname = os.path.basename(filepath)
    date_part = fname[:10] if len(fname) >= 10 else datetime.date.fromtimestamp(file_mtime).isoformat()

    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            raw_lines = f.readlines()
    except OSError:
        return ops, errs, latest_meta

    for line in raw_lines:
        s = line.strip()
        if not s:
            continue
        try:
            obj = json.loads(s)
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict):
            continue

        ts_raw = str(obj.get("ts") or "")
        epoch = parse_iso_or_local_ts(ts_raw, fallback_epoch=file_mtime)
        operator = str(obj.get("operator") or fallback_operator or "unknown").strip()
        action = str(obj.get("action") or "").strip()
        feature = str(obj.get("feature") or "").strip()
        result = str(obj.get("result") or "").strip()
        detail = str(obj.get("detail") or "").strip()
        app_ver = clean_version(str(obj.get("appVersion") or ""))
        host = str(obj.get("host") or "").strip()
        os_user = str(obj.get("osUser") or "").strip()

        op_ev = OperationEvent(
            factory_code=factory_code,
            factory_label=factory_label,
            operator=operator,
            epoch=epoch,
            ts_display=format_epoch(epoch),
            action=action,
            feature=feature,
            result=result,
            detail=detail,
            app_version=app_ver,
            host=host,
            os_user=os_user,
            source_kind="action_log",
        )
        ops.append(op_ev)

        if app_ver:
            latest_meta["app_version"] = app_ver
        if host:
            latest_meta["host"] = host
        if os_user:
            latest_meta["os_user"] = os_user
        latest_meta["last_epoch"] = str(epoch)

        # 操作ログ自体に result="error" が記録されている場合もエラーとして捕捉
        if result == "error":
            headline = f"{action_label_ja(action, feature, detail)} が失敗しました"
            sig = _make_signature_id(factory_code, operator, date_part, "操作エラー", headline)
            errs.append(
                ErrorEvent(
                    signature_id=sig,
                    factory_code=factory_code,
                    factory_label=factory_label,
                    operator=operator,
                    epoch=epoch,
                    first_seen_epoch=epoch,
                    ts_display=format_epoch(epoch),
                    date_str=date_part,
                    severity="error",
                    category="UI/業務エラー",
                    headline=headline,
                    code_location=feature_label_ja(feature),
                    stack_trace=f"action={action}\nfeature={feature}\nresult={result}\ndetail={detail}",
                    app_version=app_ver,
                    host=host,
                    os_user=os_user,
                    source_path=filepath,
                )
            )

    return ops, errs, latest_meta


def _parse_ui_header(lines: list[str], fallback_operator: str, fallback_factory: str) -> dict[str, str]:
    meta = {
        "operator": fallback_operator,
        "factory": fallback_factory,
        "app_version": "",
        "host": "",
        "os_user": "",
        "date": "",
    }
    for line in lines[:10]:
        if not line.startswith("#"):
            continue
        if line.startswith("# pm-ai-desktop ui_daily "):
            meta["date"] = line[len("# pm-ai-desktop ui_daily ") :].strip()
        for token in line.split():
            if "=" in token and not token.startswith("#"):
                k, v = token.split("=", 1)
                if k in ("operator", "factory", "app_version", "host", "os_user"):
                    meta[k] = clean_version(v) if k == "app_version" else v.strip()
    return meta


def parse_ui_or_exec_log_file(
    filepath: str,
    factory_code: str,
    factory_label: str,
    fallback_operator: str,
    file_mtime: float,
    default_date_str: str,
    fallback_meta: dict[str, str] | None = None,
    extract_operations: bool = False,
) -> tuple[list[OperationEvent], list[ErrorEvent], dict[str, str]]:
    ops: list[OperationEvent] = []
    errs: list[ErrorEvent] = []

    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            lines = [ln.rstrip("\r\n") for ln in f]
    except OSError:
        return ops, errs, {}

    hdr = _parse_ui_header(lines, fallback_operator, factory_code)
    if fallback_meta:
        for k in ("app_version", "host", "os_user", "operator"):
            if not hdr.get(k) and fallback_meta.get(k):
                hdr[k] = fallback_meta[k]

    operator = hdr.get("operator") or fallback_operator or "unknown"
    app_ver = clean_version(hdr.get("app_version") or "")
    host = hdr.get("host") or ""
    os_user = hdr.get("os_user") or ""
    date_str = hdr.get("date") or default_date_str or datetime.date.fromtimestamp(file_mtime).isoformat()

    # ファイル内の進行中バージョン更新も追跡
    current_ver = app_ver
    total_lines = len(lines)
    i = 0
    while i < total_lines:
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        # バージョン情報の補完検出
        m_ver = re.search(r"ローカル=([0-9]+\.[0-9]+)", stripped)
        if m_ver and not current_ver:
            current_ver = m_ver.group(1)

        # ui_daily からの補助業務イベント抽出 (RPA起動・自動更新・計画確認チェック)
        if extract_operations:
            if stripped.startswith("起動プロファイル:"):
                prof = stripped[len("起動プロファイル:") :].strip()
                ops.append(
                    OperationEvent(
                        factory_code=factory_code,
                        factory_label=factory_label,
                        operator=operator,
                        epoch=file_mtime,
                        ts_display=f"{date_str} (日次ログ)",
                        action="rpa_launch",
                        feature="remoteDesktop",
                        result="ok",
                        detail=prof[:60],
                        app_version=current_ver,
                        host=host,
                        os_user=os_user,
                        source_kind="ui_daily",
                    )
                )
            elif "ポータルバージョンアップ開始" in stripped:
                m_up = re.search(r"正本\s*([0-9.]+)\s*→\s*ローカル\s*([0-9.]+)", stripped)
                det = f"v{m_up.group(2)} → v{m_up.group(1)}" if m_up else stripped
                ops.append(
                    OperationEvent(
                        factory_code=factory_code,
                        factory_label=factory_label,
                        operator=operator,
                        epoch=file_mtime,
                        ts_display=f"{date_str} (日次ログ)",
                        action="auto_upgrade",
                        feature="startup",
                        result="ok",
                        detail=det,
                        app_version=current_ver,
                        host=host,
                        os_user=os_user,
                        source_kind="ui_daily",
                    )
                )

        if is_false_positive_line(stripped):
            i += 1
            continue

        # エラー / 警告判定
        severity: str | None = None
        category: str = "UI/業務エラー"
        line_epoch = file_mtime
        line_date = date_str
        headline = stripped

        # 1) 未捕捉クラッシュ ([startup-crash])
        if "[startup-crash]" in stripped:
            severity = "critical"
            category = "Java未捕捉例外"
            m_iso = ISO_IN_BRACKETS_RE.search(stripped)
            if m_iso:
                line_epoch = parse_iso_or_local_ts(m_iso.group(1), file_mtime)
                line_date = datetime.date.fromtimestamp(line_epoch).isoformat()
            headline = stripped.replace("[startup-crash]", "").strip()

        # 2) Python Traceback
        elif "Traceback (most recent call last):" in stripped:
            severity = "critical"
            category = "Python実行エラー"

        # 3) Python logging 行 (YYYY-MM-DD HH:MM:SS,mmm - ERROR/WARNING - ...)
        elif m_py := PYTHON_LOG_TS_RE.match(stripped):
            ts_part, lvl, msg = m_py.group(1), m_py.group(2), m_py.group(3).strip()
            line_epoch = parse_iso_or_local_ts(ts_part, file_mtime)
            line_date = ts_part[:10]
            if lvl in ("ERROR", "CRITICAL"):
                severity = "error"
                category = "Python実行エラー"
                headline = msg
            elif lvl == "WARNING":
                # Gemini API クォータ・過負荷切替などは警告として分類
                severity = "warn"
                category = "AI/外部API警告" if "Gemini" in msg else "Python警告"
                headline = msg[:180]

        # 4) Java 例外 / Error クラス名を含む行
        elif re.search(r"\b([A-Za-z0-9_$.]+(?:Exception|Error))\b", stripped) and not stripped.startswith("[env]"):
            # ただし単なるファイル名やINFO説明文でないことを確認
            if any(
                kw in stripped
                for kw in (
                    "Exception:",
                    "Exception ",
                    "OutOfMemoryError",
                    "NoClassDefFoundError",
                    "StackOverflowError",
                    "AssertionError",
                    "LinkageError",
                    "uncaught thread=",
                )
            ) or re.match(r"^[a-z0-9_.]+\.[A-Z][A-Za-z0-9_$]*(?:Exception|Error)\b", stripped):
                severity = "critical" if "uncaught thread=" in stripped or "Error" in stripped else "error"
                category = "Java未捕捉例外" if "uncaught thread=" in stripped else "Java実行時エラー"

        # 5) 起動時バックグラウンド読込失敗（続行） -> 警告
        elif "[startup-bg]" in stripped and "失敗" in stripped:
            severity = "warn"
            category = "起動/通信警告"

        # 6) 後加工賃・ファイル読取不可などの業務診断エラー
        elif any(kw in stripped for kw in ("読取不可", "ドロップされたファイルがありません")):
            severity = "error"
            category = "後加工賃検証" if "[kouchin" in stripped else "UI/業務エラー"
        elif ("[kouchin]" in stripped or "[kouchin-trend]" in stripped) and (
            "失敗" in stripped or "エラー" in stripped
        ):
            severity = "error"
            category = "後加工賃検証"

        if severity is None:
            i += 1
            continue

        # スタックトレース継続行をまとめて取得（最大60行）
        block_lines = [line]
        j = i + 1
        if severity in ("critical", "error"):
            while j < total_lines and len(block_lines) < 60:
                nxt = lines[j]
                if STACK_CONTINUATION_RE.match(nxt) or (
                    "Traceback" in line and (nxt.startswith("  ") or re.match(r"^[A-Za-z0-9_.]*(?:Error|Exception):", nxt))
                ):
                    block_lines.append(nxt)
                    # Python Traceback の末尾例外行を headline に昇格
                    if "Traceback" in line and re.match(r"^[A-Za-z0-9_.]*(?:Error|Exception):", nxt.strip()):
                        headline = nxt.strip()
                    j += 1
                else:
                    break

        code_loc = _extract_code_location(block_lines)
        sig = _make_signature_id(factory_code, operator, line_date, category, headline)
        errs.append(
            ErrorEvent(
                signature_id=sig,
                factory_code=factory_code,
                factory_label=factory_label,
                operator=operator,
                epoch=line_epoch,
                first_seen_epoch=line_epoch,
                ts_display=format_epoch(line_epoch) if line_epoch != file_mtime else f"{line_date} ({datetime.datetime.fromtimestamp(file_mtime).strftime('%H:%M:%S')})",
                date_str=line_date,
                severity=severity,
                category=category,
                headline=headline[:240],
                code_location=code_loc,
                stack_trace="\n".join(block_lines),
                app_version=current_ver,
                host=host,
                os_user=os_user,
                source_path=filepath,
            )
        )
        i = j

    out_meta = {
        "app_version": current_ver,
        "host": host,
        "os_user": os_user,
        "operator": operator,
    }
    return ops, errs, out_meta


def parse_stage_meta_json(
    meta_path: str,
    factory_code: str,
    factory_label: str,
    fallback_operator: str,
    file_mtime: float,
) -> tuple[list[OperationEvent], list[ErrorEvent], dict[str, str]]:
    ops: list[OperationEvent] = []
    errs: list[ErrorEvent] = []
    meta_info: dict[str, str] = {}

    try:
        with open(meta_path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return ops, errs, meta_info

    if not isinstance(data, dict):
        return ops, errs, meta_info

    operator = str(data.get("operator") or fallback_operator or "unknown").strip()
    stage_id = str(data.get("stage_id") or "runtime").strip()
    saved_at = str(data.get("saved_at") or "").strip()
    epoch = parse_iso_or_local_ts(saved_at, fallback_epoch=file_mtime)
    date_str = saved_at[:10] if len(saved_at) >= 10 else datetime.date.fromtimestamp(epoch).isoformat()
    app_ver = clean_version(str(data.get("app_version") or ""))
    host = str(data.get("host") or "").strip()
    os_user = str(data.get("os_user") or "").strip()
    exit_code = data.get("exit_code")
    error_msg = str(data.get("error") or "").strip()

    meta_info = {
        "operator": operator,
        "app_version": app_ver,
        "host": host,
        "os_user": os_user,
        "last_epoch": str(epoch),
    }

    has_nonzero_exit = isinstance(exit_code, int) and exit_code != 0
    if error_msg or has_nonzero_exit:
        headline = error_msg if error_msg else f"ステージ {stage_id} が終了コード {exit_code} で異常終了しました"
        sig = _make_signature_id(factory_code, operator, date_str, f"stage:{stage_id}", headline)
        errs.append(
            ErrorEvent(
                signature_id=sig,
                factory_code=factory_code,
                factory_label=factory_label,
                operator=operator,
                epoch=epoch,
                first_seen_epoch=epoch,
                ts_display=format_epoch(epoch),
                date_str=date_str,
                severity="critical" if has_nonzero_exit else "error",
                category="Stage異常終了",
                headline=headline[:240],
                code_location=f"stage={stage_id} (exit={exit_code})",
                stack_trace=json.dumps(data, ensure_ascii=False, indent=2),
                app_version=app_ver,
                host=host,
                os_user=os_user,
                source_path=meta_path,
            )
        )

    return ops, errs, meta_info


def parse_operator_users_bin(filepath: str, factory_code: str) -> list[str]:
    """
    PMD ユーザー管理ストア (factory-operator-users.bin / PMOU バイナリ形式 または JSON) から
    対象工場の登録操作者名リストのみを読み取る（PIN・認証情報は一切保持しない）。
    """
    try:
        with open(filepath, "rb") as f:
            raw = f.read()
    except OSError:
        return []

    if not raw:
        return []

    doc: Any = None
    if len(raw) >= 10 and raw[:4] == b"PMOU":
        fmt_ver, payload_len = struct.unpack(">HI", raw[4:10])
        if fmt_ver == 1 and 0 <= payload_len <= len(raw) - 10:
            try:
                doc = json.loads(raw[10 : 10 + payload_len].decode("utf-8", errors="replace"))
            except json.JSONDecodeError:
                doc = None
    else:
        try:
            doc = json.loads(raw.decode("utf-8-sig", errors="replace"))
        except json.JSONDecodeError:
            doc = None

    if not isinstance(doc, dict):
        return []

    names_out: list[str] = []
    seen: set[str] = set()

    def _add_names(seq: Any) -> None:
        if not isinstance(seq, list):
            return
        for item in seq:
            if not isinstance(item, str):
                continue
            n = item.strip()
            if not n or n in ("ゲスト", "【ユーザー登録無し】") or n.lower() == "unknown":
                continue
            if n not in seen:
                seen.add(n)
                names_out.append(n)

    factories_node = doc.get("factories")
    if isinstance(factories_node, dict):
        f_obj = factories_node.get(factory_code)
        if isinstance(f_obj, dict):
            _add_names(f_obj.get("names"))

    if os.path.basename(filepath).lower() == "rdp-launcher-operator-users.bin":
        rdp_depts = doc.get("rdpDepartments")
        if isinstance(rdp_depts, dict):
            for dept_obj in rdp_depts.values():
                if isinstance(dept_obj, dict):
                    _add_names(dept_obj.get("names"))

    return names_out


def parse_rpa_launcher_log(
    filepath: str,
    factory_code: str,
    factory_label: str,
    file_mtime: float,
) -> tuple[list[OperationEvent], list[ErrorEvent]]:
    ops: list[OperationEvent] = []
    errs: list[ErrorEvent] = []

    try:
        with open(filepath, "r", encoding="utf-8-sig", errors="replace") as f:
            lines = [ln.rstrip("\r\n") for ln in f]
    except OSError:
        return ops, errs

    current_operator = "RPAランチャー"
    current_ver = ""
    for line in lines:
        m = LAUNCHER_LOG_RE.match(line.strip())
        if not m:
            continue
        ts_str, lvl, msg = m.group(1), m.group(2), m.group(3).strip()
        epoch = parse_iso_or_local_ts(ts_str, file_mtime)
        date_str = ts_str[:10]

        if "PmAiRdpRemoteLauncher 開始" in msg:
            mv = re.search(r"version=([0-9.]+)", msg)
            if mv:
                current_ver = mv.group(1)
        elif msg.startswith("操作者名引数:"):
            op_name = msg[len("操作者名引数:") :].strip()
            if op_name and op_name not in ("ゲスト", "unknown"):
                current_operator = op_name
                ops.append(
                    OperationEvent(
                        factory_code=factory_code,
                        factory_label=factory_label,
                        operator=current_operator,
                        epoch=epoch,
                        ts_display=format_epoch(epoch),
                        action="rpa_launch",
                        feature="rpa",
                        result="ok",
                        detail=f"PmAiRdpRemoteLauncher (v{current_ver})" if current_ver else "PmAiRdpRemoteLauncher",
                        app_version=current_ver,
                        host="",
                        os_user="",
                        source_kind="rpa_launcher",
                    )
                )

        if lvl == "ERROR" or ("exitCode=" in msg and "exitCode=0" not in msg):
            sig = _make_signature_id(factory_code, current_operator, date_str, "RDPランチャー", msg)
            errs.append(
                ErrorEvent(
                    signature_id=sig,
                    factory_code=factory_code,
                    factory_label=factory_label,
                    operator=current_operator,
                    epoch=epoch,
                    first_seen_epoch=epoch,
                    ts_display=format_epoch(epoch),
                    date_str=date_str,
                    severity="error",
                    category="RDPランチャー",
                    headline=msg[:240],
                    code_location="PmAiRdpRemoteLauncher",
                    stack_trace=line,
                    app_version=current_ver,
                    host="",
                    os_user="",
                    source_path=filepath,
                )
            )
    return ops, errs


# ---------------------------------------------------------------------------
# インクリメンタル監視エンジン
# ---------------------------------------------------------------------------
class IncrementalLogScanner:
    """
    国分・湖南の共有フォルダを増分キャッシュ付きで高速走査するクラス。
    UIスレッドを一切ブロックしないよう、バックグラウンドワーカースレッドから呼び出す想定。
    """

    def __init__(
        self,
        factory_targets: tuple[FactoryTarget, ...] = FACTORY_TARGETS,
        local_repo_root: str | None = None,
        github_version_ttl_sec: float = 180.0,
    ) -> None:
        self.factory_targets = factory_targets
        self.local_repo_root = local_repo_root or self._guess_repo_root()
        self.github_version_ttl_sec = github_version_ttl_sec

        self._file_cache: dict[str, _CachedFileResult] = {}
        self._gen_dir_cache: dict[str, tuple[int, dict[str, str], list[ErrorEvent]]] = {}
        self._pin_records_cache: dict[tuple[str, str], tuple[int, int, list[OperatorPinRecord]]] = {}
        self._cached_github_ver: str = ""
        self._cached_github_source: str = ""
        self._last_github_fetch: float = 0.0

    @staticmethod
    def _guess_repo_root() -> str:
        here = os.path.abspath(os.path.dirname(__file__))
        cand = os.path.abspath(os.path.join(here, "..", ".."))
        if os.path.isfile(os.path.join(cand, "version.txt")):
            return cand
        return ""

    def _read_local_repo_version(self) -> str:
        if not self.local_repo_root:
            return ""
        for rel in ("updates/version.txt", "version.txt"):
            p = os.path.join(self.local_repo_root, rel)
            if os.path.isfile(p):
                try:
                    with open(p, "r", encoding="utf-8", errors="replace") as f:
                        v = clean_version(f.read())
                        if v:
                            return v
                except OSError:
                    pass
        return ""

    def resolve_latest_versions(self, force_network: bool = False) -> tuple[str, str, str]:
        """(配信最新バージョン, ローカルリポジトリ版, 取得元メモ) を返す。"""
        local_ver = self._read_local_repo_version()
        now = time.time()
        if force_network or (now - self._last_github_fetch >= self.github_version_ttl_sec):
            self._last_github_fetch = now
            for url in GITHUB_VERSION_URLS:
                try:
                    req = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
                    with urllib.request.urlopen(req, timeout=3.5) as resp:
                        txt = resp.read().decode("utf-8", errors="replace")
                        v = clean_version(txt)
                        if v and parse_version_tuple(v):
                            self._cached_github_ver = v
                            self._cached_github_source = "GitHub公開アップデート"
                            break
                except Exception:
                    continue

        pub_ver = self._cached_github_ver or local_ver
        source_note = self._cached_github_source if self._cached_github_ver else ("ローカルversion.txt" if local_ver else "未取得")
        return pub_ver, local_ver, source_note

    def _scan_cached(
        self,
        filepath: str,
        parser_fn: Any,
        stat_res: os.stat_result | None = None,
    ) -> _CachedFileResult | None:
        try:
            st = stat_res if stat_res is not None else os.stat(filepath)
        except OSError:
            self._file_cache.pop(filepath, None)
            return None

        cached = self._file_cache.get(filepath)
        if cached is not None and cached.mtime_ns == st.st_mtime_ns and cached.size == st.st_size:
            return cached

        ops, errs, meta = parser_fn(st.st_mtime)
        res = _CachedFileResult(
            mtime_ns=st.st_mtime_ns,
            size=st.st_size,
            operations=ops,
            errors=errs,
            header_meta=meta,
        )
        self._file_cache[filepath] = res
        return res

    def _load_cached_pin_records(self, factory_code: str, bin_path: str) -> list[OperatorPinRecord]:
        try:
            st = os.stat(bin_path)
        except OSError:
            self._pin_records_cache.pop((factory_code, bin_path), None)
            return []
        cache_key = (factory_code, bin_path)
        cached = self._pin_records_cache.get(cache_key)
        if cached is not None and cached[0] == st.st_mtime_ns and cached[1] == st.st_size:
            return cached[2]
        try:
            recs = load_factory_pin_records(factory_code, bin_path)
        except Exception:
            recs = []
        self._pin_records_cache[cache_key] = (st.st_mtime_ns, st.st_size, recs)
        return recs

    def invalidate_pin_cache(self) -> None:
        self._pin_records_cache.clear()

    def scan(
        self,
        lookback_days: int = 14,
        force_version_check: bool = False,
        now_epoch: float | None = None,
    ) -> MonitorSnapshot:
        t0 = time.perf_counter()
        now_ts = now_epoch if now_epoch is not None else time.time()
        today_date = datetime.date.fromtimestamp(now_ts)
        today_iso = today_date.isoformat()
        cutoff_date = today_date - datetime.timedelta(days=max(1, lookback_days))
        cutoff_iso = cutoff_date.isoformat()

        pub_ver, local_ver, ver_note = self.resolve_latest_versions(force_network=force_version_check)

        factories_reach: dict[str, FactoryReachability] = {}
        all_ops: list[OperationEvent] = []
        raw_errors: list[ErrorEvent] = []
        all_pin_records: list[OperatorPinRecord] = []
        operator_store_paths: dict[str, str] = {}
        pin_map: dict[tuple[str, str], OperatorPinRecord] = {}

        # (factory_code, operator) -> ユーザーメタ集約
        user_registry: dict[tuple[str, str], dict[str, Any]] = {}

        def ensure_user(f_code: str, f_label: str, op_name: str, data_dir: str) -> dict[str, Any]:
            key = (f_code, op_name)
            if key not in user_registry:
                user_registry[key] = {
                    "factory_code": f_code,
                    "factory_label": f_label,
                    "operator": op_name,
                    "version": "",
                    "version_epoch": 0.0,
                    "last_epoch": 0.0,
                    "last_action_summary": "履歴なし",
                    "last_feature_ja": "-",
                    "host": "",
                    "os_user": "",
                    "today_ops": 0,
                    "action_log_dir": os.path.join(data_dir, "操作ログ", op_name),
                    "remote_log_dir": os.path.join(data_dir, "remote_log", op_name),
                }
            return user_registry[key]

        for target in self.factory_targets:
            data_dir, online = resolve_accessible_dir(target.primary_data_dir, target.unc_data_dir)
            if not online:
                factories_reach[target.code] = FactoryReachability(
                    code=target.code,
                    label_ja=target.label_ja,
                    resolved_dir=data_dir,
                    online=False,
                    operator_count=0,
                )
                continue

            discovered_ops_for_factory: set[str] = set()
            primary_store_path = os.path.join(data_dir, "factory-operator-users.bin")
            operator_store_paths[target.code] = primary_store_path

            # 0) factory-operator-users.bin (PMOU正本・PIN管理情報込み) / rdp-launcher-operator-users.bin / *_RPA設定.ini から登録操作者名を網羅取得
            if os.path.isfile(primary_store_path):
                f_pin_recs = self._load_cached_pin_records(target.code, primary_store_path)
                for p_rec in f_pin_recs:
                    all_pin_records.append(p_rec)
                    pin_map[(target.code, p_rec.name)] = p_rec
                    discovered_ops_for_factory.add(p_rec.name)
                    ensure_user(target.code, target.label_ja, p_rec.name, data_dir)

            for bin_name in ("factory-operator-users.bin", "rdp-launcher-operator-users.bin"):
                bin_path = os.path.join(data_dir, bin_name)
                if os.path.isfile(bin_path):
                    b_res = self._scan_cached(
                        bin_path,
                        lambda _mt, bp=bin_path, fc=target.code: (
                            [],
                            [],
                            {"registered_names": "\n".join(parse_operator_users_bin(bp, fc))},
                        ),
                    )
                    if b_res is not None:
                        names_blob = b_res.header_meta.get("registered_names", "")
                        for op_n in names_blob.splitlines():
                            op_n = op_n.strip()
                            if op_n:
                                discovered_ops_for_factory.add(op_n)
                                ensure_user(target.code, target.label_ja, op_n, data_dir)

            try:
                for entry in os.scandir(data_dir):
                    if entry.is_file():
                        m_ini = RPA_INI_RE.match(entry.name)
                        if m_ini:
                            op_n = m_ini.group(1).strip()
                            if op_n and op_n.lower() != "unknown" and op_n != "ゲスト":
                                discovered_ops_for_factory.add(op_n)
                                ensure_user(target.code, target.label_ja, op_n, data_dir)
            except OSError:
                pass

            # 1) 操作ログ/<operator>/YYYY-MM-DD.ndjson
            action_root = os.path.join(data_dir, "操作ログ")
            if os.path.isdir(action_root):
                try:
                    op_dirs = [e for e in os.scandir(action_root) if e.is_dir()]
                except OSError:
                    op_dirs = []

                for op_dir in op_dirs:
                    op_name = op_dir.name.strip()
                    if not op_name:
                        continue
                    if op_name.lower() != "unknown":
                        discovered_ops_for_factory.add(op_name)
                        u_rec = ensure_user(target.code, target.label_ja, op_name, data_dir)
                    else:
                        u_rec = None

                    try:
                        ndjson_files = sorted(
                            [f for f in os.scandir(op_dir.path) if f.is_file() and f.name.endswith(".ndjson")],
                            key=lambda x: x.name,
                            reverse=True,
                        )
                    except OSError:
                        ndjson_files = []

                    # lookback_days 以内のファイル ＋ 最新1ファイル（長期間未ログインユーザーの最終版数把握用）
                    for idx, f_entry in enumerate(ndjson_files):
                        f_date = f_entry.name[:10]
                        in_window = f_date >= cutoff_iso
                        if not in_window and idx > 0:
                            continue

                        try:
                            f_st = f_entry.stat()
                        except OSError:
                            continue
                        res = self._scan_cached(
                            f_entry.path,
                            lambda mt, p=f_entry.path, fc=target.code, fl=target.label_ja, on=op_name: parse_action_ndjson_file(
                                p, fc, fl, on, mt
                            ),
                            stat_res=f_st,
                        )
                        if res is None:
                            continue

                        if in_window:
                            all_ops.extend(res.operations)
                            raw_errors.extend(res.errors)

                        # ユーザー最新状態の更新
                        for op_ev in res.operations:
                            t_rec = u_rec
                            if t_rec is None and op_ev.operator and op_ev.operator.lower() != "unknown":
                                discovered_ops_for_factory.add(op_ev.operator)
                                t_rec = ensure_user(target.code, target.label_ja, op_ev.operator, data_dir)
                            if t_rec is None:
                                continue

                            if op_ev.ts_display.startswith(today_iso):
                                t_rec["today_ops"] += 1

                            if op_ev.epoch >= t_rec["last_epoch"]:
                                t_rec["last_epoch"] = op_ev.epoch
                                t_rec["last_action_summary"] = op_ev.summary_ja
                                t_rec["last_feature_ja"] = op_ev.feature_ja or "-"
                                if op_ev.host:
                                    t_rec["host"] = op_ev.host
                                if op_ev.os_user:
                                    t_rec["os_user"] = op_ev.os_user

                            if op_ev.app_version and op_ev.epoch >= t_rec["version_epoch"]:
                                t_rec["version"] = op_ev.app_version
                                t_rec["version_epoch"] = op_ev.epoch

            # 2) remote_log/<operator>/{ui_daily/*.txt, <gen>/{meta.json, ui_run_log.txt, execution_log.txt}}
            remote_root = os.path.join(data_dir, "remote_log")
            if os.path.isdir(remote_root):
                try:
                    r_op_dirs = [e for e in os.scandir(remote_root) if e.is_dir()]
                except OSError:
                    r_op_dirs = []

                for r_op in r_op_dirs:
                    op_name = r_op.name.strip()
                    if not op_name:
                        continue
                    if op_name.lower() != "unknown":
                        discovered_ops_for_factory.add(op_name)
                        u_rec = ensure_user(target.code, target.label_ja, op_name, data_dir)
                    else:
                        u_rec = None

                    # 2a) ui_daily/*.txt
                    ui_daily_dir = os.path.join(r_op.path, "ui_daily")
                    if os.path.isdir(ui_daily_dir):
                        try:
                            daily_files = sorted(
                                [f for f in os.scandir(ui_daily_dir) if f.is_file() and f.name.endswith(".txt")],
                                key=lambda x: x.name,
                                reverse=True,
                            )
                        except OSError:
                            daily_files = []

                        for idx, df in enumerate(daily_files):
                            d_str = df.name[:10]
                            in_window = d_str >= cutoff_iso
                            if not in_window and idx > 0:
                                continue

                            try:
                                df_st = df.stat()
                            except OSError:
                                continue
                            res = self._scan_cached(
                                df.path,
                                lambda mt, p=df.path, fc=target.code, fl=target.label_ja, on=op_name, ds=d_str: parse_ui_or_exec_log_file(
                                    p, fc, fl, on, mt, ds, extract_operations=True
                                ),
                                stat_res=df_st,
                            )
                            if res is None:
                                continue
                            if in_window:
                                all_ops.extend(res.operations)
                                raw_errors.extend(res.errors)

                            if u_rec is not None:
                                mt_sec = res.mtime_ns / 1e9
                                ver = res.header_meta.get("app_version", "")
                                if ver and mt_sec >= u_rec["version_epoch"]:
                                    u_rec["version"] = ver
                                    u_rec["version_epoch"] = mt_sec
                                if res.header_meta.get("host") and not u_rec["host"]:
                                    u_rec["host"] = res.header_meta["host"]
                                if res.header_meta.get("os_user") and not u_rec["os_user"]:
                                    u_rec["os_user"] = res.header_meta["os_user"]
                                if mt_sec > u_rec["last_epoch"] and u_rec["last_epoch"] == 0.0:
                                    u_rec["last_epoch"] = mt_sec
                                    u_rec["last_action_summary"] = "UI日次ログ記録"

                    # 2b) 世代フォルダ (<yyyyMMdd-HHmmss_stage>)
                    try:
                        gen_dirs = sorted(
                            [
                                g
                                for g in os.scandir(r_op.path)
                                if g.is_dir() and g.name != "ui_daily"
                            ],
                            key=lambda x: x.name,
                            reverse=True,
                        )
                    except OSError:
                        gen_dirs = []

                    for g_dir in gen_dirs:
                        m_gen = GEN_DIR_RE.match(g_dir.name)
                        if not m_gen:
                            continue
                        g_date = f"{m_gen.group(1)}-{m_gen.group(2)}-{m_gen.group(3)}"
                        if g_date < cutoff_iso:
                            continue

                        try:
                            g_mtime_ns = g_dir.stat().st_mtime_ns
                        except OSError:
                            continue

                        cached_gen = self._gen_dir_cache.get(g_dir.path)
                        if cached_gen is not None and cached_gen[0] == g_mtime_ns:
                            gen_meta = cached_gen[1]
                            raw_errors.extend(cached_gen[2])
                            if u_rec is not None:
                                m_ep = float(gen_meta.get("last_epoch") or 0.0)
                                ver = gen_meta.get("app_version", "")
                                if ver and m_ep >= u_rec["version_epoch"]:
                                    u_rec["version"] = ver
                                    u_rec["version_epoch"] = m_ep
                            continue

                        gen_meta = {}
                        gen_errs: list[ErrorEvent] = []
                        try:
                            g_files = {gf.name: gf for gf in os.scandir(g_dir.path) if gf.is_file()}
                        except OSError:
                            g_files = {}

                        meta_entry = g_files.get("meta.json")
                        if meta_entry is not None:
                            try:
                                meta_st = meta_entry.stat()
                            except OSError:
                                meta_st = None
                            m_res = self._scan_cached(
                                meta_entry.path,
                                lambda mt, p=meta_entry.path, fc=target.code, fl=target.label_ja, on=op_name: parse_stage_meta_json(
                                    p, fc, fl, on, mt
                                ),
                                stat_res=meta_st,
                            )
                            if m_res is not None:
                                gen_meta = m_res.header_meta
                                gen_errs.extend(m_res.errors)
                                if u_rec is not None:
                                    m_ep = float(gen_meta.get("last_epoch") or 0.0)
                                    ver = gen_meta.get("app_version", "")
                                    if ver and m_ep >= u_rec["version_epoch"]:
                                        u_rec["version"] = ver
                                        u_rec["version_epoch"] = m_ep

                        for log_leaf in ("ui_run_log.txt", "execution_log.txt"):
                            l_entry = g_files.get(log_leaf)
                            if l_entry is None:
                                continue
                            try:
                                l_st = l_entry.stat()
                            except OSError:
                                l_st = None
                            l_res = self._scan_cached(
                                l_entry.path,
                                lambda mt, p=l_entry.path, fc=target.code, fl=target.label_ja, on=op_name, ds=g_date, gm=dict(gen_meta): parse_ui_or_exec_log_file(
                                    p, fc, fl, on, mt, ds, fallback_meta=gm, extract_operations=False
                                ),
                                stat_res=l_st,
                            )
                            if l_res is not None:
                                gen_errs.extend(l_res.errors)

                        self._gen_dir_cache[g_dir.path] = (g_mtime_ns, dict(gen_meta), gen_errs)
                        raw_errors.extend(gen_errs)

            # 3) launcher-logs/launcher-YYYYMMDD.log
            launcher_dir = os.path.join(data_dir, "launcher-logs")
            if os.path.isdir(launcher_dir):
                try:
                    l_files = sorted(
                        [f for f in os.scandir(launcher_dir) if f.is_file() and f.name.endswith(".log")],
                        key=lambda x: x.name,
                        reverse=True,
                    )
                except OSError:
                    l_files = []

                for lf in l_files:
                    ml = LAUNCHER_FILE_RE.match(lf.name)
                    if not ml:
                        continue
                    l_date = f"{ml.group(1)}-{ml.group(2)}-{ml.group(3)}"
                    if l_date < cutoff_iso:
                        continue
                    try:
                        lf_st = lf.stat()
                    except OSError:
                        lf_st = None
                    l_res = self._scan_cached(
                        lf.path,
                        lambda mt, p=lf.path, fc=target.code, fl=target.label_ja: (
                            *parse_rpa_launcher_log(p, fc, fl, mt),
                            {},
                        ),
                        stat_res=lf_st,
                    )
                    if l_res is not None:
                        all_ops.extend(l_res.operations)
                        raw_errors.extend(l_res.errors)
                        for rpa_op in l_res.operations:
                            if rpa_op.operator and rpa_op.operator not in ("RPAランチャー", "ゲスト", "unknown"):
                                discovered_ops_for_factory.add(rpa_op.operator)
                                r_rec = ensure_user(target.code, target.label_ja, rpa_op.operator, data_dir)
                                if rpa_op.ts_display.startswith(today_iso):
                                    r_rec["today_ops"] += 1
                                if rpa_op.epoch >= r_rec["last_epoch"]:
                                    r_rec["last_epoch"] = rpa_op.epoch
                                    r_rec["last_action_summary"] = rpa_op.summary_ja
                                    r_rec["last_feature_ja"] = rpa_op.feature_ja or "RPAランチャー"
                                # PMD本体の版数が未記録の場合のみランチャー版数を補完（本体版数を上書きしない）
                                if rpa_op.app_version and not r_rec["version"]:
                                    r_rec["version"] = rpa_op.app_version

            factories_reach[target.code] = FactoryReachability(
                code=target.code,
                label_ja=target.label_ja,
                resolved_dir=data_dir,
                online=True,
                operator_count=len(discovered_ops_for_factory),
            )

        # 4) エラーのシグネチャ重複集約 (ui_daily と session/stage スナップショットの重複を1件に統合)
        dedup_errors: dict[str, ErrorEvent] = {}
        for err in raw_errors:
            if err.date_str < cutoff_iso:
                continue
            existing = dedup_errors.get(err.signature_id)
            if existing is None:
                # コピーを作って保持（キャッシュ内オブジェクトを破壊しない）
                dedup_errors[err.signature_id] = ErrorEvent(
                    signature_id=err.signature_id,
                    factory_code=err.factory_code,
                    factory_label=err.factory_label,
                    operator=err.operator,
                    epoch=err.epoch,
                    first_seen_epoch=err.first_seen_epoch,
                    ts_display=err.ts_display,
                    date_str=err.date_str,
                    severity=err.severity,
                    category=err.category,
                    headline=err.headline,
                    code_location=err.code_location,
                    stack_trace=err.stack_trace,
                    app_version=err.app_version,
                    host=err.host,
                    os_user=err.os_user,
                    source_path=err.source_path,
                    occurrence_count=1,
                )
            else:
                # ui_daily と ui_run_log の両方に同じ行が出ているだけの場合は ui_daily を優先しつつカウントしすぎない工夫:
                # 同一ソース種類（例: ui_daily 内で複数回）なら加算、別スナップショット由来はスタックトレースやメタ情報を補完
                same_source_file = existing.source_path == err.source_path
                if same_source_file:
                    existing.occurrence_count += 1
                if err.epoch > existing.epoch:
                    existing.epoch = err.epoch
                    existing.ts_display = err.ts_display
                if err.first_seen_epoch < existing.first_seen_epoch:
                    existing.first_seen_epoch = err.first_seen_epoch
                if len(err.stack_trace) > len(existing.stack_trace):
                    existing.stack_trace = err.stack_trace
                if not existing.code_location and err.code_location:
                    existing.code_location = err.code_location
                if not existing.app_version and err.app_version:
                    existing.app_version = err.app_version
                if not existing.host and err.host:
                    existing.host = err.host
                if not existing.os_user and err.os_user:
                    existing.os_user = err.os_user
                if "ui_daily" in err.source_path and "ui_daily" not in existing.source_path:
                    existing.source_path = err.source_path

        # 5) 操作イベントのソート & エラー直前の操作履歴の相関付け
        all_ops.sort(key=lambda o: o.epoch, reverse=True)

        ops_by_user: dict[tuple[str, str], list[OperationEvent]] = {}
        for op in all_ops:
            ops_by_user.setdefault((op.factory_code, op.operator), []).append(op)

        merged_errors = list(dedup_errors.values())
        merged_errors.sort(key=lambda e: (e.date_str, e.severity_rank, e.epoch), reverse=True)

        for err in merged_errors:
            u_ops = ops_by_user.get((err.factory_code, err.operator), [])
            # エラー発生時刻以前（または同日）の直近操作を最大5件紐付け
            preceding = [
                op
                for op in u_ops
                if op.epoch <= err.epoch + 60.0 and op.source_kind == "action_log"
            ][:5]
            if not preceding:
                preceding = [
                    op for op in u_ops if op.ts_display.startswith(err.date_str)
                ][:5]
            err.preceding_ops = preceding

        # 6) ユーザー別エラー件数集計 & バージョン判定
        err_counts_today: dict[tuple[str, str], int] = {}
        warn_counts_today: dict[tuple[str, str], int] = {}
        err_counts_recent: dict[tuple[str, str], int] = {}
        warn_counts_recent: dict[tuple[str, str], int] = {}

        for err in merged_errors:
            ukey = (err.factory_code, err.operator)
            if err.is_error_or_critical:
                err_counts_recent[ukey] = err_counts_recent.get(ukey, 0) + 1
                if err.date_str == today_iso:
                    err_counts_today[ukey] = err_counts_today.get(ukey, 0) + 1
            else:
                warn_counts_recent[ukey] = warn_counts_recent.get(ukey, 0) + 1
                if err.date_str == today_iso:
                    warn_counts_today[ukey] = warn_counts_today.get(ukey, 0) + 1

        users_out: list[UserStatusSummary] = []
        for ukey, rec in user_registry.items():
            ver = rec["version"]
            if not ver or not pub_ver:
                v_status = "unknown"
            else:
                cmp_v = compare_versions(ver, pub_ver)
                if cmp_v == 0:
                    v_status = "latest"
                elif cmp_v > 0:
                    v_status = "ahead"
                else:
                    v_status = "outdated"

            last_ep = float(rec["last_epoch"])
            is_today = (
                last_ep > 0
                and datetime.date.fromtimestamp(last_ep) == today_date
            )
            is_online = last_ep > 0 and (now_ts - last_ep) <= 1800.0  # 30分以内

            pin_rec = pin_map.get(ukey)
            f_store_path = operator_store_paths.get(rec["factory_code"], "")

            users_out.append(
                UserStatusSummary(
                    factory_code=rec["factory_code"],
                    factory_label=rec["factory_label"],
                    operator=rec["operator"],
                    current_version=ver,
                    version_status=v_status,
                    last_active_epoch=last_ep,
                    last_action_summary=rec["last_action_summary"],
                    last_feature_ja=rec["last_feature_ja"],
                    host=rec["host"],
                    os_user=rec["os_user"],
                    today_op_count=int(rec["today_ops"]),
                    today_error_count=err_counts_today.get(ukey, 0),
                    today_warn_count=warn_counts_today.get(ukey, 0),
                    recent_error_count=err_counts_recent.get(ukey, 0),
                    recent_warn_count=warn_counts_recent.get(ukey, 0),
                    is_online_now=is_online,
                    is_active_today=is_today,
                    action_log_dir=rec["action_log_dir"],
                    remote_log_dir=rec["remote_log_dir"],
                    pin_plaintext=pin_rec.pin_plaintext if pin_rec else "",
                    has_pin=pin_rec.has_pin if pin_rec else False,
                    pin_status_ja=pin_rec.pin_status_ja if pin_rec else "⚪ 未登録(ログのみ)",
                    pin_is_locked=pin_rec.is_locked if pin_rec else False,
                    pin_must_change=pin_rec.must_change if pin_rec else False,
                    pin_failed_attempts=pin_rec.failed_attempts if pin_rec else 0,
                    is_admin_user=pin_rec.is_admin if pin_rec else False,
                    aladdin_login_id=pin_rec.aladdin_login_id if pin_rec else "",
                    has_aladdin_password=pin_rec.has_aladdin_password if pin_rec else False,
                    operator_store_path=pin_rec.store_path if pin_rec else f_store_path,
                    is_registered_in_store=(pin_rec is not None),
                )
            )

        # ソート順: 本日エラーあり優先 → 稼働中 → 最終アクティブ日時降順
        users_out.sort(
            key=lambda u: (
                u.today_error_count > 0,
                u.is_online_now,
                u.is_active_today,
                u.last_active_epoch,
            ),
            reverse=True,
        )

        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        return MonitorSnapshot(
            scanned_at_epoch=now_ts,
            scan_duration_ms=elapsed_ms,
            latest_published_version=pub_ver,
            local_repo_version=local_ver,
            version_source_note=ver_note,
            factories=factories_reach,
            users=users_out,
            operations=all_ops,
            errors=merged_errors,
            pin_records=all_pin_records,
            operator_store_paths=operator_store_paths,
        )
