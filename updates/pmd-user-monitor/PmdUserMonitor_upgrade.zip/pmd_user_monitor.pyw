# -*- coding: utf-8 -*-
"""
PMD 国分・湖南工場 ユーザー稼働・操作・内部エラー常駐監視トレイアプリ
========================================================================
- 国分工場・湖南工場の全ユーザーについて以下をリアルタイム常駐監視:
  1. どのバージョンを使用しているか（GitHub配信最新版との自動比較・旧版ハイライト）
  2. どの操作をおこなっているか（全タブ・段階1/2・Excel出力・同一化・後加工賃・RPA起動）
  3. 内部エラーが発生しているか（Java未捕捉例外・Pythonエラー・Stage異常終了・業務エラー）
- タスクトレイ常駐 ＋ 非フォーカス奪取型スライドアップ通知ポップアップ ＋ 4タブ統合ダッシュボード
"""
from __future__ import annotations

import csv
import datetime
import json
import os
import struct
import subprocess
import sys
import time
import winsound
from typing import Any

from PySide6.QtCore import (
    QBuffer,
    QIODevice,
    QObject,
    QPoint,
    QRect,
    QSize,
    Qt,
    QThread,
    QTimer,
    Signal,
)
from PySide6.QtGui import (
    QAction,
    QClipboard,
    QColor,
    QCursor,
    QFont,
    QGuiApplication,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QSplitter,
    QSystemTrayIcon,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

# 同ディレクトリの monitor_core / monitor_updater をインポート可能にする
if getattr(sys, "frozen", False):
    INSTALL_DIR = os.environ.get("PMD_USER_MONITOR_INSTALL_DIR") or os.path.dirname(
        os.path.abspath(sys.executable)
    )
    APP_DIR = os.environ.get("PMD_USER_MONITOR_APP_DIR") or os.path.dirname(
        os.path.abspath(__file__)
    )
    APP_EXEC_PATH = os.path.abspath(sys.executable)
else:
    APP_EXEC_PATH = os.path.abspath(__file__)
    APP_DIR = os.environ.get("PMD_USER_MONITOR_APP_DIR") or os.path.dirname(APP_EXEC_PATH)
    INSTALL_DIR = os.environ.get("PMD_USER_MONITOR_INSTALL_DIR") or APP_DIR

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from monitor_core import (  # noqa: E402
    ErrorEvent,
    FACTORY_TARGETS,
    IncrementalLogScanner,
    MonitorSnapshot,
    OperationEvent,
    UserStatusSummary,
    compare_versions,
    format_ai_diagnostic_report,
    format_epoch,
    format_relative_ago,
    format_short_ts,
    nfkc_lower,
)
from monitor_updater import (  # noqa: E402
    MonitorUpdateInfo,
    check_github_differential_update,
    download_and_apply_differential_update,
    is_git_working_tree,
    read_local_monitor_version,
)
from operator_pin_store import (  # noqa: E402
    FACTORY_LABELS_JA,
    MAX_PIN_LENGTH,
    MIN_PIN_LENGTH,
    PinBackupEntry,
    add_operator_user,
    create_store_backup,
    generate_random_pin,
    list_store_backups,
    normalize_pin,
    reissue_random_pin,
    remove_operator_user,
    restore_store_from_backup,
    set_operator_admin_role,
    set_operator_pin,
    unlock_operator_pin,
)

# ---------------------------------------------------------------------------
# アプリ識別・ローカル設定パス
# ---------------------------------------------------------------------------
APP_NAME = "PMD 工場ユーザー・エラー監視トレイ"
APP_VERSION = read_local_monitor_version(APP_DIR, fallback="1.00")
SINGLE_INSTANCE_KEY = "PMD_Factory_User_Error_Monitor_SingleInstance_v1"

LOCAL_STATE_DIR = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "PmdUserMonitor",
)
os.makedirs(LOCAL_STATE_DIR, exist_ok=True)
CONFIG_PATH = os.path.join(LOCAL_STATE_DIR, "config.json")
SEEN_STATE_PATH = os.path.join(LOCAL_STATE_DIR, "seen_errors.json")

STARTUP_DIR = os.path.join(
    os.environ.get("APPDATA", ""),
    r"Microsoft\Windows\Start Menu\Programs\Startup",
)
STARTUP_LNK_PATH = os.path.join(STARTUP_DIR, "PMDユーザー監視トレイ.lnk")

DEFAULT_CONFIG: dict[str, Any] = {
    "poll_interval_sec": 5,
    "lookback_days": 14,
    "popup_on_error": True,
    "popup_on_warn": False,
    "popup_on_outdated_start": False,
    "keep_popup_until_handled": True,
    "popup_auto_close_sec": 20,
    "play_sound": True,
    "reminder_interval_min": 15,  # 0=OFF, 5, 15, 30, 60
    "open_dashboard_on_manual_start": True,
    "hide_tab_select_in_timeline": True,
    "show_pin_in_tables": True,
    "auto_check_github_update": True,
    "auto_apply_update_in_tray": True,
    "custom_github_update_url": "",
}


# ---------------------------------------------------------------------------
# OS連携・音・スタートアップ登録ユーティリティ
# ---------------------------------------------------------------------------
def open_path_in_os(path: str) -> None:
    try:
        if path and os.path.exists(path):
            os.startfile(path)
        elif path and os.path.isdir(os.path.dirname(path)):
            os.startfile(os.path.dirname(path))
        else:
            QMessageBox.information(None, APP_NAME, f"対象パスが見つかりません:\n{path}")
    except Exception as exc:
        QMessageBox.warning(None, APP_NAME, f"開けませんでした:\n{path}\n\n{exc}")


def select_file_in_explorer(filepath: str) -> None:
    try:
        norm = os.path.normpath(filepath)
        if os.path.exists(norm):
            subprocess.Popen(["explorer.exe", f"/select,{norm}"])
        else:
            parent = os.path.dirname(norm)
            if os.path.exists(parent):
                os.startfile(parent)
    except Exception:
        pass


def play_alert_chime(is_critical: bool = True) -> None:
    try:
        winsound.MessageBeep(
            winsound.MB_ICONHAND if is_critical else winsound.MB_ICONASTERISK
        )
    except Exception:
        pass


def is_startup_registered() -> bool:
    return os.path.exists(STARTUP_LNK_PATH)


def set_startup_registered(enable: bool) -> tuple[bool, str]:
    try:
        if not enable:
            if os.path.exists(STARTUP_LNK_PATH):
                os.remove(STARTUP_LNK_PATH)
            return True, "Windowsスタートアップ登録を解除しました。"

        os.makedirs(STARTUP_DIR, exist_ok=True)
        vbs_launcher = os.path.join(APP_DIR, "PMDユーザー監視トレイ起動.vbs")
        ico_path = os.path.join(APP_DIR, "pmd_user_monitor.ico")

        if getattr(sys, "frozen", False):
            target_path = sys.executable
            args = "--startup"
            work_dir = os.path.dirname(sys.executable)
            icon_loc = sys.executable
        elif os.path.exists(vbs_launcher):
            target_path = os.path.join(
                os.environ.get("WINDIR", r"C:\Windows"), "System32", "wscript.exe"
            )
            args = f'"{vbs_launcher}" --startup'
            work_dir = APP_DIR
            icon_loc = ico_path if os.path.exists(ico_path) else target_path
        else:
            pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
            target_path = pyw if os.path.exists(pyw) else sys.executable
            args = f'"{APP_EXEC_PATH}" --startup'
            work_dir = APP_DIR
            icon_loc = ico_path if os.path.exists(ico_path) else target_path

        # PowerShell WScript.Shell COM でショートカット作成（pywin32 非依存）
        ps_script = (
            "$ws = New-Object -ComObject WScript.Shell; "
            f"$sc = $ws.CreateShortcut('{STARTUP_LNK_PATH.replace(chr(39), chr(39)*2)}'); "
            f"$sc.TargetPath = '{target_path.replace(chr(39), chr(39)*2)}'; "
            f"$sc.Arguments = '{args.replace(chr(39), chr(39)*2)}'; "
            f"$sc.WorkingDirectory = '{work_dir.replace(chr(39), chr(39)*2)}'; "
            f"$sc.IconLocation = '{icon_loc.replace(chr(39), chr(39)*2)}'; "
            "$sc.Description = 'PMD 国分・湖南工場 ユーザー・内部エラー常駐監視ツール'; "
            "$sc.Save()"
        )
        subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_script],
            check=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000),
        )
        return True, "Windowsスタートアップに登録しました（PC起動時に自動常駐します）。"
    except Exception as exc:
        return False, f"スタートアップ設定に失敗しました: {exc}"


# ---------------------------------------------------------------------------
# 高精細ベクタータスクトレイアイコン描画
# ---------------------------------------------------------------------------
def create_monitor_pixmap(
    unread_error_count: int = 0,
    online: bool = True,
    has_outdated_active: bool = False,
    size: int = 64,
) -> QPixmap:
    pix = QPixmap(size, size)
    pix.fill(Qt.GlobalColor.transparent)

    p = QPainter(pix)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

    pad = max(2, int(size * 0.06))
    box_w = size - pad * 2
    rect = QRect(pad, pad, box_w, box_w)
    grad = QLinearGradient(0, pad, 0, size - pad)

    if not online:
        grad.setColorAt(0.0, QColor("#64748b"))
        grad.setColorAt(1.0, QColor("#334155"))
        border_col = QColor("#94a3b8")
    elif unread_error_count > 0:
        grad.setColorAt(0.0, QColor("#ef4444"))
        grad.setColorAt(1.0, QColor("#b91c1c"))
        border_col = QColor("#fecaca")
    else:
        grad.setColorAt(0.0, QColor("#0ea5e9"))
        grad.setColorAt(0.55, QColor("#0284c7"))
        grad.setColorAt(1.0, QColor("#0f766e"))
        border_col = QColor("#bae6fd")

    radius = size * 0.22
    bg_path = QPainterPath()
    bg_path.addRoundedRect(rect, radius, radius)
    p.fillPath(bg_path, grad)
    p.setPen(QPen(border_col, max(1.5, size * 0.035)))
    p.drawPath(bg_path)

    if not online:
        p.setPen(QColor("#e2e8f0"))
        f = QFont("Segoe UI", max(10, int(size * 0.38)), QFont.Weight.Bold)
        p.setFont(f)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, "?")
    elif unread_error_count > 0:
        # 上部に「ERR」小ラベル、中央に未読件数
        p.setPen(QColor("#fee2e2"))
        f_top = QFont("Segoe UI", max(6, int(size * 0.14)), QFont.Weight.Bold)
        p.setFont(f_top)
        p.drawText(
            QRect(pad, int(size * 0.11), box_w, int(size * 0.20)),
            Qt.AlignmentFlag.AlignCenter,
            "ERR",
        )

        badge_text = str(unread_error_count) if unread_error_count < 100 else "99+"
        p.setPen(QColor("#ffffff"))
        f_cnt = QFont(
            "Segoe UI",
            max(10, int(size * (0.36 if len(badge_text) <= 2 else 0.27))),
            QFont.Weight.Black,
        )
        p.setFont(f_cnt)
        p.drawText(
            QRect(pad, int(size * 0.28), box_w, int(size * 0.58)),
            Qt.AlignmentFlag.AlignCenter,
            badge_text,
        )
    else:
        # 正常監視中: モニターパルス波形 ＋ PMD ラベル
        p.setPen(QColor("#e0f2fe"))
        f_lbl = QFont("Segoe UI", max(7, int(size * 0.17)), QFont.Weight.ExtraBold)
        p.setFont(f_lbl)
        p.drawText(
            QRect(pad, int(size * 0.13), box_w, int(size * 0.24)),
            Qt.AlignmentFlag.AlignCenter,
            "PMD",
        )

        wave = QPainterPath()
        y_mid = size * 0.63
        wave.moveTo(size * 0.18, y_mid)
        wave.lineTo(size * 0.34, y_mid)
        wave.lineTo(size * 0.43, size * 0.43)
        wave.lineTo(size * 0.53, size * 0.80)
        wave.lineTo(size * 0.62, size * 0.54)
        wave.lineTo(size * 0.68, y_mid)
        wave.lineTo(size * 0.82, y_mid)

        pen = QPen(
            QColor("#ffffff"),
            max(2.0, size * 0.065),
            Qt.PenStyle.SolidLine,
            Qt.PenCapStyle.RoundCap,
            Qt.PenJoinStyle.RoundJoin,
        )
        p.setPen(pen)
        p.drawPath(wave)

        # 本日旧版稼働中ユーザーがいる場合は右上にアンバー小ドットを表示
        if has_outdated_active:
            dot_r = int(size * 0.13)
            p.setBrush(QColor("#f59e0b"))
            p.setPen(QPen(QColor("#ffffff"), max(1.2, size * 0.025)))
            p.drawEllipse(QPoint(int(size * 0.80), int(size * 0.20)), dot_r, dot_r)

    p.end()
    return pix


def create_monitor_tray_icon(
    unread_error_count: int = 0,
    online: bool = True,
    has_outdated_active: bool = False,
) -> QIcon:
    icon = QIcon()
    for sz in (16, 24, 32, 48, 64):
        icon.addPixmap(create_monitor_pixmap(unread_error_count, online, has_outdated_active, sz))
    return icon


def save_monitor_ico(dest_path: str) -> None:
    """マルチ解像度(16/24/32/48/64/256px) PNGフレーム格納型の Windows .ico ファイルを生成する。"""
    sizes = (16, 24, 32, 48, 64, 256)
    png_frames: list[tuple[int, bytes]] = []
    for sz in sizes:
        pix = create_monitor_pixmap(0, True, False, sz)
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        pix.save(buf, "PNG")
        png_frames.append((sz, bytes(buf.data())))
        buf.close()

    header = struct.pack("<HHH", 0, 1, len(png_frames))
    dir_entries = bytearray()
    payload = bytearray()
    offset = 6 + 16 * len(png_frames)
    for sz, png_bytes in png_frames:
        dim = 0 if sz >= 256 else sz
        dir_entries.extend(
            struct.pack(
                "<BBBBHHII",
                dim,
                dim,
                0,
                0,
                1,
                32,
                len(png_bytes),
                offset,
            )
        )
        payload.extend(png_bytes)
        offset += len(png_bytes)

    os.makedirs(os.path.dirname(os.path.abspath(dest_path)), exist_ok=True)
    with open(dest_path, "wb") as f:
        f.write(header)
        f.write(dir_entries)
        f.write(payload)


# ---------------------------------------------------------------------------
# バックグラウンドスキャンワーカー (UI非ブロッキング)
# ---------------------------------------------------------------------------
class ScanWorker(QThread):
    snapshot_ready = Signal(object)
    scan_failed = Signal(str)

    def __init__(
        self,
        scanner: IncrementalLogScanner,
        lookback_days: int,
        force_version_check: bool = False,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.scanner = scanner
        self.lookback_days = lookback_days
        self.force_version_check = force_version_check

    def run(self) -> None:
        try:
            snap = self.scanner.scan(
                lookback_days=self.lookback_days,
                force_version_check=self.force_version_check,
            )
            self.snapshot_ready.emit(snap)
        except Exception as exc:
            self.scan_failed.emit(str(exc))


class UpdateCheckWorker(QThread):
    update_checked = Signal(object, bool)

    def __init__(
        self,
        current_version: str,
        custom_base_url: str = "",
        manual: bool = False,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.current_version = current_version
        self.custom_base_url = custom_base_url
        self.manual = manual

    def run(self) -> None:
        info = check_github_differential_update(
            current_version=self.current_version,
            custom_base_url=self.custom_base_url,
            timeout_sec=6.0,
        )
        self.update_checked.emit(info, self.manual)


class UpdateApplyWorker(QThread):
    update_applied = Signal(str, object)
    update_failed = Signal(str)

    def __init__(
        self,
        update_info: MonitorUpdateInfo,
        target_app_dir: str,
        custom_base_url: str = "",
        backup_dir: str | None = None,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.update_info = update_info
        self.target_app_dir = target_app_dir
        self.custom_base_url = custom_base_url
        self.backup_dir = backup_dir

    def run(self) -> None:
        try:
            new_ver, updated_files = download_and_apply_differential_update(
                update_info=self.update_info,
                target_app_dir=self.target_app_dir,
                custom_base_url=self.custom_base_url,
                backup_dir=self.backup_dir,
                timeout_sec=20.0,
            )
            self.update_applied.emit(new_ver, updated_files)
        except Exception as exc:
            self.update_failed.emit(str(exc))


# ---------------------------------------------------------------------------
# 画面右下スライドアップ通知ポップアップ（フォーカスを奪わない）
# ---------------------------------------------------------------------------
class ErrorAlertPopup(QWidget):
    def __init__(
        self,
        on_open_error_tab_cb: Any,
        on_mark_all_read_cb: Any,
        on_copy_report_cb: Any,
    ) -> None:
        super().__init__(None)
        self.on_open_error_tab_cb = on_open_error_tab_cb
        self.on_mark_all_read_cb = on_mark_all_read_cb
        self.on_copy_report_cb = on_copy_report_cb
        self.current_errors: list[ErrorEvent] = []

        self.setWindowFlags(
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)

        self.auto_close_timer = QTimer(self)
        self.auto_close_timer.setSingleShot(True)
        self.auto_close_timer.timeout.connect(self.hide_popup)

        self._build_ui()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        self.card = QFrame(self)
        self.card.setObjectName("alertCard")
        self.card.setStyleSheet(
            """
            QFrame#alertCard {
                background-color: #0f172a;
                border: 2px solid #ef4444;
                border-radius: 12px;
            }
            QLabel {
                color: #f8fafc;
                font-family: "Yu Gothic UI", "Meiryo UI", sans-serif;
            }
            QPushButton[class="primaryAction"] {
                background-color: #dc2626;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 7px 12px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton[class="primaryAction"]:hover {
                background-color: #b91c1c;
            }
            QPushButton[class="subAction"] {
                background-color: #334155;
                color: #f1f5f9;
                border: 1px solid #475569;
                border-radius: 6px;
                padding: 7px 10px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton[class="subAction"]:hover {
                background-color: #475569;
            }
            QPushButton[class="miniCopyBtn"] {
                background-color: #2563eb;
                color: #ffffff;
                border: none;
                border-radius: 5px;
                padding: 4px 8px;
                font-size: 11px;
                font-weight: bold;
            }
            QPushButton[class="miniCopyBtn"]:hover {
                background-color: #1d4ed8;
            }
            """
        )

        shadow = QGraphicsDropShadowEffect(self.card)
        shadow.setBlurRadius(24)
        shadow.setOffset(0, 6)
        shadow.setColor(QColor(0, 0, 0, 175))
        self.card.setGraphicsEffect(shadow)

        card_layout = QVBoxLayout(self.card)
        card_layout.setContentsMargins(16, 14, 16, 14)
        card_layout.setSpacing(10)

        header_row = QHBoxLayout()
        self.title_lbl = QLabel("🚨 PMD 内部エラーを検知しました")
        self.title_lbl.setStyleSheet("font-size: 14px; font-weight: bold; color: #fca5a5;")
        header_row.addWidget(self.title_lbl, 1)

        self.badge_lbl = QLabel("")
        self.badge_lbl.setStyleSheet(
            "background-color: #dc2626; color: #ffffff; font-weight: bold; "
            "font-size: 11px; padding: 2px 8px; border-radius: 10px;"
        )
        header_row.addWidget(self.badge_lbl)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(24, 24)
        close_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        close_btn.setStyleSheet(
            "QPushButton { background: transparent; color: #94a3b8; border: none; font-size: 14px; font-weight: bold; }"
            "QPushButton:hover { color: #ffffff; background-color: #334155; border-radius: 4px; }"
        )
        close_btn.clicked.connect(self.hide_popup)
        header_row.addWidget(close_btn)
        card_layout.addLayout(header_row)

        self.subtitle_lbl = QLabel("")
        self.subtitle_lbl.setStyleSheet("font-size: 11px; color: #cbd5e1;")
        card_layout.addWidget(self.subtitle_lbl)

        self.items_container = QWidget(self.card)
        self.items_layout = QVBoxLayout(self.items_container)
        self.items_layout.setContentsMargins(0, 0, 0, 0)
        self.items_layout.setSpacing(6)
        card_layout.addWidget(self.items_container)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        open_err_btn = QPushButton("🔍 エラー詳細・直前操作を確認")
        open_err_btn.setProperty("class", "primaryAction")
        open_err_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        open_err_btn.clicked.connect(self._on_open_detail)
        btn_row.addWidget(open_err_btn, 1)

        ack_btn = QPushButton("✓ すべて既読にして閉じる")
        ack_btn.setProperty("class", "subAction")
        ack_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        ack_btn.clicked.connect(self._on_ack_close)
        btn_row.addWidget(ack_btn)

        card_layout.addLayout(btn_row)
        outer.addWidget(self.card)
        self.setFixedWidth(500)

    def show_errors(
        self,
        new_errors: list[ErrorEvent],
        unread_errors: list[ErrorEvent],
        keep_until_handled: bool,
        auto_close_sec: int,
        title_override: str | None = None,
    ) -> None:
        self.current_errors = unread_errors if unread_errors else new_errors

        if title_override:
            self.title_lbl.setText(title_override)
        elif len(new_errors) == 1:
            e0 = new_errors[0]
            self.title_lbl.setText(f"🚨 [{e0.factory_label}] {e0.operator} さんで内部エラー発生")
        else:
            self.title_lbl.setText(f"🚨 新たに {len(new_errors)}件 の内部エラーを検知しました")

        self.badge_lbl.setText(f"未確認 {len(self.current_errors)}件")
        now_str = datetime.datetime.now().strftime("%H:%M:%S")
        mode_note = "既読または[✕]まで維持" if keep_until_handled else f"{auto_close_sec}秒後に自動消去"
        self.subtitle_lbl.setText(f"検知時刻: {now_str}  （{mode_note}）")

        while self.items_layout.count():
            child = self.items_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        new_sigs = {e.signature_id for e in new_errors}
        for err in self.current_errors[:4]:
            row_frame = QFrame(self.items_container)
            is_new = err.signature_id in new_sigs
            border_c = "#ef4444" if err.severity == "critical" else ("#f97316" if is_new else "#334155")
            row_frame.setStyleSheet(
                f"QFrame {{ background-color: #1e293b; border: 1px solid {border_c}; border-radius: 7px; }}"
            )
            rl = QHBoxLayout(row_frame)
            rl.setContentsMargins(10, 7, 10, 7)
            rl.setSpacing(8)

            info_col = QVBoxLayout()
            info_col.setSpacing(2)

            loc_part = f" @ {err.code_location}" if err.code_location else ""
            top_line = QLabel(
                f"[{err.factory_label}] {err.operator} (v{err.app_version or '?'}) — {err.category}{loc_part}"
            )
            top_line.setStyleSheet("font-size: 11px; font-weight: bold; color: #fde047; border: none;")
            info_col.addWidget(top_line)

            hl_lbl = QLabel(err.headline[:115] + ("…" if len(err.headline) > 115 else ""))
            hl_lbl.setStyleSheet("font-size: 11px; color: #f8fafc; border: none;")
            hl_lbl.setWordWrap(True)
            info_col.addWidget(hl_lbl)

            rl.addLayout(info_col, 1)

            copy_btn = QPushButton("📋 AI用コピー")
            copy_btn.setProperty("class", "miniCopyBtn")
            copy_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            copy_btn.clicked.connect(lambda _c=False, ev=err: self.on_copy_report_cb(ev))
            rl.addWidget(copy_btn)

            self.items_layout.addWidget(row_frame)

        if len(self.current_errors) > 4:
            more = QLabel(f"…他 {len(self.current_errors) - 4} 件の未確認エラーがあります")
            more.setStyleSheet("font-size: 11px; color: #fbbf24; padding-left: 4px;")
            self.items_layout.addWidget(more)

        self.adjustSize()
        self._position_bottom_right()
        self.show()
        self.raise_()

        self.auto_close_timer.stop()
        if not keep_until_handled and auto_close_sec > 0:
            self.auto_close_timer.start(auto_close_sec * 1000)

    def _position_bottom_right(self) -> None:
        screen = QGuiApplication.primaryScreen()
        if not screen:
            return
        avail = screen.availableGeometry()
        w = self.width()
        h = self.sizeHint().height()
        self.resize(w, h)
        x = avail.right() - w - 16
        y = avail.bottom() - h - 16
        self.move(max(avail.left() + 8, x), max(avail.top() + 8, y))

    def _on_open_detail(self) -> None:
        target_sig = self.current_errors[0].signature_id if self.current_errors else ""
        self.hide_popup()
        self.on_open_error_tab_cb(target_sig)

    def _on_ack_close(self) -> None:
        self.on_mark_all_read_cb()
        self.hide_popup()

    def hide_popup(self) -> None:
        self.auto_close_timer.stop()
        self.hide()


# ---------------------------------------------------------------------------
# メイン監視ダッシュボードウィンドウ
# ---------------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self, controller: "PmdUserMonitorApp") -> None:
        super().__init__()
        self.controller = controller
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.setWindowIcon(create_monitor_tray_icon(0, True, False))
        self.resize(1280, 820)

        self._displayed_users: list[UserStatusSummary] = []
        self._displayed_pin_users: list[UserStatusSummary] = []
        self._displayed_errors: list[ErrorEvent] = []
        self._displayed_timeline_ops: list[OperationEvent] = []
        self._selected_user_key: tuple[str, str] | None = None
        self._selected_pin_user_key: tuple[str, str] | None = None
        self._selected_error_sig: str = ""
        self._suppress_settings_save = False

        self._build_ui()

    def _build_ui(self) -> None:
        central = QWidget(self)
        central.setObjectName("centralBg")
        self.setCentralWidget(central)
        central.setStyleSheet(
            """
            QWidget {
                font-family: "Yu Gothic UI", "Meiryo UI", sans-serif;
                color: #1e293b;
            }
            QMainWindow, QWidget#centralBg {
                background-color: #f1f5f9;
            }
            QFrame[class="kpiCard"] {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 10px;
            }
            QFrame[class="panelCard"] {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 10px;
            }
            QPushButton[class="primaryBtn"] {
                background-color: #2563eb;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 6px 13px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton[class="primaryBtn"]:hover {
                background-color: #1d4ed8;
            }
            QPushButton[class="secondaryBtn"] {
                background-color: #ffffff;
                color: #334155;
                border: 1px solid #94a3b8;
                border-radius: 6px;
                padding: 6px 11px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton[class="secondaryBtn"]:hover {
                background-color: #f8fafc;
                border-color: #475569;
            }
            QPushButton[class="dangerBtn"] {
                background-color: #fef2f2;
                color: #b91c1c;
                border: 1px solid #fca5a5;
                border-radius: 6px;
                padding: 6px 11px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton[class="dangerBtn"]:hover {
                background-color: #fee2e2;
            }
            QLineEdit, QComboBox {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                padding: 5px 9px;
                font-size: 12px;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 1px solid #2563eb;
            }
            QTableWidget {
                background-color: #ffffff;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                gridline-color: #e2e8f0;
                font-size: 12px;
                selection-background-color: #dbeafe;
                selection-color: #0f172a;
            }
            QHeaderView::section {
                background-color: #f8fafc;
                color: #334155;
                font-weight: bold;
                font-size: 12px;
                padding: 6px 8px;
                border: none;
                border-bottom: 1px solid #cbd5e1;
            }
            QTabWidget::pane {
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                background-color: #ffffff;
                top: -1px;
            }
            QTabBar::tab {
                background-color: #e2e8f0;
                color: #475569;
                font-weight: bold;
                font-size: 12px;
                padding: 8px 16px;
                margin-right: 4px;
                border-top-left-radius: 7px;
                border-top-right-radius: 7px;
            }
            QTabBar::tab:selected {
                background-color: #ffffff;
                color: #1d4ed8;
                border: 1px solid #cbd5e1;
                border-bottom-color: #ffffff;
            }
            """
        )

        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(14, 12, 14, 12)
        root_layout.setSpacing(10)

        # 1. 上部ステータスバナー
        self.banner = QFrame(central)
        self.banner.setFixedHeight(64)
        b_lay = QHBoxLayout(self.banner)
        b_lay.setContentsMargins(16, 8, 16, 8)
        b_lay.setSpacing(12)

        b_text_col = QVBoxLayout()
        b_text_col.setSpacing(2)
        self.banner_title_lbl = QLabel("🔄 国分・湖南工場の共有ログを初回スキャン中…")
        self.banner_title_lbl.setStyleSheet("font-size: 15px; font-weight: bold;")
        b_text_col.addWidget(self.banner_title_lbl)

        self.banner_sub_lbl = QLabel("配信最新バージョン確認中…")
        self.banner_sub_lbl.setStyleSheet("font-size: 11px;")
        b_text_col.addWidget(self.banner_sub_lbl)
        b_lay.addLayout(b_text_col, 1)

        self.btn_self_upgrade = QPushButton("✨ バージョンアップ")
        self.btn_self_upgrade.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_self_upgrade.setVisible(False)
        self.btn_self_upgrade.clicked.connect(lambda: self.controller.apply_self_update(interactive=True))
        b_lay.addWidget(self.btn_self_upgrade)

        self._upgrade_pulse_state = False
        self._upgrade_pulse_timer = QTimer(self)
        self._upgrade_pulse_timer.setInterval(750)
        self._upgrade_pulse_timer.timeout.connect(self._tick_upgrade_button_glow)

        self.btn_mark_all_read = QPushButton("✅ 未確認エラーをすべて既読")
        self.btn_mark_all_read.setProperty("class", "secondaryBtn")
        self.btn_mark_all_read.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_mark_all_read.clicked.connect(self.controller.mark_all_errors_read)
        b_lay.addWidget(self.btn_mark_all_read)

        self.btn_rescan = QPushButton("🔄 今すぐ再スキャン")
        self.btn_rescan.setProperty("class", "primaryBtn")
        self.btn_rescan.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_rescan.clicked.connect(self._on_rescan_clicked)
        b_lay.addWidget(self.btn_rescan)

        root_layout.addWidget(self.banner)

        # 2. KPI サマリーカード (4枚)
        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(10)
        self.kpi_users_val, self.kpi_users_sub = self._create_kpi_card(
            kpi_row, "👥 本日稼働 / 登録ユーザー", "-", "湖南 -名 / 国分 -名", "#0284c7"
        )
        self.kpi_ver_val, self.kpi_ver_sub = self._create_kpi_card(
            kpi_row, "📦 バージョン普及状況", "-", "配信最新: -", "#059669"
        )
        self.kpi_ops_val, self.kpi_ops_sub = self._create_kpi_card(
            kpi_row, "🖱️ 本日の操作アクティビティ", "-", "期間総操作数: -", "#4f46e5"
        )
        self.kpi_err_val, self.kpi_err_sub = self._create_kpi_card(
            kpi_row, "🚨 内部エラー監視", "-", "未確認エラー: 0件", "#dc2626"
        )
        root_layout.addLayout(kpi_row)

        # 3. 共通フィルタバー
        filter_card = QFrame(central)
        filter_card.setProperty("class", "panelCard")
        fl = QHBoxLayout(filter_card)
        fl.setContentsMargins(12, 7, 12, 7)
        fl.setSpacing(10)

        fl.addWidget(QLabel("🏭 工場:"))
        self.cmb_factory = QComboBox()
        self.cmb_factory.addItem("全工場 (国分＋湖南)", "ALL")
        self.cmb_factory.addItem("湖南工場のみ", "KONAN")
        self.cmb_factory.addItem("国分工場のみ", "KOKUBU")
        self.cmb_factory.currentIndexChanged.connect(self.refresh_views_from_snapshot)
        fl.addWidget(self.cmb_factory)

        fl.addWidget(QLabel("👤 ユーザー:"))
        self.cmb_operator = QComboBox()
        self.cmb_operator.setMinimumWidth(120)
        self.cmb_operator.addItem("（全員）", "ALL")
        self.cmb_operator.currentIndexChanged.connect(self.refresh_views_from_snapshot)
        fl.addWidget(self.cmb_operator)

        fl.addWidget(QLabel("📅 監視期間:"))
        self.cmb_days = QComboBox()
        for label, days in (
            ("今日のみ", 1),
            ("直近3日間", 3),
            ("直近7日間", 7),
            ("直近14日間", 14),
            ("直近30日間", 30),
        ):
            self.cmb_days.addItem(label, days)
        self.cmb_days.currentIndexChanged.connect(self._on_lookback_days_changed)
        fl.addWidget(self.cmb_days)

        fl.addWidget(QLabel("🔍 横断検索:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("ユーザー名・バージョン・操作名・エラーメッセージ・PC名で即座に絞り込み…")
        self.txt_search.setClearButtonEnabled(True)
        self.txt_search.textChanged.connect(self.refresh_views_from_snapshot)
        fl.addWidget(self.txt_search, 1)

        root_layout.addWidget(filter_card)

        # 4. メイン5タブ（管理者専用 PIN・ユーザー管理タブ搭載）
        self.tabs = QTabWidget(central)
        self.tabs.addTab(self._build_users_tab(), "👥 工場・ユーザー別稼働＆バージョン")
        self.tabs.addTab(self._build_errors_tab(), "🚨 内部エラー・例外監視")
        self.tabs.addTab(self._build_timeline_tab(), "🖱️ リアルタイム操作タイムライン")
        self.tabs.addTab(self._build_pin_management_tab(), "🔑 ユーザー・PIN管理")
        self.tabs.addTab(self._build_settings_tab(), "⚙️ 監視・通知・スタートアップ設定")
        root_layout.addWidget(self.tabs, 1)

        self._apply_banner_style("normal")

    def _create_kpi_card(
        self,
        parent_layout: QHBoxLayout,
        title: str,
        init_val: str,
        init_sub: str,
        accent_hex: str,
    ) -> tuple[QLabel, QLabel]:
        card = QFrame()
        card.setProperty("class", "kpiCard")
        card.setStyleSheet(
            f"QFrame[class='kpiCard'] {{ background-color: #ffffff; border: 1px solid #cbd5e1; "
            f"border-left: 5px solid {accent_hex}; border-radius: 9px; }}"
        )
        vl = QVBoxLayout(card)
        vl.setContentsMargins(12, 8, 12, 8)
        vl.setSpacing(2)

        t_lbl = QLabel(title)
        t_lbl.setStyleSheet("font-size: 11px; font-weight: bold; color: #64748b; border: none;")
        vl.addWidget(t_lbl)

        v_lbl = QLabel(init_val)
        v_lbl.setStyleSheet("font-size: 18px; font-weight: bold; color: #0f172a; border: none;")
        vl.addWidget(v_lbl)

        s_lbl = QLabel(init_sub)
        s_lbl.setStyleSheet("font-size: 11px; color: #475569; border: none;")
        vl.addWidget(s_lbl)

        parent_layout.addWidget(card, 1)
        return v_lbl, s_lbl

    # --- Tab 1: ユーザー別稼働＆バージョン ---
    def _build_users_tab(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        splitter = QSplitter(Qt.Orientation.Vertical, page)

        top_w = QWidget()
        top_l = QVBoxLayout(top_w)
        top_l.setContentsMargins(0, 0, 0, 0)
        top_l.setSpacing(4)

        top_bar = QHBoxLayout()
        top_bar.setSpacing(8)
        hint_lbl = QLabel(
            "💡 行クリックで下部に操作・エラー履歴表示 ／ 右クリックまたは [PIN番号] ダブルクリックで即座にPIN確認・変更できます。"
        )
        hint_lbl.setStyleSheet("font-size: 11px; color: #475569;")
        top_bar.addWidget(hint_lbl, 1)

        self.chk_show_pins_tab1 = QCheckBox("👁️ PIN番号を表示")
        self.chk_show_pins_tab1.setChecked(True)
        self.chk_show_pins_tab1.toggled.connect(self._on_show_pin_toggled)
        top_bar.addWidget(self.chk_show_pins_tab1)

        btn_t1_copy_pin = QPushButton("📋 PINコピー")
        btn_t1_copy_pin.setProperty("class", "secondaryBtn")
        btn_t1_copy_pin.clicked.connect(lambda: self._copy_user_pin_to_clipboard(self._current_selected_tab1_user()))
        top_bar.addWidget(btn_t1_copy_pin)

        btn_t1_edit_pin = QPushButton("✏️ PIN変更…")
        btn_t1_edit_pin.setProperty("class", "secondaryBtn")
        btn_t1_edit_pin.clicked.connect(lambda: self._dialog_change_user_pin(self._current_selected_tab1_user()))
        top_bar.addWidget(btn_t1_edit_pin)

        btn_t1_pin_tab = QPushButton("🔑 PIN・ユーザー管理タブへ")
        btn_t1_pin_tab.setProperty("class", "primaryBtn")
        btn_t1_pin_tab.clicked.connect(self._jump_to_pin_tab_for_selected)
        top_bar.addWidget(btn_t1_pin_tab)

        top_l.addLayout(top_bar)

        self.tbl_users = QTableWidget(0, 10, top_w)
        self.tbl_users.setHorizontalHeaderLabels(
            [
                "稼働状態",
                "工場",
                "ユーザー名",
                "PIN番号",
                "使用バージョン",
                "直近の操作内容",
                "最終操作日時",
                "本日操作数",
                "内部エラー(今日/期間)",
                "PC名 / OSユーザー",
            ]
        )
        self._configure_readonly_table(self.tbl_users)
        uh = self.tbl_users.horizontalHeader()
        uh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        uh.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(8, QHeaderView.ResizeMode.ResizeToContents)
        uh.setSectionResizeMode(9, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_users.itemSelectionChanged.connect(self._on_user_row_selected)
        self.tbl_users.cellDoubleClicked.connect(self._on_users_table_double_clicked)
        self.tbl_users.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tbl_users.customContextMenuRequested.connect(self._on_users_table_context_menu)
        top_l.addWidget(self.tbl_users, 1)
        splitter.addWidget(top_w)

        # 下部: 選択ユーザーの詳細ペイン
        bot_w = QWidget()
        bot_l = QVBoxLayout(bot_w)
        bot_l.setContentsMargins(0, 4, 0, 0)
        bot_l.setSpacing(6)

        u_bar = QHBoxLayout()
        self.lbl_user_detail_title = QLabel("👤 ユーザー詳細: （上の表からユーザーを選択してください）")
        self.lbl_user_detail_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #0f172a;")
        u_bar.addWidget(self.lbl_user_detail_title, 1)

        self.chk_user_ops_no_tab = QCheckBox("画面切替(tab_select)を除いて表示")
        self.chk_user_ops_no_tab.setChecked(False)
        self.chk_user_ops_no_tab.toggled.connect(self._refresh_selected_user_detail)
        u_bar.addWidget(self.chk_user_ops_no_tab)

        btn_open_act = QPushButton("📂 操作ログフォルダ")
        btn_open_act.setProperty("class", "secondaryBtn")
        btn_open_act.clicked.connect(self._open_selected_user_action_dir)
        u_bar.addWidget(btn_open_act)

        btn_open_rem = QPushButton("📂 remote_logフォルダ")
        btn_open_rem.setProperty("class", "secondaryBtn")
        btn_open_rem.clicked.connect(self._open_selected_user_remote_dir)
        u_bar.addWidget(btn_open_rem)
        bot_l.addLayout(u_bar)

        sub_split = QSplitter(Qt.Orientation.Horizontal, bot_w)

        self.tbl_user_ops = QTableWidget(0, 4, sub_split)
        self.tbl_user_ops.setHorizontalHeaderLabels(["日時", "版数", "操作内容", "結果"])
        self._configure_readonly_table(self.tbl_user_ops)
        uoh = self.tbl_user_ops.horizontalHeader()
        uoh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        uoh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        uoh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        uoh.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        sub_split.addWidget(self.tbl_user_ops)

        self.tbl_user_errs = QTableWidget(0, 4, sub_split)
        self.tbl_user_errs.setHorizontalHeaderLabels(["日時", "重要度", "版数", "エラー・警告概要（ダブルクリックで詳細へ）"])
        self._configure_readonly_table(self.tbl_user_errs)
        ueh = self.tbl_user_errs.horizontalHeader()
        ueh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        ueh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        ueh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        ueh.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.tbl_user_errs.cellDoubleClicked.connect(self._on_user_err_double_clicked)
        sub_split.addWidget(self.tbl_user_errs)

        sub_split.setSizes([600, 560])
        bot_l.addWidget(sub_split, 1)
        splitter.addWidget(bot_w)
        splitter.setSizes([340, 240])

        lay.addWidget(splitter, 1)
        return page

    # --- Tab 2: 内部エラー・例外監視 ---
    def _build_errors_tab(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        bar = QHBoxLayout()
        bar.setSpacing(8)

        bar.addWidget(QLabel("表示レベル:"))
        self.cmb_err_sev = QComboBox()
        self.cmb_err_sev.addItem("🔴 重大・エラーのみ（推奨）", "errors_only")
        self.cmb_err_sev.addItem("🟡 警告（読込失敗・API制限等）も含む", "all")
        self.cmb_err_sev.currentIndexChanged.connect(self.refresh_views_from_snapshot)
        bar.addWidget(self.cmb_err_sev)

        self.chk_unread_only = QCheckBox("未確認のみ表示")
        self.chk_unread_only.setChecked(False)
        self.chk_unread_only.toggled.connect(self.refresh_views_from_snapshot)
        bar.addWidget(self.chk_unread_only)

        bar.addStretch(1)

        btn_ack_sel = QPushButton("✓ 選択行を既読にする")
        btn_ack_sel.setProperty("class", "secondaryBtn")
        btn_ack_sel.clicked.connect(self._mark_selected_error_read)
        bar.addWidget(btn_ack_sel)

        btn_copy_ai = QPushButton("📋 AI調査・修正用レポートをコピー")
        btn_copy_ai.setProperty("class", "primaryBtn")
        btn_copy_ai.clicked.connect(self._copy_selected_error_report)
        bar.addWidget(btn_copy_ai)

        btn_open_log = QPushButton("📄 元ログを開く")
        btn_open_log.setProperty("class", "secondaryBtn")
        btn_open_log.clicked.connect(self._open_selected_error_file)
        bar.addWidget(btn_open_log)

        btn_sel_exp = QPushButton("📂 フォルダで表示")
        btn_sel_exp.setProperty("class", "secondaryBtn")
        btn_sel_exp.clicked.connect(self._reveal_selected_error_file)
        bar.addWidget(btn_sel_exp)

        lay.addLayout(bar)

        splitter = QSplitter(Qt.Orientation.Vertical, page)

        self.tbl_errors = QTableWidget(0, 9, splitter)
        self.tbl_errors.setHorizontalHeaderLabels(
            [
                "状態",
                "重要度",
                "発生日時",
                "工場",
                "ユーザー",
                "発生版数",
                "分類 / 発生箇所",
                "エラー概要",
                "回数",
            ]
        )
        self._configure_readonly_table(self.tbl_errors)
        eh = self.tbl_errors.horizontalHeader()
        eh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        eh.setSectionResizeMode(7, QHeaderView.ResizeMode.Stretch)
        eh.setSectionResizeMode(8, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl_errors.itemSelectionChanged.connect(self._on_error_row_selected)
        splitter.addWidget(self.tbl_errors)

        detail_wrap = QWidget()
        dl = QVBoxLayout(detail_wrap)
        dl.setContentsMargins(0, 4, 0, 0)
        dl.setSpacing(4)
        dl_lbl = QLabel("🔍 選択エラーの詳細診断レポート（直前ユーザー操作履歴 ＋ スタックトレース）")
        dl_lbl.setStyleSheet("font-size: 12px; font-weight: bold; color: #0f172a;")
        dl.addWidget(dl_lbl)

        self.txt_error_detail = QTextEdit()
        self.txt_error_detail.setReadOnly(True)
        self.txt_error_detail.setStyleSheet(
            "QTextEdit { background-color: #0f172a; color: #f8fafc; font-family: 'Consolas', 'Yu Gothic UI', monospace; "
            "font-size: 12px; border-radius: 8px; padding: 10px; }"
        )
        dl.addWidget(self.txt_error_detail, 1)
        splitter.addWidget(detail_wrap)
        splitter.setSizes([310, 260])

        lay.addWidget(splitter, 1)
        return page

    # --- Tab 3: リアルタイム操作タイムライン ---
    def _build_timeline_tab(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        bar = QHBoxLayout()
        self.chk_hide_tab_select = QCheckBox("📑 単純な画面切替(tab_select)を除いて、主要業務操作のみ表示する")
        self.chk_hide_tab_select.toggled.connect(self._on_timeline_filter_toggled)
        bar.addWidget(self.chk_hide_tab_select)

        bar.addStretch(1)
        self.lbl_timeline_count = QLabel("0 件")
        self.lbl_timeline_count.setStyleSheet("font-size: 12px; color: #475569; font-weight: bold;")
        bar.addWidget(self.lbl_timeline_count)

        btn_csv = QPushButton("📊 表示中の操作履歴をCSV出力")
        btn_csv.setProperty("class", "secondaryBtn")
        btn_csv.clicked.connect(self._export_timeline_csv)
        bar.addWidget(btn_csv)
        lay.addLayout(bar)

        self.tbl_timeline = QTableWidget(0, 8, page)
        self.tbl_timeline.setHorizontalHeaderLabels(
            [
                "日時",
                "工場",
                "ユーザー",
                "使用版数",
                "機能・画面",
                "操作内容",
                "結果",
                "PC名 / OSユーザー",
            ]
        )
        self._configure_readonly_table(self.tbl_timeline)
        th = self.tbl_timeline.horizontalHeader()
        th.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        th.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        th.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        th.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        th.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        th.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        th.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        th.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        lay.addWidget(self.tbl_timeline, 1)
        return page

    # --- Tab 4: 管理者専用 ユーザー・PIN管理 ---
    def _build_pin_management_tab(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        # 上部案内カード
        info_card = QFrame(page)
        info_card.setStyleSheet(
            "QFrame { background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; }"
            "QLabel { color: #1e3a8a; border: none; background: transparent; }"
        )
        il = QHBoxLayout(info_card)
        il.setContentsMargins(12, 8, 12, 8)
        il.setSpacing(10)

        info_lbl = QLabel(
            "🔑 【管理者専用】国分・湖南工場の全ユーザーの現在のPIN番号確認・変更・ランダム再発行・ロック解除・新規登録を行えます。\n"
            "変更内容は各工場共有フォルダの factory-operator-users.bin へ自動世代バックアップ付きで即時反映されます。"
        )
        info_lbl.setStyleSheet("font-size: 11.5px; font-weight: bold;")
        il.addWidget(info_lbl, 1)

        self.chk_show_pins_tab4 = QCheckBox("👁️ PIN番号を平文表示")
        self.chk_show_pins_tab4.setStyleSheet("font-weight: bold; color: #1d4ed8;")
        self.chk_show_pins_tab4.setChecked(True)
        self.chk_show_pins_tab4.toggled.connect(self._on_show_pin_toggled)
        il.addWidget(self.chk_show_pins_tab4)

        lay.addWidget(info_card)

        # アクションボタン 1段目（選択ユーザーへのPIN操作）
        row1 = QHBoxLayout()
        row1.setSpacing(8)

        btn_edit_pin = QPushButton("✏️ PINを指定変更…")
        btn_edit_pin.setProperty("class", "primaryBtn")
        btn_edit_pin.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_edit_pin.clicked.connect(lambda: self._dialog_change_user_pin(self._current_selected_pin_tab_user()))
        row1.addWidget(btn_edit_pin)

        btn_rand_pin = QPushButton("🎲 ランダム4桁PIN再発行")
        btn_rand_pin.setProperty("class", "secondaryBtn")
        btn_rand_pin.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_rand_pin.clicked.connect(lambda: self._action_reissue_random_pin(self._current_selected_pin_tab_user()))
        row1.addWidget(btn_rand_pin)

        btn_unlock = QPushButton("🔓 ロック・失敗回数解除")
        btn_unlock.setProperty("class", "secondaryBtn")
        btn_unlock.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_unlock.clicked.connect(lambda: self._action_unlock_user_pin(self._current_selected_pin_tab_user()))
        row1.addWidget(btn_unlock)

        btn_copy_pin = QPushButton("📋 PINのみコピー")
        btn_copy_pin.setProperty("class", "secondaryBtn")
        btn_copy_pin.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_copy_pin.clicked.connect(
            lambda: self._copy_user_pin_to_clipboard(self._current_selected_pin_tab_user(), with_label=False)
        )
        row1.addWidget(btn_copy_pin)

        btn_copy_案内 = QPushButton("💬 案内文付きコピー")
        btn_copy_案内.setProperty("class", "secondaryBtn")
        btn_copy_案内.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_copy_案内.clicked.connect(
            lambda: self._copy_user_pin_to_clipboard(self._current_selected_pin_tab_user(), with_label=True)
        )
        row1.addWidget(btn_copy_案内)

        btn_admin_role = QPushButton("👑 管理者権限 切替")
        btn_admin_role.setProperty("class", "secondaryBtn")
        btn_admin_role.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_admin_role.clicked.connect(lambda: self._action_toggle_admin_role(self._current_selected_pin_tab_user()))
        row1.addWidget(btn_admin_role)

        row1.addStretch(1)
        lay.addLayout(row1)

        # アクションボタン 2段目（ユーザー追加削除・バックアップ・CSV）
        row2 = QHBoxLayout()
        row2.setSpacing(8)

        btn_add_user = QPushButton("➕ 新規ユーザー追加…")
        btn_add_user.setProperty("class", "secondaryBtn")
        btn_add_user.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_add_user.clicked.connect(self._dialog_add_operator_user)
        row2.addWidget(btn_add_user)

        btn_del_user = QPushButton("🗑️ ユーザー削除")
        btn_del_user.setProperty("class", "dangerBtn")
        btn_del_user.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_del_user.clicked.connect(lambda: self._action_remove_operator_user(self._current_selected_pin_tab_user()))
        row2.addWidget(btn_del_user)

        row2.addSpacing(12)

        btn_backup = QPushButton("💾 今すぐバックアップ作成")
        btn_backup.setProperty("class", "secondaryBtn")
        btn_backup.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_backup.clicked.connect(self._action_manual_pin_backup)
        row2.addWidget(btn_backup)

        btn_restore = QPushButton("⏪ バックアップから復元…")
        btn_restore.setProperty("class", "secondaryBtn")
        btn_restore.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_restore.clicked.connect(self._dialog_restore_pin_backup)
        row2.addWidget(btn_restore)

        btn_pin_csv = QPushButton("📊 PIN一覧CSV出力")
        btn_pin_csv.setProperty("class", "secondaryBtn")
        btn_pin_csv.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_pin_csv.clicked.connect(self._export_pins_csv)
        row2.addWidget(btn_pin_csv)

        row2.addStretch(1)
        self.lbl_pin_op_status = QLabel("")
        self.lbl_pin_op_status.setStyleSheet("font-size: 12px; font-weight: bold; color: #059669;")
        row2.addWidget(self.lbl_pin_op_status)
        lay.addLayout(row2)

        # PIN一覧テーブル
        self.tbl_pins = QTableWidget(0, 9, page)
        self.tbl_pins.setHorizontalHeaderLabels(
            [
                "工場",
                "ユーザー名",
                "現在のPIN番号",
                "PIN状態 / ロック状況",
                "権限",
                "アラジンRPA連携",
                "使用バージョン",
                "最終稼働日時",
                "正本ファイル",
            ]
        )
        self._configure_readonly_table(self.tbl_pins)
        ph = self.tbl_pins.horizontalHeader()
        ph.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        ph.setSectionResizeMode(8, QHeaderView.ResizeMode.Stretch)
        self.tbl_pins.itemSelectionChanged.connect(self._on_pin_row_selected)
        self.tbl_pins.cellDoubleClicked.connect(self._on_pin_table_double_clicked)
        self.tbl_pins.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tbl_pins.customContextMenuRequested.connect(self._on_pin_table_context_menu)
        lay.addWidget(self.tbl_pins, 1)

        return page

    # --- Tab 5: 監視・通知・スタートアップ設定 ---
    def _build_settings_tab(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(12)

        # 通知・ポーリング設定カード
        cfg_card = QFrame(page)
        cfg_card.setProperty("class", "panelCard")
        cl = QVBoxLayout(cfg_card)
        cl.setContentsMargins(16, 14, 16, 14)
        cl.setSpacing(10)

        t1 = QLabel("🔔 常駐監視・ポップアップ通知設定（変更すると即時保存されます）")
        t1.setStyleSheet("font-size: 13px; font-weight: bold; color: #0f172a;")
        cl.addWidget(t1)

        r1 = QHBoxLayout()
        r1.addWidget(QLabel("監視ポーリング間隔:"))
        self.cmb_poll_sec = QComboBox()
        for sec in (3, 5, 10, 15, 30, 60):
            self.cmb_poll_sec.addItem(f"{sec}秒おき" + ("（推奨）" if sec == 5 else ""), sec)
        self.cmb_poll_sec.currentIndexChanged.connect(self._on_settings_ui_changed)
        r1.addWidget(self.cmb_poll_sec)

        r1.addSpacing(20)
        r1.addWidget(QLabel("未確認エラーのリマインド再通知:"))
        self.cmb_reminder_min = QComboBox()
        self.cmb_reminder_min.addItem("OFF（初回検知時のみ）", 0)
        for m in (5, 15, 30, 60):
            self.cmb_reminder_min.addItem(f"{m}分おき", m)
        self.cmb_reminder_min.currentIndexChanged.connect(self._on_settings_ui_changed)
        r1.addWidget(self.cmb_reminder_min)
        r1.addStretch(1)
        cl.addLayout(r1)

        self.chk_popup_error = QCheckBox(
            "🚨 新規の内部エラー（クラッシュ・例外・異常終了）を検知したとき画面右下にポップアップ通知する"
        )
        self.chk_popup_error.toggled.connect(self._on_settings_ui_changed)
        cl.addWidget(self.chk_popup_error)

        self.chk_keep_popup = QCheckBox(
            "📌 離席時の見逃し防止（[既読] または [✕] を押すまでポップアップを閉じずに維持する）"
        )
        self.chk_keep_popup.toggled.connect(self._on_settings_ui_changed)
        cl.addWidget(self.chk_keep_popup)

        self.chk_popup_warn = QCheckBox(
            "⚠️ 警告レベル（起動時カレンダー読込失敗・API一時制限等）でもポップアップ通知する"
        )
        self.chk_popup_warn.toggled.connect(self._on_settings_ui_changed)
        cl.addWidget(self.chk_popup_warn)

        self.chk_play_sound = QCheckBox("🔊 エラー通知時にアラート音を鳴らす")
        self.chk_play_sound.toggled.connect(self._on_settings_ui_changed)
        cl.addWidget(self.chk_play_sound)

        self.chk_open_on_manual = QCheckBox(
            "🖥️ アイコンから手動起動したときはダッシュボード画面を開く（※Windowsスタートアップ自動起動時は常にトレイ格納）"
        )
        self.chk_open_on_manual.toggled.connect(self._on_settings_ui_changed)
        cl.addWidget(self.chk_open_on_manual)

        self.chk_win_startup = QCheckBox("🚀 Windows起動時にタスクトレイへ自動常駐する（スタートアップ登録）")
        self.chk_win_startup.setStyleSheet("font-weight: bold; color: #1d4ed8; margin-top: 4px;")
        self.chk_win_startup.toggled.connect(self._on_startup_checkbox_toggled)
        cl.addWidget(self.chk_win_startup)

        test_row = QHBoxLayout()
        btn_test_popup = QPushButton("🔔 エラー通知ポップアップをテスト表示")
        btn_test_popup.setProperty("class", "secondaryBtn")
        btn_test_popup.clicked.connect(self.controller.trigger_test_popup)
        test_row.addWidget(btn_test_popup)
        test_row.addStretch(1)
        cl.addLayout(test_row)

        lay.addWidget(cfg_card)

        # 監視ツール本体の GitHub 差分アップデートカード
        upd_card = QFrame(page)
        upd_card.setProperty("class", "panelCard")
        ul = QVBoxLayout(upd_card)
        ul.setContentsMargins(16, 14, 16, 14)
        ul.setSpacing(8)

        t_upd = QLabel(f"📦 監視ツール本体の GitHub 差分アップデート （現在バージョン: v{APP_VERSION}）")
        t_upd.setStyleSheet("font-size: 13px; font-weight: bold; color: #0f172a;")
        ul.addWidget(t_upd)

        self.lbl_self_update_status = QLabel("GitHub アップデート配信情報を確認待機中…")
        self.lbl_self_update_status.setStyleSheet(
            "font-family: 'Consolas', 'Yu Gothic UI', monospace; font-size: 12px; color: #334155;"
        )
        self.lbl_self_update_status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        ul.addWidget(self.lbl_self_update_status)

        self.chk_auto_check_update = QCheckBox(
            "🔄 GitHub 公開リポジトリからの差分アップデートを定期確認する（3分周期・本体ランタイム再DL不要）"
        )
        self.chk_auto_check_update.toggled.connect(self._on_settings_ui_changed)
        ul.addWidget(self.chk_auto_check_update)

        self.chk_auto_apply_tray = QCheckBox(
            "⚡ タスクトレイ格納中（画面非表示中）は新バージョン検知時に自動で差分アップデートを適用・再起動する"
        )
        self.chk_auto_apply_tray.toggled.connect(self._on_settings_ui_changed)
        ul.addWidget(self.chk_auto_apply_tray)

        upd_btn_row = QHBoxLayout()
        self.btn_check_update_now = QPushButton("🔍 今すぐGitHub更新を確認")
        self.btn_check_update_now.setProperty("class", "secondaryBtn")
        self.btn_check_update_now.clicked.connect(lambda: self.controller.request_self_update_check(manual=True))
        upd_btn_row.addWidget(self.btn_check_update_now)

        self.btn_apply_update_now = QPushButton("✨ 最新版へ差分アップデート適用")
        self.btn_apply_update_now.setProperty("class", "primaryBtn")
        self.btn_apply_update_now.setEnabled(False)
        self.btn_apply_update_now.clicked.connect(lambda: self.controller.apply_self_update(interactive=True))
        upd_btn_row.addWidget(self.btn_apply_update_now)

        upd_btn_row.addStretch(1)
        ul.addLayout(upd_btn_row)

        lay.addWidget(upd_card)

        # 共有フォルダ接続診断カード
        path_card = QFrame(page)
        path_card.setProperty("class", "panelCard")
        pl = QVBoxLayout(path_card)
        pl.setContentsMargins(16, 14, 16, 14)
        pl.setSpacing(8)

        t2 = QLabel("🌐 国分・湖南工場 監視パス接続ステータス")
        t2.setStyleSheet("font-size: 13px; font-weight: bold; color: #0f172a;")
        pl.addWidget(t2)

        self.lbl_path_diag = QLabel("スキャン待機中…")
        self.lbl_path_diag.setStyleSheet(
            "font-family: 'Consolas', 'Yu Gothic UI', monospace; font-size: 12px; color: #334155;"
        )
        self.lbl_path_diag.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        pl.addWidget(self.lbl_path_diag)

        btn_dirs = QHBoxLayout()
        for ft in FACTORY_TARGETS:
            b_act = QPushButton(f"📂 {ft.label_ja} 操作ログを開く")
            b_act.setProperty("class", "secondaryBtn")
            b_act.clicked.connect(lambda _c=False, code=ft.code: self.controller.open_factory_subdir(code, "操作ログ"))
            btn_dirs.addWidget(b_act)

            b_rem = QPushButton(f"📂 {ft.label_ja} remote_logを開く")
            b_rem.setProperty("class", "secondaryBtn")
            b_rem.clicked.connect(lambda _c=False, code=ft.code: self.controller.open_factory_subdir(code, "remote_log"))
            btn_dirs.addWidget(b_rem)
        btn_dirs.addStretch(1)
        pl.addLayout(btn_dirs)

        lay.addWidget(path_card)
        lay.addStretch(1)
        return page

    @staticmethod
    def _configure_readonly_table(tbl: QTableWidget) -> None:
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tbl.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        tbl.setAlternatingRowColors(True)

    def _apply_banner_style(self, mode: str) -> None:
        if mode == "offline":
            bg, border, fg = "#e2e8f0", "#94a3b8", "#334155"
        elif mode == "error":
            bg, border, fg = "#fef2f2", "#ef4444", "#991b1b"
        elif mode == "outdated":
            bg, border, fg = "#fffbeb", "#f59e0b", "#92400e"
        else:
            bg, border, fg = "#ecfdf5", "#10b981", "#065f46"
        self.banner.setStyleSheet(
            f"QFrame {{ background-color: {bg}; border: 1.5px solid {border}; border-radius: 10px; }}"
            f"QLabel {{ color: {fg}; border: none; background: transparent; }}"
        )

    def sync_controls_from_config(self, cfg: dict[str, Any]) -> None:
        self._suppress_settings_save = True
        try:
            idx_days = self.cmb_days.findData(int(cfg.get("lookback_days", 14)))
            if idx_days >= 0:
                self.cmb_days.setCurrentIndex(idx_days)

            idx_poll = self.cmb_poll_sec.findData(int(cfg.get("poll_interval_sec", 5)))
            if idx_poll >= 0:
                self.cmb_poll_sec.setCurrentIndex(idx_poll)

            idx_rem = self.cmb_reminder_min.findData(int(cfg.get("reminder_interval_min", 15)))
            if idx_rem >= 0:
                self.cmb_reminder_min.setCurrentIndex(idx_rem)

            self.chk_popup_error.setChecked(bool(cfg.get("popup_on_error", True)))
            self.chk_keep_popup.setChecked(bool(cfg.get("keep_popup_until_handled", True)))
            self.chk_popup_warn.setChecked(bool(cfg.get("popup_on_warn", False)))
            self.chk_play_sound.setChecked(bool(cfg.get("play_sound", True)))
            self.chk_open_on_manual.setChecked(bool(cfg.get("open_dashboard_on_manual_start", True)))
            self.chk_hide_tab_select.setChecked(bool(cfg.get("hide_tab_select_in_timeline", True)))
            show_pin = bool(cfg.get("show_pin_in_tables", True))
            self.chk_show_pins_tab1.setChecked(show_pin)
            self.chk_show_pins_tab4.setChecked(show_pin)
            self.chk_auto_check_update.setChecked(bool(cfg.get("auto_check_github_update", True)))
            self.chk_auto_apply_tray.setChecked(bool(cfg.get("auto_apply_update_in_tray", True)))

            self.chk_win_startup.blockSignals(True)
            self.chk_win_startup.setChecked(is_startup_registered())
            self.chk_win_startup.blockSignals(False)
        finally:
            self._suppress_settings_save = False

    def _on_rescan_clicked(self) -> None:
        self.controller.request_scan(force_version=True)
        self.controller.request_self_update_check(manual=False)

    def _tick_upgrade_button_glow(self) -> None:
        self._upgrade_pulse_state = not self._upgrade_pulse_state
        if self._upgrade_pulse_state:
            self.btn_self_upgrade.setStyleSheet(
                "QPushButton { background-color: #f59e0b; color: #ffffff; border: 2px solid #fde047; "
                "border-radius: 7px; padding: 6px 14px; font-weight: bold; font-size: 12px; }"
                "QPushButton:hover { background-color: #d97706; }"
            )
        else:
            self.btn_self_upgrade.setStyleSheet(
                "QPushButton { background-color: #d97706; color: #fffbeb; border: 2px solid #fbbf24; "
                "border-radius: 7px; padding: 6px 14px; font-weight: bold; font-size: 12px; }"
                "QPushButton:hover { background-color: #b45309; }"
            )

    def refresh_self_update_ui(
        self,
        info: MonitorUpdateInfo | None,
        applying: bool = False,
        status_override: str = "",
    ) -> None:
        if applying:
            self._upgrade_pulse_timer.stop()
            self.btn_self_upgrade.setVisible(True)
            self.btn_self_upgrade.setEnabled(False)
            self.btn_self_upgrade.setText("⏳ 差分アップデート適用中…")
            self.btn_self_upgrade.setStyleSheet(
                "QPushButton { background-color: #0284c7; color: #ffffff; border: none; "
                "border-radius: 7px; padding: 6px 14px; font-weight: bold; font-size: 12px; }"
            )
            self.btn_check_update_now.setEnabled(False)
            self.btn_apply_update_now.setEnabled(False)
            self.lbl_self_update_status.setText(status_override or "GitHub から差分ZIPをダウンロード・検証・適用しています…")
            return

        self.btn_check_update_now.setEnabled(True)
        if info is None:
            self._upgrade_pulse_timer.stop()
            self.btn_self_upgrade.setVisible(False)
            self.btn_apply_update_now.setEnabled(False)
            if status_override:
                self.lbl_self_update_status.setText(status_override)
            return

        checked_str = format_epoch(info.checked_at_epoch)
        if info.update_available and info.remote_version:
            label_txt = f"✨ バージョンアップ (v{APP_VERSION} → v{info.remote_version})"
            self.btn_self_upgrade.setText(label_txt)
            self.btn_self_upgrade.setEnabled(True)
            self.btn_self_upgrade.setVisible(True)
            self._tick_upgrade_button_glow()
            if not self._upgrade_pulse_timer.isActive():
                self._upgrade_pulse_timer.start()

            self.btn_apply_update_now.setEnabled(True)
            self.btn_apply_update_now.setText(f"✨ 最新版 (v{info.remote_version}) へ差分アップデート適用")
            lines = [
                f"✨ 新バージョン v{info.remote_version} が GitHub で配信されています！（現在: v{APP_VERSION} / 最終確認: {checked_str}）",
                f"配信元: {info.source_url}",
            ]
            if info.notes:
                lines.append(f"更新内容: {info.notes}")
            self.lbl_self_update_status.setText("\n".join(lines))
        else:
            self._upgrade_pulse_timer.stop()
            self.btn_self_upgrade.setVisible(False)
            self.btn_apply_update_now.setEnabled(False)
            self.btn_apply_update_now.setText("✨ 最新版へ差分アップデート適用")
            if info.remote_version:
                self.lbl_self_update_status.setText(
                    f"✅ 最新バージョンを使用中です （現在: v{APP_VERSION} / GitHub配信: v{info.remote_version} / 最終確認: {checked_str}）\n"
                    f"配信元: {info.source_url}"
                )
            else:
                self.lbl_self_update_status.setText(
                    f"ℹ️ 現在バージョン: v{APP_VERSION} （最終確認: {checked_str}）\n"
                    f"状態: {info.error or '未配信'}"
                )

    def _on_lookback_days_changed(self) -> None:
        if self._suppress_settings_save:
            return
        days = int(self.cmb_days.currentData() or 14)
        self.controller.config["lookback_days"] = days
        self.controller.save_config()
        self.controller.request_scan(force_version=False)

    def _on_timeline_filter_toggled(self, checked: bool) -> None:
        if not self._suppress_settings_save:
            self.controller.config["hide_tab_select_in_timeline"] = bool(checked)
            self.controller.save_config()
        self.refresh_views_from_snapshot()

    def _on_settings_ui_changed(self) -> None:
        if self._suppress_settings_save:
            return
        cfg = self.controller.config
        cfg["poll_interval_sec"] = int(self.cmb_poll_sec.currentData() or 5)
        cfg["reminder_interval_min"] = int(self.cmb_reminder_min.currentData() or 0)
        cfg["popup_on_error"] = self.chk_popup_error.isChecked()
        cfg["keep_popup_until_handled"] = self.chk_keep_popup.isChecked()
        cfg["popup_on_warn"] = self.chk_popup_warn.isChecked()
        cfg["play_sound"] = self.chk_play_sound.isChecked()
        cfg["open_dashboard_on_manual_start"] = self.chk_open_on_manual.isChecked()
        cfg["auto_check_github_update"] = self.chk_auto_check_update.isChecked()
        cfg["auto_apply_update_in_tray"] = self.chk_auto_apply_tray.isChecked()
        self.controller.apply_updated_config()

    def _on_startup_checkbox_toggled(self, checked: bool) -> None:
        ok, msg = set_startup_registered(checked)
        if not ok:
            QMessageBox.warning(self, APP_NAME, msg)
            self.chk_win_startup.blockSignals(True)
            self.chk_win_startup.setChecked(is_startup_registered())
            self.chk_win_startup.blockSignals(False)
        else:
            QMessageBox.information(self, APP_NAME, msg)

    # --- スナップショット反映 ---
    def refresh_views_from_snapshot(self) -> None:
        snap = self.controller.latest_snapshot
        if snap is None:
            return

        unread_sigs = self.controller.unread_error_signatures()
        unread_cnt = len(unread_sigs)
        pub_ver = snap.latest_published_version or "-"

        # 操作者コンボの更新
        current_op = self.cmb_operator.currentData() or "ALL"
        op_names = sorted({u.operator for u in snap.users})
        self.cmb_operator.blockSignals(True)
        self.cmb_operator.clear()
        self.cmb_operator.addItem("（全員）", "ALL")
        for n in op_names:
            self.cmb_operator.addItem(n, n)
        idx_op = self.cmb_operator.findData(current_op)
        self.cmb_operator.setCurrentIndex(idx_op if idx_op >= 0 else 0)
        self.cmb_operator.blockSignals(False)

        # バナー & KPI 更新
        konan_r = snap.factories.get("KONAN")
        kokubu_r = snap.factories.get("KOKUBU")
        any_online = bool((konan_r and konan_r.online) or (kokubu_r and kokubu_r.online))

        active_today_users = [u for u in snap.users if u.is_active_today]
        online_now_users = [u for u in snap.users if u.is_online_now]
        outdated_active = [u for u in active_today_users if u.version_status == "outdated"]
        latest_ver_users = [u for u in snap.users if u.version_status in ("latest", "ahead")]
        outdated_all_users = [u for u in snap.users if u.version_status == "outdated"]

        today_iso = datetime.date.fromtimestamp(snap.scanned_at_epoch).isoformat()
        today_ops_total = sum(u.today_op_count for u in snap.users)
        crit_err_all = [e for e in snap.errors if e.is_error_or_critical]
        warn_all = [e for e in snap.errors if not e.is_error_or_critical]

        if not any_online:
            self._apply_banner_style("offline")
            self.banner_title_lbl.setText("⚪ 共有フォルダへ接続できません（ネットワークまたはVPNを確認してください）")
        elif unread_cnt > 0:
            self._apply_banner_style("error")
            self.banner_title_lbl.setText(
                f"🔴 未確認の内部エラーが {unread_cnt}件 あります！ — [内部エラー・例外監視] タブを確認してください"
            )
        elif outdated_active:
            self._apply_banner_style("outdated")
            names_s = "・".join(f"{u.operator}(v{u.current_version})" for u in outdated_active[:4])
            self.banner_title_lbl.setText(
                f"🟡 監視中（異常なし） — 本日旧バージョンで稼働中のユーザーがいます: {names_s} [最新 v{pub_ver}]"
            )
        else:
            self._apply_banner_style("normal")
            self.banner_title_lbl.setText(
                f"🟢 国分・湖南工場 正常監視中 — 未確認の内部エラーはありません（配信最新 v{pub_ver}）"
            )

        k_stat = "🟢接続OK" if (konan_r and konan_r.online) else "⚪未接続"
        kb_stat = "🟢接続OK" if (kokubu_r and kokubu_r.online) else "⚪未接続"
        scan_t = datetime.datetime.fromtimestamp(snap.scanned_at_epoch).strftime("%H:%M:%S")
        self.banner_sub_lbl.setText(
            f"湖南工場: {k_stat}  |  国分工場: {kb_stat}  |  配信最新: v{pub_ver} ({snap.version_source_note})  |  "
            f"最終スキャン: {scan_t} ({snap.scan_duration_ms:.0f}ms)"
        )

        # フィルタ条件の取得
        f_code = self.cmb_factory.currentData() or "ALL"
        op_filter = self.cmb_operator.currentData() or "ALL"
        q_norm = nfkc_lower(self.txt_search.text().strip())

        # KPI カード（工場フィルタ選択時は該当工場にスコープ）
        scoped_users = [u for u in snap.users if f_code == "ALL" or u.factory_code == f_code]
        scoped_ops = [o for o in snap.operations if f_code == "ALL" or o.factory_code == f_code]
        scoped_errs = [e for e in snap.errors if f_code == "ALL" or e.factory_code == f_code]

        scoped_active_today = [u for u in scoped_users if u.is_active_today]
        scoped_online_now = [u for u in scoped_users if u.is_online_now]
        scoped_latest = [u for u in scoped_users if u.version_status in ("latest", "ahead")]
        scoped_outdated = [u for u in scoped_users if u.version_status == "outdated"]
        scoped_unknown = [u for u in scoped_users if u.version_status == "unknown"]
        scoped_outdated_active = [u for u in scoped_active_today if u.version_status == "outdated"]

        konan_cnt = sum(1 for u in snap.users if u.factory_code == "KONAN")
        kokubu_cnt = sum(1 for u in snap.users if u.factory_code == "KOKUBU")
        self.kpi_users_val.setText(f"本日 {len(scoped_active_today)}名 / 登録 {len(scoped_users)}名")
        if f_code == "ALL":
            self.kpi_users_sub.setText(
                f"直近30分稼働: {len(scoped_online_now)}名 （湖南 {konan_cnt}名・国分 {kokubu_cnt}名）"
            )
        else:
            f_lbl = "湖南工場" if f_code == "KONAN" else "国分工場"
            self.kpi_users_sub.setText(f"[{f_lbl}] 直近30分稼働: {len(scoped_online_now)}名")

        ver_val_txt = f"最新 {len(scoped_latest)}名 / 旧版 {len(scoped_outdated)}名"
        if scoped_unknown:
            ver_val_txt += f" / 未記録 {len(scoped_unknown)}名"
        self.kpi_ver_val.setText(ver_val_txt)
        self.kpi_ver_sub.setText(f"基準配信版: v{pub_ver} （本日旧版稼働: {len(scoped_outdated_active)}名）")

        scoped_today_ops = sum(u.today_op_count for u in scoped_users)
        self.kpi_ops_val.setText(f"本日 {scoped_today_ops} 回")
        self.kpi_ops_sub.setText(f"監視期間内の総操作ログ: {len(scoped_ops)} 件")

        scoped_unread_cnt = sum(1 for e in scoped_errs if e.signature_id in unread_sigs)
        scoped_crit_err = [e for e in scoped_errs if e.is_error_or_critical]
        scoped_warn = [e for e in scoped_errs if not e.is_error_or_critical]
        self.kpi_err_val.setText(f"未確認 {scoped_unread_cnt} 件")
        self.kpi_err_val.setStyleSheet(
            f"font-size: 18px; font-weight: bold; color: {'#dc2626' if scoped_unread_cnt > 0 else '#059669'}; border: none;"
        )
        self.kpi_err_sub.setText(f"期間内エラー: {len(scoped_crit_err)}件 / 警告: {len(scoped_warn)}件")

        # タブ見出しの件数バッジ更新
        self.tabs.setTabText(
            1,
            f"🚨 内部エラー・例外監視 ({unread_cnt}件未読)" if unread_cnt > 0 else f"🚨 内部エラー・例外監視 ({len(crit_err_all)})",
        )
        locked_cnt = sum(1 for u in snap.users if u.pin_is_locked)
        reg_pin_cnt = sum(1 for u in snap.users if u.is_registered_in_store)
        pin_tab_title = (
            f"🔑 ユーザー・PIN管理 ({reg_pin_cnt}名 / 🔒ロック{locked_cnt}名)"
            if locked_cnt > 0
            else f"🔑 ユーザー・PIN管理 ({reg_pin_cnt}名)"
        )
        self.tabs.setTabText(3, pin_tab_title)

        # 設定タブのパス診断
        diag_lines = []
        for ft in FACTORY_TARGETS:
            fr = snap.factories.get(ft.code)
            if fr:
                st_txt = "ONLINE (到達可能)" if fr.online else "OFFLINE (到達不可)"
                diag_lines.append(f"[{ft.label_ja}] {st_txt} | 登録操作者={fr.operator_count}名 | パス={fr.resolved_dir}")
        diag_lines.append(f"[最新バージョン参照] 配信最新=v{pub_ver} ({snap.version_source_note}) / ローカルrepo=v{snap.local_repo_version or '-'}")
        self.lbl_path_diag.setText("\n".join(diag_lines))

        # --- Tab 1 テーブル更新 ---
        self._populate_users_table(snap, f_code, op_filter, q_norm)

        # --- Tab 2 テーブル更新 ---
        self._populate_errors_table(snap, f_code, op_filter, q_norm, unread_sigs)

        # --- Tab 3 テーブル更新 ---
        self._populate_timeline_table(snap, f_code, op_filter, q_norm)

        # --- Tab 4 (PIN管理) テーブル更新 ---
        self._populate_pin_management_table(snap, f_code, op_filter, q_norm)

    def _populate_users_table(
        self,
        snap: MonitorSnapshot,
        f_code: str,
        op_filter: str,
        q_norm: str,
    ) -> None:
        pub_ver = snap.latest_published_version
        show_pin = bool(self.controller.config.get("show_pin_in_tables", True))
        filtered: list[UserStatusSummary] = []
        for u in snap.users:
            if f_code != "ALL" and u.factory_code != f_code:
                continue
            if op_filter != "ALL" and u.operator != op_filter:
                continue
            if q_norm:
                hay = nfkc_lower(
                    f"{u.factory_label} {u.operator} {u.pin_plaintext} {u.pin_status_ja} "
                    f"{u.current_version} {u.last_action_summary} {u.host} {u.os_user}"
                )
                if q_norm not in hay:
                    continue
            filtered.append(u)

        self._displayed_users = filtered
        self.tbl_users.setRowCount(len(filtered))

        selected_row_to_restore = -1
        for row, u in enumerate(filtered):
            if self._selected_user_key == (u.factory_code, u.operator):
                selected_row_to_restore = row

            # 0: 稼働状態
            if u.is_online_now:
                st_txt, st_fg, st_bg = "🟢 稼働中(30分内)", "#065f46", "#d1fae5"
            elif u.is_active_today:
                st_txt, st_fg, st_bg = "🔵 本日利用", "#1e40af", "#dbeafe"
            elif u.last_active_epoch <= 0:
                st_txt, st_fg, st_bg = "⚪ 未稼働 (ログなし)", "#64748b", "#f8fafc"
            else:
                st_txt, st_fg, st_bg = f"⚪ 待機 ({format_relative_ago(u.last_active_epoch, snap.scanned_at_epoch)})", "#475569", "#f1f5f9"
            it_st = self._styled_item(st_txt, fg=st_fg, bg=st_bg, bold=True, align_center=True)
            self.tbl_users.setItem(row, 0, it_st)

            # 1: 工場
            f_fg = "#1d4ed8" if u.factory_code == "KONAN" else "#7e22ce"
            f_bg = "#eff6ff" if u.factory_code == "KONAN" else "#faf5ff"
            self.tbl_users.setItem(
                row, 1, self._styled_item(u.factory_label, fg=f_fg, bg=f_bg, bold=True, align_center=True)
            )

            # 2: ユーザー名
            op_disp = f"👑 {u.operator}" if u.is_admin_user else u.operator
            self.tbl_users.setItem(row, 2, self._styled_item(op_disp, bold=True))

            # 3: PIN番号
            pin_txt, pin_fg, pin_bg = self._format_pin_cell_text(u, show_pin, compact=True)
            pin_it = self._styled_item(pin_txt, fg=pin_fg, bg=pin_bg, bold=True, align_center=True)
            pin_it.setToolTip(f"{u.pin_status_ja}（ダブルクリックでPIN変更）")
            self.tbl_users.setItem(row, 3, pin_it)

            # 4: バージョン
            if not u.current_version:
                v_txt, v_fg, v_bg = "未記録 (未ログイン)", "#64748b", None
            elif u.version_status == "latest":
                v_txt, v_fg, v_bg = f"v{u.current_version} ✅最新", "#065f46", "#ecfdf5"
            elif u.version_status == "ahead":
                v_txt, v_fg, v_bg = f"v{u.current_version} 🚀先行版", "#1e40af", "#eff6ff"
            else:
                v_txt, v_fg, v_bg = f"v{u.current_version} ⚠️旧版(最新v{pub_ver})", "#9a3412", "#ffedd5"
            self.tbl_users.setItem(row, 4, self._styled_item(v_txt, fg=v_fg, bg=v_bg, bold=True))

            # 5: 直近の操作内容
            act_summary = u.last_action_summary if u.last_active_epoch > 0 else "共有操作ログ未出力（ユーザー管理に登録済）"
            self.tbl_users.setItem(row, 5, QTableWidgetItem(act_summary))

            # 6: 最終操作日時
            self.tbl_users.setItem(row, 6, QTableWidgetItem(format_short_ts(u.last_active_epoch)))

            # 7: 本日操作数
            self.tbl_users.setItem(
                row, 7, self._styled_item(f"{u.today_op_count} 回", align_center=True, bold=u.today_op_count > 0)
            )

            # 8: 内部エラー
            if u.today_error_count > 0:
                e_txt = f"🚨 今日 {u.today_error_count}件 (計{u.recent_error_count})"
                e_it = self._styled_item(e_txt, fg="#991b1b", bg="#fee2e2", bold=True, align_center=True)
            elif u.recent_error_count > 0:
                e_txt = f"⚠️ 今日 0件 (期間{u.recent_error_count}件)"
                e_it = self._styled_item(e_txt, fg="#92400e", bg="#fef3c7", bold=False, align_center=True)
            else:
                e_txt = "✓ 0件"
                e_it = self._styled_item(e_txt, fg="#059669", align_center=True)
            self.tbl_users.setItem(row, 8, e_it)

            # 9: PC / OS User
            host_str = f"{u.host or '-'} / {u.os_user or '-'}"
            self.tbl_users.setItem(row, 9, QTableWidgetItem(host_str))

        if selected_row_to_restore >= 0:
            self.tbl_users.blockSignals(True)
            self.tbl_users.selectRow(selected_row_to_restore)
            self.tbl_users.blockSignals(False)
            self._refresh_selected_user_detail()
        elif filtered and self._selected_user_key is None:
            self.tbl_users.selectRow(0)

    def _populate_errors_table(
        self,
        snap: MonitorSnapshot,
        f_code: str,
        op_filter: str,
        q_norm: str,
        unread_sigs: set[str],
    ) -> None:
        only_err = (self.cmb_err_sev.currentData() or "errors_only") == "errors_only"
        unread_only = self.chk_unread_only.isChecked()
        pub_ver = snap.latest_published_version

        filtered: list[ErrorEvent] = []
        for e in snap.errors:
            if only_err and not e.is_error_or_critical:
                continue
            if unread_only and e.signature_id not in unread_sigs:
                continue
            if f_code != "ALL" and e.factory_code != f_code:
                continue
            if op_filter != "ALL" and e.operator != op_filter:
                continue
            if q_norm:
                hay = nfkc_lower(
                    f"{e.factory_label} {e.operator} {e.app_version} {e.category} {e.code_location} {e.headline} {e.stack_trace}"
                )
                if q_norm not in hay:
                    continue
            filtered.append(e)

        self._displayed_errors = filtered
        self.tbl_errors.setRowCount(len(filtered))

        restore_row = -1
        for row, e in enumerate(filtered):
            if e.signature_id == self._selected_error_sig:
                restore_row = row

            is_unread = e.signature_id in unread_sigs
            # 0: 状態
            if is_unread:
                st_it = self._styled_item("🔴 未確認", fg="#991b1b", bg="#fee2e2", bold=True, align_center=True)
            else:
                st_it = self._styled_item("✓ 確認済", fg="#64748b", align_center=True)
            self.tbl_errors.setItem(row, 0, st_it)

            # 1: 重要度
            if e.severity == "critical":
                sev_it = self._styled_item("重大(クラッシュ)", fg="#ffffff", bg="#dc2626", bold=True, align_center=True)
            elif e.severity == "error":
                sev_it = self._styled_item("エラー", fg="#9a3412", bg="#ffedd5", bold=True, align_center=True)
            else:
                sev_it = self._styled_item("警告", fg="#854d0e", bg="#fef9c3", align_center=True)
            self.tbl_errors.setItem(row, 1, sev_it)

            # 2: 日時
            self.tbl_errors.setItem(row, 2, QTableWidgetItem(e.ts_display))

            # 3: 工場
            self.tbl_errors.setItem(row, 3, self._styled_item(e.factory_label, bold=True, align_center=True))

            # 4: ユーザー
            self.tbl_errors.setItem(row, 4, self._styled_item(e.operator, bold=True))

            # 5: 発生版数
            v_str = f"v{e.app_version}" if e.app_version else "-"
            if e.app_version and pub_ver and compare_versions(e.app_version, pub_ver) < 0:
                v_str += " (旧版)"
            self.tbl_errors.setItem(row, 5, QTableWidgetItem(v_str))

            # 6: 分類 / 発生箇所
            loc_txt = f"{e.category} ({e.code_location})" if e.code_location else e.category
            self.tbl_errors.setItem(row, 6, QTableWidgetItem(loc_txt))

            # 7: 概要
            self.tbl_errors.setItem(row, 7, QTableWidgetItem(e.headline))

            # 8: 回数
            self.tbl_errors.setItem(row, 8, self._styled_item(f"{e.occurrence_count}回", align_center=True))

        if restore_row >= 0:
            self.tbl_errors.blockSignals(True)
            self.tbl_errors.selectRow(restore_row)
            self.tbl_errors.blockSignals(False)
            self._update_error_detail_pane(filtered[restore_row])
        elif filtered:
            self.tbl_errors.selectRow(0)
        else:
            self.txt_error_detail.setPlainText("表示条件に一致する内部エラーはありません。")

    def _populate_timeline_table(
        self,
        snap: MonitorSnapshot,
        f_code: str,
        op_filter: str,
        q_norm: str,
    ) -> None:
        hide_tab = self.chk_hide_tab_select.isChecked()
        filtered: list[OperationEvent] = []
        for op in snap.operations:
            if hide_tab and op.is_tab_select:
                continue
            if f_code != "ALL" and op.factory_code != f_code:
                continue
            if op_filter != "ALL" and op.operator != op_filter:
                continue
            if q_norm:
                hay = nfkc_lower(
                    f"{op.factory_label} {op.operator} {op.app_version} {op.feature_ja} {op.summary_ja} {op.host} {op.os_user}"
                )
                if q_norm not in hay:
                    continue
            filtered.append(op)
            if len(filtered) >= 500:  # UI描画高速維持のため最新500件まで表示
                break

        self._displayed_timeline_ops = filtered
        self.lbl_timeline_count.setText(f"表示: {len(filtered)} 件")
        self.tbl_timeline.setRowCount(len(filtered))

        for row, op in enumerate(filtered):
            self.tbl_timeline.setItem(row, 0, QTableWidgetItem(op.ts_display))
            f_fg = "#1d4ed8" if op.factory_code == "KONAN" else "#7e22ce"
            self.tbl_timeline.setItem(row, 1, self._styled_item(op.factory_label, fg=f_fg, bold=True, align_center=True))
            self.tbl_timeline.setItem(row, 2, self._styled_item(op.operator, bold=True))
            self.tbl_timeline.setItem(row, 3, QTableWidgetItem(f"v{op.app_version}" if op.app_version else "-"))
            self.tbl_timeline.setItem(row, 4, QTableWidgetItem(op.feature_ja or "-"))
            self.tbl_timeline.setItem(row, 5, QTableWidgetItem(op.summary_ja))

            res_fg = "#dc2626" if op.result == "error" else ("#d97706" if op.result in ("mismatch", "warn") else "#059669")
            self.tbl_timeline.setItem(
                row, 6, self._styled_item(op.result_ja, fg=res_fg, bold=op.result != "ok", align_center=True)
            )
            self.tbl_timeline.setItem(row, 7, QTableWidgetItem(f"{op.host or '-'} / {op.os_user or '-'}"))

    @staticmethod
    def _format_pin_cell_text(
        u: UserStatusSummary,
        show_plain: bool,
        compact: bool = False,
    ) -> tuple[str, str | None, str | None]:
        if not u.is_registered_in_store:
            return ("未登録", "#94a3b8", None)
        if not u.has_pin and not u.pin_plaintext:
            return ("未設定", "#64748b", "#f8fafc")

        raw_pin = u.pin_plaintext if show_plain else ("•" * max(4, len(u.pin_plaintext or "1234")))
        if not u.pin_plaintext and u.has_pin:
            raw_pin = "（平文未記録）" if not compact else "要再設定"

        if u.pin_is_locked:
            txt = f"🔒 {raw_pin}" if compact else raw_pin
            return (txt, "#991b1b", "#fee2e2")
        if u.pin_must_change:
            txt = f"{raw_pin} (初回変更待)" if compact else raw_pin
            return (txt, "#9a3412", "#ffedd5")
        return (raw_pin, "#0f172a", "#f8fafc" if compact else "#ecfdf5")

    def _populate_pin_management_table(
        self,
        snap: MonitorSnapshot,
        f_code: str,
        op_filter: str,
        q_norm: str,
    ) -> None:
        pub_ver = snap.latest_published_version
        show_pin = bool(self.controller.config.get("show_pin_in_tables", True))
        filtered: list[UserStatusSummary] = []

        # 工場順（湖南→国分）＋ 管理者優先・名前順で見やすく並べる
        sorted_candidates = sorted(
            snap.users,
            key=lambda x: (
                0 if x.factory_code == "KONAN" else 1,
                0 if x.is_registered_in_store else 1,
                0 if x.is_admin_user else 1,
                x.operator,
            ),
        )
        for u in sorted_candidates:
            if f_code != "ALL" and u.factory_code != f_code:
                continue
            if op_filter != "ALL" and u.operator != op_filter:
                continue
            if q_norm:
                hay = nfkc_lower(
                    f"{u.factory_label} {u.operator} {u.pin_plaintext} {u.pin_status_ja} "
                    f"{u.aladdin_login_id} {u.current_version} {u.host}"
                )
                if q_norm not in hay:
                    continue
            filtered.append(u)

        self._displayed_pin_users = filtered
        self.tbl_pins.setRowCount(len(filtered))

        mono_font = QFont("Consolas", 11, QFont.Weight.Bold)
        restore_row = -1
        for row, u in enumerate(filtered):
            if self._selected_pin_user_key == (u.factory_code, u.operator):
                restore_row = row

            # 0: 工場
            f_fg = "#1d4ed8" if u.factory_code == "KONAN" else "#7e22ce"
            f_bg = "#eff6ff" if u.factory_code == "KONAN" else "#faf5ff"
            self.tbl_pins.setItem(
                row, 0, self._styled_item(u.factory_label, fg=f_fg, bg=f_bg, bold=True, align_center=True)
            )

            # 1: ユーザー名
            op_disp = f"👑 {u.operator}" if u.is_admin_user else u.operator
            self.tbl_pins.setItem(row, 1, self._styled_item(op_disp, bold=True))

            # 2: 現在のPIN番号
            pin_txt, pin_fg, pin_bg = self._format_pin_cell_text(u, show_pin, compact=False)
            pin_it = self._styled_item(pin_txt, fg=pin_fg, bg=pin_bg, bold=True, align_center=True)
            pin_it.setFont(mono_font)
            self.tbl_pins.setItem(row, 2, pin_it)

            # 3: PIN状態 / ロック状況
            if u.pin_is_locked:
                st_fg, st_bg = "#991b1b", "#fee2e2"
            elif u.pin_must_change or u.pin_failed_attempts > 0:
                st_fg, st_bg = "#9a3412", "#ffedd5"
            elif u.has_pin:
                st_fg, st_bg = "#065f46", "#ecfdf5"
            else:
                st_fg, st_bg = "#64748b", "#f8fafc"
            self.tbl_pins.setItem(
                row, 3, self._styled_item(u.pin_status_ja, fg=st_fg, bg=st_bg, bold=True, align_center=True)
            )

            # 4: 権限
            if not u.is_registered_in_store:
                role_it = self._styled_item("未登録(過去ログのみ)", fg="#94a3b8", align_center=True)
            elif u.is_admin_user:
                role_it = self._styled_item("👑 管理者", fg="#92400e", bg="#fef3c7", bold=True, align_center=True)
            else:
                role_it = self._styled_item("一般操作者", fg="#475569", align_center=True)
            self.tbl_pins.setItem(row, 4, role_it)

            # 5: アラジンRPA連携
            if u.aladdin_login_id:
                pw_note = "PW済" if u.has_aladdin_password else "PW未設定"
                ala_it = self._styled_item(f"✅ {u.aladdin_login_id} ({pw_note})", fg="#0f766e", align_center=True)
            else:
                ala_it = self._styled_item("—", fg="#94a3b8", align_center=True)
            self.tbl_pins.setItem(row, 5, ala_it)

            # 6: 使用バージョン
            if not u.current_version:
                v_txt, v_fg = "未記録", "#64748b"
            elif u.version_status in ("latest", "ahead"):
                v_txt, v_fg = f"v{u.current_version} ✅", "#065f46"
            else:
                v_txt, v_fg = f"v{u.current_version} ⚠️(最新v{pub_ver})", "#9a3412"
            self.tbl_pins.setItem(row, 6, self._styled_item(v_txt, fg=v_fg, bold=bool(u.current_version)))

            # 7: 最終稼働日時
            self.tbl_pins.setItem(row, 7, QTableWidgetItem(format_short_ts(u.last_active_epoch)))

            # 8: 正本ファイル
            self.tbl_pins.setItem(row, 8, QTableWidgetItem(u.operator_store_path or "-"))

        if restore_row >= 0:
            self.tbl_pins.blockSignals(True)
            self.tbl_pins.selectRow(restore_row)
            self.tbl_pins.blockSignals(False)
        elif filtered and self._selected_pin_user_key is None:
            self.tbl_pins.selectRow(0)

    @staticmethod
    def _styled_item(
        text: str,
        fg: str | None = None,
        bg: str | None = None,
        bold: bool = False,
        align_center: bool = False,
    ) -> QTableWidgetItem:
        it = QTableWidgetItem(text)
        if fg:
            it.setForeground(QColor(fg))
        if bg:
            it.setBackground(QColor(bg))
        if bold:
            f = it.font()
            f.setBold(True)
            it.setFont(f)
        if align_center:
            it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        return it

    # --- インタラクションハンドラ ---
    def _on_user_row_selected(self) -> None:
        row = self.tbl_users.currentRow()
        if 0 <= row < len(self._displayed_users):
            u = self._displayed_users[row]
            self._selected_user_key = (u.factory_code, u.operator)
            self._refresh_selected_user_detail()

    def _refresh_selected_user_detail(self) -> None:
        snap = self.controller.latest_snapshot
        if snap is None or self._selected_user_key is None:
            return
        fc, op_name = self._selected_user_key
        u_obj = next((u for u in snap.users if u.factory_code == fc and u.operator == op_name), None)
        if u_obj is None:
            return

        show_pin = bool(self.controller.config.get("show_pin_in_tables", True))
        pin_disp = (u_obj.pin_plaintext or "未設定") if show_pin else ("••••" if u_obj.has_pin else "未設定")
        role_disp = " [👑管理者]" if u_obj.is_admin_user else ""
        self.lbl_user_detail_title.setText(
            f"👤 [{u_obj.factory_label}] {u_obj.operator} さん{role_disp} — "
            f"PIN: {pin_disp} ({u_obj.pin_status_ja}) / 現在 v{u_obj.current_version or '?'} / PC: {u_obj.host or '-'}"
        )

        no_tab = self.chk_user_ops_no_tab.isChecked()
        u_ops = [
            o
            for o in snap.operations
            if o.factory_code == fc and o.operator == op_name and (not no_tab or not o.is_tab_select)
        ][:80]
        self.tbl_user_ops.setRowCount(len(u_ops))
        for r, o in enumerate(u_ops):
            self.tbl_user_ops.setItem(r, 0, QTableWidgetItem(o.ts_display))
            self.tbl_user_ops.setItem(r, 1, QTableWidgetItem(f"v{o.app_version}" if o.app_version else "-"))
            self.tbl_user_ops.setItem(r, 2, QTableWidgetItem(o.summary_ja))
            self.tbl_user_ops.setItem(r, 3, QTableWidgetItem(o.result_ja))

        u_errs = [e for e in snap.errors if e.factory_code == fc and e.operator == op_name][:50]
        self._selected_user_errs_cache = u_errs
        self.tbl_user_errs.setRowCount(len(u_errs))
        for r, e in enumerate(u_errs):
            self.tbl_user_errs.setItem(r, 0, QTableWidgetItem(e.ts_display))
            fg = "#dc2626" if e.is_error_or_critical else "#ca8a04"
            self.tbl_user_errs.setItem(r, 1, self._styled_item(e.severity_ja, fg=fg, bold=True))
            self.tbl_user_errs.setItem(r, 2, QTableWidgetItem(f"v{e.app_version}" if e.app_version else "-"))
            self.tbl_user_errs.setItem(r, 3, QTableWidgetItem(e.headline))

    def _on_user_err_double_clicked(self, row: int, _col: int) -> None:
        errs = getattr(self, "_selected_user_errs_cache", [])
        if 0 <= row < len(errs):
            target = errs[row]
            if not target.is_error_or_critical:
                self.cmb_err_sev.setCurrentIndex(1)  # 警告も表示に切替
            self.focus_error_signature(target.signature_id)

    def _open_selected_user_action_dir(self) -> None:
        snap = self.controller.latest_snapshot
        if snap and self._selected_user_key:
            fc, op = self._selected_user_key
            u = next((x for x in snap.users if x.factory_code == fc and x.operator == op), None)
            if u:
                open_path_in_os(u.action_log_dir)

    def _open_selected_user_remote_dir(self) -> None:
        snap = self.controller.latest_snapshot
        if snap and self._selected_user_key:
            fc, op = self._selected_user_key
            u = next((x for x in snap.users if x.factory_code == fc and x.operator == op), None)
            if u:
                open_path_in_os(u.remote_log_dir)

    def _on_error_row_selected(self) -> None:
        row = self.tbl_errors.currentRow()
        if 0 <= row < len(self._displayed_errors):
            err = self._displayed_errors[row]
            self._selected_error_sig = err.signature_id
            self._update_error_detail_pane(err)

    def _update_error_detail_pane(self, err: ErrorEvent) -> None:
        pub_ver = self.controller.latest_snapshot.latest_published_version if self.controller.latest_snapshot else ""
        report = format_ai_diagnostic_report(err, pub_ver)
        self.txt_error_detail.setPlainText(report)

    def _current_selected_error(self) -> ErrorEvent | None:
        row = self.tbl_errors.currentRow()
        if 0 <= row < len(self._displayed_errors):
            return self._displayed_errors[row]
        return None

    def _mark_selected_error_read(self) -> None:
        err = self._current_selected_error()
        if err:
            self.controller.mark_signature_read(err.signature_id)

    def _copy_selected_error_report(self) -> None:
        err = self._current_selected_error()
        if err:
            self.controller.copy_error_report_to_clipboard(err, show_toast=True)

    def _open_selected_error_file(self) -> None:
        err = self._current_selected_error()
        if err:
            open_path_in_os(err.source_path)

    def _reveal_selected_error_file(self) -> None:
        err = self._current_selected_error()
        if err:
            select_file_in_explorer(err.source_path)

    def focus_error_signature(self, sig_id: str) -> None:
        self._selected_error_sig = sig_id
        self.tabs.setCurrentIndex(1)
        self.refresh_views_from_snapshot()
        for r, e in enumerate(self._displayed_errors):
            if e.signature_id == sig_id:
                self.tbl_errors.selectRow(r)
                self.tbl_errors.scrollToItem(self.tbl_errors.item(r, 0))
                break

    def _export_timeline_csv(self) -> None:
        if not self._displayed_timeline_ops:
            QMessageBox.information(self, APP_NAME, "出力対象の操作履歴がありません。")
            return
        default_name = f"PMD操作監視ログ_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        out_path, _ = QFileDialog.getSaveFileName(
            self, "CSVファイルとして保存", default_name, "CSV Files (*.csv)"
        )
        if not out_path:
            return
        try:
            with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["日時", "工場", "ユーザー", "バージョン", "機能・画面", "操作内容", "結果", "PC名", "OSユーザー"])
                for op in self._displayed_timeline_ops:
                    writer.writerow(
                        [
                            op.ts_display,
                            op.factory_label,
                            op.operator,
                            op.app_version,
                            op.feature_ja,
                            op.summary_ja,
                            op.result_ja,
                            op.host,
                            op.os_user,
                        ]
                    )
            QMessageBox.information(self, APP_NAME, f"CSVを出力しました:\n{out_path}")
        except OSError as exc:
            QMessageBox.warning(self, APP_NAME, f"CSV保存に失敗しました:\n{exc}")

    # --- 管理者専用 PIN・ユーザー管理アクション群 ---
    @staticmethod
    def _admin_actor_label() -> str:
        os_u = os.environ.get("USERNAME") or os.environ.get("USER") or "admin"
        return f"監視ツール管理者({os_u})"

    def _resolve_store_path_for_factory(self, factory_code: str) -> str:
        snap = self.controller.latest_snapshot
        if snap and snap.operator_store_paths.get(factory_code):
            return snap.operator_store_paths[factory_code]
        ft = next((x for x in FACTORY_TARGETS if x.code == factory_code), None)
        if ft:
            base = ft.primary_data_dir if os.path.isdir(ft.primary_data_dir) else ft.unc_data_dir
            return os.path.join(base, "factory-operator-users.bin")
        return ""

    def _on_show_pin_toggled(self, checked: bool) -> None:
        if self._suppress_settings_save:
            return
        self._suppress_settings_save = True
        try:
            self.chk_show_pins_tab1.setChecked(checked)
            self.chk_show_pins_tab4.setChecked(checked)
        finally:
            self._suppress_settings_save = False
        self.controller.config["show_pin_in_tables"] = bool(checked)
        self.controller.save_config()
        self.refresh_views_from_snapshot()

    def _on_pin_row_selected(self) -> None:
        row = self.tbl_pins.currentRow()
        if 0 <= row < len(self._displayed_pin_users):
            u = self._displayed_pin_users[row]
            self._selected_pin_user_key = (u.factory_code, u.operator)

    def _current_selected_tab1_user(self) -> UserStatusSummary | None:
        row = self.tbl_users.currentRow()
        if 0 <= row < len(self._displayed_users):
            return self._displayed_users[row]
        return None

    def _current_selected_pin_tab_user(self) -> UserStatusSummary | None:
        row = self.tbl_pins.currentRow()
        if 0 <= row < len(self._displayed_pin_users):
            return self._displayed_pin_users[row]
        return None

    def _jump_to_pin_tab_for_selected(self) -> None:
        u = self._current_selected_tab1_user()
        if u is not None:
            self._selected_pin_user_key = (u.factory_code, u.operator)
        self.tabs.setCurrentIndex(3)
        self.refresh_views_from_snapshot()
        if self._selected_pin_user_key:
            for r, pu in enumerate(self._displayed_pin_users):
                if (pu.factory_code, pu.operator) == self._selected_pin_user_key:
                    self.tbl_pins.selectRow(r)
                    self.tbl_pins.scrollToItem(self.tbl_pins.item(r, 0))
                    break

    def _on_users_table_double_clicked(self, row: int, col: int) -> None:
        if 0 <= row < len(self._displayed_users) and col == 3:
            self._dialog_change_user_pin(self._displayed_users[row])

    def _on_pin_table_double_clicked(self, row: int, _col: int) -> None:
        if 0 <= row < len(self._displayed_pin_users):
            self._dialog_change_user_pin(self._displayed_pin_users[row])

    def _on_users_table_context_menu(self, pos: QPoint) -> None:
        item = self.tbl_users.itemAt(pos)
        if item is None:
            return
        row = item.row()
        if not (0 <= row < len(self._displayed_users)):
            return
        self.tbl_users.selectRow(row)
        u = self._displayed_users[row]
        menu = self._build_user_pin_context_menu(u, include_log_dirs=True)
        menu.exec(self.tbl_users.viewport().mapToGlobal(pos))

    def _on_pin_table_context_menu(self, pos: QPoint) -> None:
        item = self.tbl_pins.itemAt(pos)
        if item is None:
            return
        row = item.row()
        if not (0 <= row < len(self._displayed_pin_users)):
            return
        self.tbl_pins.selectRow(row)
        u = self._displayed_pin_users[row]
        menu = self._build_user_pin_context_menu(u, include_log_dirs=True)
        menu.exec(self.tbl_pins.viewport().mapToGlobal(pos))

    def _build_user_pin_context_menu(self, u: UserStatusSummary, include_log_dirs: bool = False) -> QMenu:
        menu = QMenu(self)
        act_copy = QAction(f"📋 [{u.factory_label}] {u.operator} さんのPIN番号をコピー", menu)
        act_copy.triggered.connect(lambda: self._copy_user_pin_to_clipboard(u, with_label=False))
        menu.addAction(act_copy)

        act_copy_msg = QAction("💬 工場・氏名・PIN案内文をコピー", menu)
        act_copy_msg.triggered.connect(lambda: self._copy_user_pin_to_clipboard(u, with_label=True))
        menu.addAction(act_copy_msg)

        menu.addSeparator()

        act_edit = QAction("✏️ PIN番号を指定変更…", menu)
        act_edit.triggered.connect(lambda: self._dialog_change_user_pin(u))
        menu.addAction(act_edit)

        act_rand = QAction("🎲 ランダム4桁PINを再発行…", menu)
        act_rand.triggered.connect(lambda: self._action_reissue_random_pin(u))
        menu.addAction(act_rand)

        act_unlock = QAction("🔓 PINロック・失敗回数を解除", menu)
        act_unlock.setEnabled(u.is_registered_in_store and (u.pin_failed_attempts > 0 or u.pin_must_change))
        act_unlock.triggered.connect(lambda: self._action_unlock_user_pin(u))
        menu.addAction(act_unlock)

        act_admin = QAction(
            "👑 管理者権限を解除…" if u.is_admin_user else "👑 管理者権限を付与…",
            menu,
        )
        act_admin.setEnabled(u.is_registered_in_store)
        act_admin.triggered.connect(lambda: self._action_toggle_admin_role(u))
        menu.addAction(act_admin)

        if include_log_dirs:
            menu.addSeparator()
            act_adir = QAction("📂 操作ログフォルダを開く", menu)
            act_adir.triggered.connect(lambda: open_path_in_os(u.action_log_dir))
            menu.addAction(act_adir)

            act_rdir = QAction("📂 remote_logフォルダを開く", menu)
            act_rdir.triggered.connect(lambda: open_path_in_os(u.remote_log_dir))
            menu.addAction(act_rdir)
        return menu

    def _notify_pin_mutation_success(self, status_msg: str) -> None:
        self.lbl_pin_op_status.setText(f"✅ {status_msg}")
        self.controller.scanner.invalidate_pin_cache()
        self.controller.request_scan(force_version=False)

    def _copy_user_pin_to_clipboard(self, u: UserStatusSummary | None, with_label: bool = False) -> None:
        if u is None:
            QMessageBox.information(self, APP_NAME, "対象のユーザーを表から選択してください。")
            return
        if not u.pin_plaintext:
            QMessageBox.information(
                self,
                APP_NAME,
                f"[{u.factory_label}] {u.operator} さんの平文PINが記録されていません。\n"
                "「✏️ PINを指定変更」または「🎲 ランダム4桁PIN再発行」から新しいPINを設定してください。",
            )
            return
        text = (
            f"【{u.factory_label}】{u.operator} さんのPIN番号: {u.pin_plaintext}"
            if with_label
            else u.pin_plaintext
        )
        QGuiApplication.clipboard().setText(text)
        msg = f"[{u.factory_label}] {u.operator} さんのPINをコピーしました"
        self.lbl_pin_op_status.setText(f"📋 {msg}")
        self.controller.tray.showMessage(
            APP_NAME,
            msg,
            QSystemTrayIcon.MessageIcon.Information,
            2200,
        )

    def _dialog_change_user_pin(self, u: UserStatusSummary | None) -> None:
        if u is None:
            QMessageBox.information(self, APP_NAME, "PINを変更するユーザーを表から選択してください。")
            return

        store_path = u.operator_store_path or self._resolve_store_path_for_factory(u.factory_code)
        if not store_path or not os.path.isdir(os.path.dirname(store_path)):
            QMessageBox.warning(
                self,
                APP_NAME,
                f"{u.factory_label} の共有フォルダへ接続できないためPINを更新できません:\n{store_path}",
            )
            return

        dlg = QDialog(self)
        dlg.setWindowTitle(f"PIN番号の変更 — [{u.factory_label}] {u.operator}")
        dlg.setMinimumWidth(430)
        vlay = QVBoxLayout(dlg)
        vlay.setSpacing(10)

        cur_info = u.pin_plaintext if u.pin_plaintext else ("（平文未記録）" if u.has_pin else "（未設定）")
        reg_warn = (
            ""
            if u.is_registered_in_store
            else "\n※このユーザーは現在正本ファイルに未登録のため、保存時に新規登録されます。"
        )
        hdr = QLabel(
            f"対象: <b>[{u.factory_label}] {u.operator}</b> さん<br>"
            f"現在のPIN番号: <b>{cur_info}</b> （状態: {u.pin_status_ja}）{reg_warn}"
        )
        hdr.setWordWrap(True)
        vlay.addWidget(hdr)

        form = QFormLayout()
        pin_row = QHBoxLayout()
        txt_pin = QLineEdit(u.pin_plaintext or "")
        txt_pin.setPlaceholderText(f"{MIN_PIN_LENGTH}〜{MAX_PIN_LENGTH}桁の数字（全角数字も自動で半角化）")
        txt_pin.selectAll()
        pin_row.addWidget(txt_pin, 1)

        btn_gen = QPushButton("🎲 4桁自動生成")
        btn_gen.setProperty("class", "secondaryBtn")
        btn_gen.clicked.connect(lambda: txt_pin.setText(generate_random_pin(4)))
        pin_row.addWidget(btn_gen)
        form.addRow("新しいPIN番号:", pin_row)

        chk_must_change = QCheckBox("次回ログイン時に本人へPIN変更を求める（仮PINとして発行する場合）")
        chk_must_change.setChecked(False)
        form.addRow("", chk_must_change)

        chk_copy_after = QCheckBox("保存後に新しいPIN番号をクリップボードへコピーする")
        chk_copy_after.setChecked(True)
        form.addRow("", chk_copy_after)
        vlay.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        btns.button(QDialogButtonBox.StandardButton.Save).setText("💾 PINを保存")
        btns.button(QDialogButtonBox.StandardButton.Cancel).setText("キャンセル")
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        vlay.addWidget(btns)

        txt_pin.setFocus()
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        pin_norm = normalize_pin(txt_pin.text())
        if pin_norm is None:
            QMessageBox.warning(
                self,
                APP_NAME,
                f"PIN番号は {MIN_PIN_LENGTH}〜{MAX_PIN_LENGTH}桁の数字（0〜9）で入力してください。",
            )
            return

        try:
            if u.is_registered_in_store:
                saved_pin = set_operator_pin(
                    store_path=store_path,
                    factory_code=u.factory_code,
                    operator_name=u.operator,
                    new_pin=pin_norm,
                    require_change_on_login=chk_must_change.isChecked(),
                    admin_actor=self._admin_actor_label(),
                )
            else:
                saved_pin = add_operator_user(
                    store_path=store_path,
                    factory_code=u.factory_code,
                    operator_name=u.operator,
                    initial_pin=pin_norm,
                    require_change_on_login=chk_must_change.isChecked(),
                    is_admin=False,
                    admin_actor=self._admin_actor_label(),
                )
            if chk_copy_after.isChecked():
                QGuiApplication.clipboard().setText(saved_pin)
            self._notify_pin_mutation_success(f"[{u.factory_label}] {u.operator} さんのPINを更新しました")
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"PINの保存に失敗しました:\n{exc}")

    def _action_reissue_random_pin(self, u: UserStatusSummary | None) -> None:
        if u is None:
            QMessageBox.information(self, APP_NAME, "対象のユーザーを表から選択してください。")
            return
        if not u.is_registered_in_store:
            self._dialog_change_user_pin(u)
            return

        store_path = u.operator_store_path or self._resolve_store_path_for_factory(u.factory_code)
        ans = QMessageBox.question(
            self,
            APP_NAME,
            f"[{u.factory_label}] {u.operator} さんにランダム4桁の新しいPINを再発行しますか？\n\n"
            "・ロック状態／失敗回数はリセットされます\n"
            "・次回ログイン時に本人が希望のPINへ変更できる「初回変更待」状態になります\n"
            "・発行されたPINは自動でクリップボードにコピーされます",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return

        try:
            issued_pin = reissue_random_pin(
                store_path=store_path,
                factory_code=u.factory_code,
                operator_name=u.operator,
                digits=4,
                require_change_on_login=True,
                admin_actor=self._admin_actor_label(),
            )
            QGuiApplication.clipboard().setText(issued_pin)
            self._notify_pin_mutation_success(
                f"[{u.factory_label}] {u.operator} さんのPINを再発行しクリップボードへコピーしました"
            )
            QMessageBox.information(
                self,
                APP_NAME,
                f"[{u.factory_label}] {u.operator} さんの新しいPINを発行しました:\n\n"
                f"🔑 新PIN番号:  {issued_pin}\n\n"
                "（クリップボードにコピー済みです）",
            )
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"ランダムPIN再発行に失敗しました:\n{exc}")

    def _action_unlock_user_pin(self, u: UserStatusSummary | None) -> None:
        if u is None:
            QMessageBox.information(self, APP_NAME, "対象のユーザーを表から選択してください。")
            return
        if not u.is_registered_in_store:
            QMessageBox.information(self, APP_NAME, "このユーザーは正本ファイルに未登録です。")
            return
        if u.pin_failed_attempts == 0 and not u.pin_must_change:
            QMessageBox.information(
                self,
                APP_NAME,
                f"[{u.factory_label}] {u.operator} さんは現在ロックされておらず、失敗回数も0回です。",
            )
            return

        clear_must = False
        if u.pin_must_change:
            ans = QMessageBox.question(
                self,
                APP_NAME,
                f"[{u.factory_label}] {u.operator} さんの失敗回数 ({u.pin_failed_attempts}回) を解除します。\n"
                "あわせて「🆕 初回変更待」フラグも解除して、現在のPINのまま継続利用できるようにしますか？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Yes,
            )
            if ans == QMessageBox.StandardButton.Cancel:
                return
            clear_must = ans == QMessageBox.StandardButton.Yes

        store_path = u.operator_store_path or self._resolve_store_path_for_factory(u.factory_code)
        try:
            unlock_operator_pin(
                store_path=store_path,
                factory_code=u.factory_code,
                operator_name=u.operator,
                clear_must_change=clear_must,
                admin_actor=self._admin_actor_label(),
            )
            self._notify_pin_mutation_success(f"[{u.factory_label}] {u.operator} さんのPINロック/失敗回数を解除しました")
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"ロック解除に失敗しました:\n{exc}")

    def _action_toggle_admin_role(self, u: UserStatusSummary | None) -> None:
        if u is None:
            QMessageBox.information(self, APP_NAME, "対象のユーザーを表から選択してください。")
            return
        if not u.is_registered_in_store:
            QMessageBox.information(self, APP_NAME, "先にユーザーのPIN設定（正本登録）を行ってください。")
            return

        target_admin = not u.is_admin_user
        verb = "付与" if target_admin else "解除"
        ans = QMessageBox.question(
            self,
            APP_NAME,
            f"[{u.factory_label}] {u.operator} さんの PMD 管理者権限を【{verb}】しますか？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return

        store_path = u.operator_store_path or self._resolve_store_path_for_factory(u.factory_code)
        try:
            set_operator_admin_role(
                store_path=store_path,
                factory_code=u.factory_code,
                operator_name=u.operator,
                is_admin=target_admin,
                admin_actor=self._admin_actor_label(),
            )
            self._notify_pin_mutation_success(f"[{u.factory_label}] {u.operator} さんの管理者権限を{verb}しました")
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"管理者権限の更新に失敗しました:\n{exc}")

    def _dialog_add_operator_user(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("新規ユーザーの追加登録")
        dlg.setMinimumWidth(440)
        vlay = QVBoxLayout(dlg)
        vlay.setSpacing(10)

        form = QFormLayout()
        cmb_fac = QComboBox()
        cmb_fac.addItem("湖南工場 (KONAN)", "KONAN")
        cmb_fac.addItem("国分工場 (KOKUBU)", "KOKUBU")
        cur_f = self.cmb_factory.currentData()
        if cur_f in ("KONAN", "KOKUBU"):
            cmb_fac.setCurrentIndex(cmb_fac.findData(cur_f))
        form.addRow("登録先の工場:", cmb_fac)

        txt_name = QLineEdit()
        txt_name.setPlaceholderText("例: 山田")
        form.addRow("ユーザー名（氏名）:", txt_name)

        pin_row = QHBoxLayout()
        txt_pin = QLineEdit(generate_random_pin(4))
        txt_pin.setPlaceholderText("空欄の場合はランダム4桁を自動発行")
        pin_row.addWidget(txt_pin, 1)
        btn_rnd = QPushButton("🎲 再生成")
        btn_rnd.setProperty("class", "secondaryBtn")
        btn_rnd.clicked.connect(lambda: txt_pin.setText(generate_random_pin(4)))
        pin_row.addWidget(btn_rnd)
        form.addRow("初期PIN番号:", pin_row)

        chk_must = QCheckBox("初回ログイン時に本人へPIN変更を求める")
        chk_must.setChecked(False)
        form.addRow("", chk_must)

        chk_admin = QCheckBox("👑 PMD 管理者権限を付与する")
        chk_admin.setChecked(False)
        form.addRow("", chk_admin)

        vlay.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        btns.button(QDialogButtonBox.StandardButton.Save).setText("➕ 追加して保存")
        btns.button(QDialogButtonBox.StandardButton.Cancel).setText("キャンセル")
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        vlay.addWidget(btns)

        txt_name.setFocus()
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        fcode = str(cmb_fac.currentData() or "KONAN")
        flabel = FACTORY_LABELS_JA.get(fcode, fcode)
        store_path = self._resolve_store_path_for_factory(fcode)
        if not store_path or not os.path.isdir(os.path.dirname(store_path)):
            QMessageBox.warning(self, APP_NAME, f"{flabel} の共有フォルダへ接続できません:\n{store_path}")
            return

        try:
            issued_pin = add_operator_user(
                store_path=store_path,
                factory_code=fcode,
                operator_name=txt_name.text(),
                initial_pin=txt_pin.text().strip() or None,
                require_change_on_login=chk_must.isChecked(),
                is_admin=chk_admin.isChecked(),
                admin_actor=self._admin_actor_label(),
            )
            QGuiApplication.clipboard().setText(issued_pin)
            norm_nm = txt_name.text().strip()
            self._selected_pin_user_key = (fcode, norm_nm)
            self._notify_pin_mutation_success(
                f"[{flabel}] に「{norm_nm}」さんを追加しました（PINをクリップボードにコピー済）"
            )
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"ユーザー追加に失敗しました:\n{exc}")

    def _action_remove_operator_user(self, u: UserStatusSummary | None) -> None:
        if u is None:
            QMessageBox.information(self, APP_NAME, "削除するユーザーを表から選択してください。")
            return
        if not u.is_registered_in_store:
            QMessageBox.information(
                self,
                APP_NAME,
                f"[{u.factory_label}] {u.operator} さんは既に factory-operator-users.bin から削除されています（過去ログのみ存在）。",
            )
            return

        ans = QMessageBox.warning(
            self,
            APP_NAME,
            f"[{u.factory_label}] からユーザー「{u.operator}」さんを削除しますか？\n\n"
            "※削除前に自動で世代バックアップが作成されます（過去の操作ログ自体は消えません）。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return

        store_path = u.operator_store_path or self._resolve_store_path_for_factory(u.factory_code)
        try:
            remove_operator_user(
                store_path=store_path,
                factory_code=u.factory_code,
                operator_name=u.operator,
                admin_actor=self._admin_actor_label(),
            )
            self._notify_pin_mutation_success(f"[{u.factory_label}] から「{u.operator}」さんを削除しました")
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"ユーザー削除に失敗しました:\n{exc}")

    def _action_manual_pin_backup(self) -> None:
        created: list[str] = []
        cur_f = self.cmb_factory.currentData() or "ALL"
        targets = [ft for ft in FACTORY_TARGETS if cur_f == "ALL" or ft.code == cur_f]
        for ft in targets:
            sp = self._resolve_store_path_for_factory(ft.code)
            if sp and os.path.isfile(sp):
                entry = create_store_backup(
                    store_path=sp,
                    label=f"手動バックアップ ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})",
                    admin_actor=self._admin_actor_label(),
                )
                if entry:
                    created.append(f"・{ft.label_ja}: {entry.folder_name}")
        if created:
            self.lbl_pin_op_status.setText("💾 バックアップを作成しました")
            QMessageBox.information(
                self,
                APP_NAME,
                "ユーザー・PIN管理ファイルの世代バックアップを作成しました:\n\n" + "\n".join(created),
            )
        else:
            QMessageBox.warning(self, APP_NAME, "バックアップ対象の正本ファイルが見つかりませんでした。")

    def _dialog_restore_pin_backup(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("バックアップからのユーザー・PIN復元")
        dlg.setMinimumSize(680, 420)
        vlay = QVBoxLayout(dlg)
        vlay.setSpacing(8)

        top_row = QHBoxLayout()
        top_row.addWidget(QLabel("対象工場:"))
        cmb_fac = QComboBox()
        cmb_fac.addItem("湖南工場 (KONAN)", "KONAN")
        cmb_fac.addItem("国分工場 (KOKUBU)", "KOKUBU")
        cur_f = self.cmb_factory.currentData()
        if cur_f in ("KONAN", "KOKUBU"):
            cmb_fac.setCurrentIndex(cmb_fac.findData(cur_f))
        top_row.addWidget(cmb_fac)
        top_row.addStretch(1)
        vlay.addLayout(top_row)

        tbl_bk = QTableWidget(0, 3, dlg)
        tbl_bk.setHorizontalHeaderLabels(["作成日時", "バックアップラベル", "作成者"])
        self._configure_readonly_table(tbl_bk)
        bh = tbl_bk.horizontalHeader()
        bh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        bh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        bh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        vlay.addWidget(tbl_bk, 1)

        entries_holder: list[PinBackupEntry] = []

        def _reload_backups() -> None:
            fcode = str(cmb_fac.currentData() or "KONAN")
            sp = self._resolve_store_path_for_factory(fcode)
            bks = list_store_backups(sp)
            entries_holder.clear()
            entries_holder.extend(bks)
            tbl_bk.setRowCount(len(bks))
            for idx, bk in enumerate(bks):
                tbl_bk.setItem(idx, 0, QTableWidgetItem(bk.created_at_display))
                tbl_bk.setItem(idx, 1, QTableWidgetItem(bk.label))
                tbl_bk.setItem(idx, 2, QTableWidgetItem(bk.created_by or "-"))
            if bks:
                tbl_bk.selectRow(0)

        cmb_fac.currentIndexChanged.connect(lambda _i: _reload_backups())
        _reload_backups()

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.button(QDialogButtonBox.StandardButton.Ok).setText("⏪ 選択した世代へ復元")
        btns.button(QDialogButtonBox.StandardButton.Cancel).setText("閉じる")
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        vlay.addWidget(btns)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        sel_row = tbl_bk.currentRow()
        if not (0 <= sel_row < len(entries_holder)):
            return
        chosen = entries_holder[sel_row]
        fcode = str(cmb_fac.currentData() or "KONAN")
        flabel = FACTORY_LABELS_JA.get(fcode, fcode)
        sp = self._resolve_store_path_for_factory(fcode)

        ans = QMessageBox.question(
            self,
            APP_NAME,
            f"[{flabel}] のユーザー・PINデータを以下のバックアップ時点へ復元しますか？\n\n"
            f"日時: {chosen.created_at_display}\n"
            f"内容: {chosen.label}\n\n"
            "※復元直前の現在データも自動的にバックアップ退避されます。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return

        try:
            restore_store_from_backup(
                store_path=sp,
                backup_bin_path=chosen.bin_path,
                admin_actor=self._admin_actor_label(),
            )
            self._notify_pin_mutation_success(f"[{flabel}] を {chosen.created_at_display} のバックアップから復元しました")
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"バックアップ復元に失敗しました:\n{exc}")

    def _export_pins_csv(self) -> None:
        if not self._displayed_pin_users:
            QMessageBox.information(self, APP_NAME, "出力対象のユーザーがいません。")
            return
        default_name = f"PMD工場別ユーザーPIN一覧_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        out_path, _ = QFileDialog.getSaveFileName(
            self, "PIN一覧をCSVとして保存（取扱注意）", default_name, "CSV Files (*.csv)"
        )
        if not out_path:
            return
        try:
            with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(
                    [
                        "工場",
                        "ユーザー名",
                        "PIN番号",
                        "PIN状態",
                        "権限",
                        "アラジンID",
                        "使用バージョン",
                        "最終稼働日時",
                    ]
                )
                for u in self._displayed_pin_users:
                    writer.writerow(
                        [
                            u.factory_label,
                            u.operator,
                            u.pin_plaintext,
                            u.pin_status_ja,
                            "管理者" if u.is_admin_user else ("一般" if u.is_registered_in_store else "未登録"),
                            u.aladdin_login_id,
                            u.current_version,
                            format_epoch(u.last_active_epoch),
                        ]
                    )
            QMessageBox.information(self, APP_NAME, f"PIN一覧CSVを出力しました:\n{out_path}")
        except OSError as exc:
            QMessageBox.warning(self, APP_NAME, f"CSV保存に失敗しました:\n{exc}")

    def closeEvent(self, event: Any) -> None:
        # [✕] で終了せずタスクトレイ常駐を継続する
        event.ignore()
        self.hide()
        self.controller.notify_minimized_once()


# ---------------------------------------------------------------------------
# タスクトレイ常駐コントローラー本体
# ---------------------------------------------------------------------------
class PmdUserMonitorApp(QObject):
    def __init__(self, app: QApplication, started_from_startup: bool = False) -> None:
        super().__init__()
        self.app = app
        self.started_from_startup = started_from_startup

        self.config = self._load_config()
        self._read_sigs, self._notified_sigs, self._first_run_ever = self._load_seen_state()

        self.scanner = IncrementalLogScanner()
        self.latest_snapshot: MonitorSnapshot | None = None
        self._worker: ScanWorker | None = None
        self._minimized_hint_shown = False

        # GitHub 差分アップデート状態
        self.update_info: MonitorUpdateInfo | None = None
        self._update_check_worker: UpdateCheckWorker | None = None
        self._update_apply_worker: UpdateApplyWorker | None = None
        self._notified_update_versions: set[str] = set()

        # 単一インスタンス待受サーバー
        self.local_server = QLocalServer(self)
        QLocalServer.removeServer(SINGLE_INSTANCE_KEY)
        self.local_server.listen(SINGLE_INSTANCE_KEY)
        self.local_server.newConnection.connect(self._on_ipc_connection)

        # スライドアップ通知ポップアップ & メイン画面
        self.popup = ErrorAlertPopup(
            on_open_error_tab_cb=self.open_dashboard_to_error,
            on_mark_all_read_cb=self.mark_all_errors_read,
            on_copy_report_cb=lambda ev: self.copy_error_report_to_clipboard(ev, show_toast=True),
        )
        self.main_win = MainWindow(self)
        self.main_win.sync_controls_from_config(self.config)

        # タスクトレイアイコン構築
        self.tray = QSystemTrayIcon(create_monitor_tray_icon(0, True, False), self)
        self.tray.setToolTip(f"{APP_NAME} v{APP_VERSION}\n初回スキャン中…")
        self._build_tray_menu()
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

        # 定期スキャンタイマー & リマインドタイマー & GitHub差分更新チェックタイマー(3分周期)
        self.poll_timer = QTimer(self)
        self.poll_timer.timeout.connect(lambda: self.request_scan(force_version=False))

        self.reminder_timer = QTimer(self)
        self.reminder_timer.timeout.connect(self._on_reminder_tick)

        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(lambda: self.request_self_update_check(manual=False))

        self.apply_updated_config(save=False)

        # 手動起動時は設定に応じてダッシュボード表示
        if not self.started_from_startup and self.config.get("open_dashboard_on_manual_start", True):
            self.show_dashboard()

        # 初回スキャンおよび監視ツール自身のGitHub差分更新チェックを開始
        QTimer.singleShot(150, lambda: self.request_scan(force_version=True))
        if self.config.get("auto_check_github_update", True):
            QTimer.singleShot(1800, lambda: self.request_self_update_check(manual=False))

    def _load_config(self) -> dict[str, Any]:
        cfg = dict(DEFAULT_CONFIG)
        if os.path.isfile(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    cfg.update(loaded)
            except Exception:
                pass
        return cfg

    def save_config(self) -> None:
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def _load_seen_state(self) -> tuple[set[str], set[str], bool]:
        if not os.path.isfile(SEEN_STATE_PATH):
            return set(), set(), True
        try:
            with open(SEEN_STATE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            read_s = set(data.get("read_signatures", []))
            notif_s = set(data.get("notified_signatures", []))
            return read_s, notif_s, False
        except Exception:
            return set(), set(), True

    def _save_seen_state(self) -> None:
        try:
            payload = {
                "updated_at": datetime.datetime.now().isoformat(),
                "read_signatures": sorted(self._read_sigs)[-3000:],
                "notified_signatures": sorted(self._notified_sigs)[-3000:],
            }
            with open(SEEN_STATE_PATH, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def _build_tray_menu(self) -> None:
        menu = QMenu()
        act_open = QAction(f"📊 監視ダッシュボードを開く (v{APP_VERSION})", menu)
        act_open.triggered.connect(self.show_dashboard)
        menu.addAction(act_open)

        act_pin_mgr = QAction("🔑 ユーザー・PIN管理を開く", menu)
        act_pin_mgr.triggered.connect(self.open_dashboard_to_pin_tab)
        menu.addAction(act_pin_mgr)

        self.act_tray_upgrade = QAction("✨ 監視ツールを最新版へ差分アップデート", menu)
        self.act_tray_upgrade.setVisible(False)
        self.act_tray_upgrade.triggered.connect(lambda: self.apply_self_update(interactive=True))
        menu.addAction(self.act_tray_upgrade)

        act_scan = QAction("🔄 今すぐ再スキャン", menu)
        act_scan.triggered.connect(lambda: self.request_scan(force_version=True))
        menu.addAction(act_scan)

        act_chk_upd = QAction("🔍 監視ツールのGitHub更新を確認", menu)
        act_chk_upd.triggered.connect(lambda: self.request_self_update_check(manual=True))
        menu.addAction(act_chk_upd)

        act_ack = QAction("✅ 未確認エラーをすべて既読にする", menu)
        act_ack.triggered.connect(self.mark_all_errors_read)
        menu.addAction(act_ack)

        menu.addSeparator()

        for ft in FACTORY_TARGETS:
            act_f = QAction(f"📂 {ft.label_ja} 共有DATAを開く", menu)
            act_f.triggered.connect(lambda _c=False, code=ft.code: self.open_factory_subdir(code, ""))
            menu.addAction(act_f)

        menu.addSeparator()
        act_quit = QAction("🚪 常駐監視を終了", menu)
        act_quit.triggered.connect(self.quit_app)
        menu.addAction(act_quit)

        self.tray.setContextMenu(menu)

    def apply_updated_config(self, save: bool = True) -> None:
        if save:
            self.save_config()
        sec = max(3, int(self.config.get("poll_interval_sec", 5)))
        self.poll_timer.start(sec * 1000)

        rem_min = int(self.config.get("reminder_interval_min", 15))
        if rem_min > 0:
            self.reminder_timer.start(rem_min * 60 * 1000)
        else:
            self.reminder_timer.stop()

        if self.config.get("auto_check_github_update", True):
            self.update_timer.start(180 * 1000)  # 3分周期
        else:
            self.update_timer.stop()

    def request_scan(self, force_version: bool = False) -> None:
        if self._worker is not None and self._worker.isRunning():
            return
        days = int(self.config.get("lookback_days", 14))
        self._worker = ScanWorker(
            self.scanner,
            lookback_days=days,
            force_version_check=force_version,
            parent=self,
        )
        self._worker.snapshot_ready.connect(self._on_snapshot_ready)
        self._worker.scan_failed.connect(self._on_scan_failed)
        self._worker.start()

    def _on_scan_failed(self, err_msg: str) -> None:
        self.tray.setIcon(create_monitor_tray_icon(0, False, False))
        self.tray.setToolTip(f"{APP_NAME}\nスキャンエラー: {err_msg[:80]}")

    def _on_snapshot_ready(self, snap: MonitorSnapshot) -> None:
        self.latest_snapshot = snap
        today_iso = datetime.date.fromtimestamp(snap.scanned_at_epoch).isoformat()

        # 初回インストール・初回起動時: 前日以前の過去エラーは既読・通知済に登録し、古い通知の爆発を防ぐ
        if self._first_run_ever:
            for e in snap.errors:
                if e.date_str < today_iso or not e.is_error_or_critical:
                    self._read_sigs.add(e.signature_id)
                    self._notified_sigs.add(e.signature_id)
            self._first_run_ever = False
            self._save_seen_state()

        # アラート対象判定
        include_warn = bool(self.config.get("popup_on_warn", False))
        alert_candidates = [
            e
            for e in snap.errors
            if (e.is_error_or_critical or include_warn)
        ]

        new_alerts = [
            e
            for e in alert_candidates
            if e.signature_id not in self._notified_sigs and e.date_str >= today_iso
        ]
        for e in new_alerts:
            self._notified_sigs.add(e.signature_id)
        if new_alerts:
            self._save_seen_state()

        unread_sigs = self.unread_error_signatures()
        unread_list = [e for e in snap.errors if e.signature_id in unread_sigs]

        # トレイアイコンとツールチップ更新
        konan_ok = bool(snap.factories.get("KONAN") and snap.factories["KONAN"].online)
        kokubu_ok = bool(snap.factories.get("KOKUBU") and snap.factories["KOKUBU"].online)
        any_online = konan_ok or kokubu_ok
        has_outdated_active = any(u.is_active_today and u.version_status == "outdated" for u in snap.users)

        icon = create_monitor_tray_icon(len(unread_sigs), any_online, has_outdated_active)
        self.tray.setIcon(icon)
        self.main_win.setWindowIcon(icon)

        konan_today = sum(1 for u in snap.users if u.factory_code == "KONAN" and u.is_active_today)
        kokubu_today = sum(1 for u in snap.users if u.factory_code == "KOKUBU" and u.is_active_today)
        self.tray.setToolTip(
            f"PMD 監視中 (配信最新 v{snap.latest_published_version or '-'})\n"
            f"本日稼働: 湖南 {konan_today}名 / 国分 {kokubu_today}名\n"
            f"未確認エラー: {len(unread_sigs)}件"
        )

        # ダッシュボード表示更新
        self.main_win.refresh_views_from_snapshot()

        # 新規エラー発生時のポップアップ＆チャイム通知
        if new_alerts and self.config.get("popup_on_error", True):
            if self.config.get("play_sound", True):
                play_alert_chime(any(e.severity == "critical" for e in new_alerts))
            self.popup.show_errors(
                new_errors=new_alerts,
                unread_errors=unread_list if unread_list else new_alerts,
                keep_until_handled=bool(self.config.get("keep_popup_until_handled", True)),
                auto_close_sec=int(self.config.get("popup_auto_close_sec", 20)),
            )

        # 未確認エラーがすべて解消されたらポップアップを自動消去
        if not unread_sigs and self.popup.isVisible():
            self.popup.hide_popup()

    def _on_reminder_tick(self) -> None:
        if self.latest_snapshot is None or not self.config.get("popup_on_error", True):
            return
        unread_sigs = self.unread_error_signatures()
        if not unread_sigs:
            return
        unread_list = [e for e in self.latest_snapshot.errors if e.signature_id in unread_sigs]
        if not unread_list:
            return
        if self.config.get("play_sound", True):
            play_alert_chime(False)
        self.popup.show_errors(
            new_errors=unread_list[:2],
            unread_errors=unread_list,
            keep_until_handled=bool(self.config.get("keep_popup_until_handled", True)),
            auto_close_sec=int(self.config.get("popup_auto_close_sec", 20)),
            title_override=f"🔔 未確認の内部エラーが {len(unread_list)}件 残っています（リマインド）",
        )

    def unread_error_signatures(self) -> set[str]:
        if self.latest_snapshot is None:
            return set()
        include_warn = bool(self.config.get("popup_on_warn", False))
        return {
            e.signature_id
            for e in self.latest_snapshot.errors
            if (e.is_error_or_critical or include_warn) and e.signature_id not in self._read_sigs
        }

    def mark_signature_read(self, sig_id: str) -> None:
        self._read_sigs.add(sig_id)
        self._notified_sigs.add(sig_id)
        self._save_seen_state()
        if self.latest_snapshot:
            self._refresh_badge_and_ui()

    def mark_all_errors_read(self) -> None:
        if self.latest_snapshot:
            for e in self.latest_snapshot.errors:
                self._read_sigs.add(e.signature_id)
                self._notified_sigs.add(e.signature_id)
            self._save_seen_state()
            self.popup.hide_popup()
            self._refresh_badge_and_ui()

    def _refresh_badge_and_ui(self) -> None:
        if self.latest_snapshot is None:
            return
        unread_sigs = self.unread_error_signatures()
        any_online = any(fr.online for fr in self.latest_snapshot.factories.values())
        has_outdated = any(u.is_active_today and u.version_status == "outdated" for u in self.latest_snapshot.users)
        icon = create_monitor_tray_icon(len(unread_sigs), any_online, has_outdated)
        self.tray.setIcon(icon)
        self.main_win.setWindowIcon(icon)
        self.main_win.refresh_views_from_snapshot()

    def copy_error_report_to_clipboard(self, err: ErrorEvent, show_toast: bool = False) -> None:
        pub_ver = self.latest_snapshot.latest_published_version if self.latest_snapshot else ""
        report = format_ai_diagnostic_report(err, pub_ver)
        cb: QClipboard = QGuiApplication.clipboard()
        cb.setText(report)
        if show_toast:
            self.tray.showMessage(
                APP_NAME,
                f"[{err.factory_label}] {err.operator} さんのAI調査用レポートをクリップボードにコピーしました。",
                QSystemTrayIcon.MessageIcon.Information,
                3000,
            )

    def trigger_test_popup(self) -> None:
        sample = None
        if self.latest_snapshot:
            crit = [e for e in self.latest_snapshot.errors if e.is_error_or_critical]
            if crit:
                sample = crit[0]
        if sample is None:
            sample = ErrorEvent(
                signature_id="test_sig",
                factory_code="KONAN",
                factory_label="湖南工場",
                operator="テスト操作者",
                epoch=time.time(),
                first_seen_epoch=time.time(),
                ts_display=format_epoch(time.time()),
                date_str=datetime.date.today().isoformat(),
                severity="critical",
                category="Java未捕捉例外(テスト)",
                headline="NullPointerException: テスト通知表示です（実際のエラーではありません）",
                code_location="MainShellController.java:100",
                stack_trace="java.lang.NullPointerException: Test\n\tat jp.co.pm.ai.desktop.MainShellController.test(MainShellController.java:100)",
                app_version=self.latest_snapshot.latest_published_version if self.latest_snapshot else "18.91",
                host="TEST-PC",
                os_user="0000",
                source_path="",
            )
        if self.config.get("play_sound", True):
            play_alert_chime(True)
        self.popup.show_errors(
            new_errors=[sample],
            unread_errors=[sample],
            keep_until_handled=False,
            auto_close_sec=12,
            title_override="🔔 [通知テスト] 内部エラー検知ポップアップのプレビュー",
        )

    def open_factory_subdir(self, factory_code: str, subdir: str) -> None:
        if self.latest_snapshot and factory_code in self.latest_snapshot.factories:
            base = self.latest_snapshot.factories[factory_code].resolved_dir
        else:
            ft = next((x for x in FACTORY_TARGETS if x.code == factory_code), FACTORY_TARGETS[0])
            base = ft.primary_data_dir if os.path.isdir(ft.primary_data_dir) else ft.unc_data_dir
        target = os.path.join(base, subdir) if subdir else base
        open_path_in_os(target)

    def show_dashboard(self) -> None:
        if self.main_win.isMinimized():
            self.main_win.showNormal()
        else:
            self.main_win.show()
        self.main_win.raise_()
        self.main_win.activateWindow()

    def open_dashboard_to_pin_tab(self) -> None:
        self.show_dashboard()
        self.main_win.tabs.setCurrentIndex(3)

    def open_dashboard_to_error(self, sig_id: str) -> None:
        self.show_dashboard()
        if sig_id and sig_id != "test_sig":
            self.main_win.focus_error_signature(sig_id)
        else:
            self.main_win.tabs.setCurrentIndex(1)

    def notify_minimized_once(self) -> None:
        if not self._minimized_hint_shown:
            self._minimized_hint_shown = True
            self.tray.showMessage(
                APP_NAME,
                "タスクトレイでバックグラウンド常駐監視を継続しています。\nアイコンをクリックすると再表示します。",
                QSystemTrayIcon.MessageIcon.Information,
                3000,
            )

    def _on_tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self.show_dashboard()

    def _on_ipc_connection(self) -> None:
        sock = self.local_server.nextPendingConnection()
        if not sock:
            return
        sock.waitForReadyRead(500)
        cmd = bytes(sock.readAll()).decode("utf-8", errors="ignore").strip()
        if cmd == "PING":
            sock.write(b"PONG")
            sock.flush()
            sock.waitForBytesWritten(300)
            sock.disconnectFromServer()
            return
        sock.disconnectFromServer()
        if cmd == "QUIT":
            self.quit_app()
        else:
            self.show_dashboard()

    # --- GitHub 差分アップデート制御 ---
    def request_self_update_check(self, manual: bool = False) -> None:
        if self._update_apply_worker is not None and self._update_apply_worker.isRunning():
            return
        if self._update_check_worker is not None and self._update_check_worker.isRunning():
            return
        if manual:
            self.main_win.refresh_self_update_ui(
                self.update_info,
                applying=False,
                status_override=f"🔄 GitHub 上の差分アップデートを確認中… (現在: v{APP_VERSION})",
            )
        custom_url = str(self.config.get("custom_github_update_url") or "").strip()
        self._update_check_worker = UpdateCheckWorker(
            current_version=APP_VERSION,
            custom_base_url=custom_url,
            manual=manual,
            parent=self,
        )
        self._update_check_worker.update_checked.connect(self._on_self_update_checked)
        self._update_check_worker.start()

    def _on_self_update_checked(self, info: MonitorUpdateInfo, manual: bool) -> None:
        self.update_info = info
        self.main_win.refresh_self_update_ui(info, applying=False)

        if info.update_available and info.remote_version:
            self.act_tray_upgrade.setText(
                f"✨ 監視ツールを最新版へ差分更新 (v{APP_VERSION} → v{info.remote_version})"
            )
            self.act_tray_upgrade.setVisible(True)

            # トレイ格納中（画面非表示中）かつ自動適用ON・Git開発ツリー外であれば静かに自動更新
            if (
                not manual
                and bool(self.config.get("auto_apply_update_in_tray", True))
                and not self.main_win.isVisible()
                and not is_git_working_tree(APP_DIR)
            ):
                self.apply_self_update(interactive=False)
                return

            if info.remote_version not in self._notified_update_versions:
                self._notified_update_versions.add(info.remote_version)
                self.tray.showMessage(
                    APP_NAME,
                    f"監視ツールの新バージョン v{info.remote_version} が配信されています（現在 v{APP_VERSION}）。\n"
                    "上部の「✨ バージョンアップ」ボタンまたはトレイメニューから即座に差分更新できます。",
                    QSystemTrayIcon.MessageIcon.Information,
                    5000,
                )
        else:
            self.act_tray_upgrade.setVisible(False)
            if manual:
                if info.remote_version:
                    QMessageBox.information(
                        self.main_win,
                        APP_NAME,
                        f"現在は最新バージョン (v{APP_VERSION}) です。\nGitHub配信版: v{info.remote_version}",
                    )
                else:
                    QMessageBox.warning(
                        self.main_win,
                        APP_NAME,
                        f"GitHub アップデート情報の確認に失敗しました:\n{info.error}",
                    )

    def apply_self_update(self, interactive: bool = True) -> None:
        if self._update_apply_worker is not None and self._update_apply_worker.isRunning():
            return
        if self.update_info is None or not self.update_info.remote_version:
            if interactive:
                self.request_self_update_check(manual=True)
            return

        if is_git_working_tree(APP_DIR):
            if not interactive:
                return
            ans = QMessageBox.question(
                self.main_win,
                APP_NAME,
                "現在、開発用 Git リポジトリの作業ツリーから直接起動されています。\n"
                f"GitHub 配信版 (v{self.update_info.remote_version}) の差分ファイルを上書き適用して再起動しますか？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if ans != QMessageBox.StandardButton.Yes:
                return

        self._was_dashboard_visible_before_update = self.main_win.isVisible()
        self._was_update_interactive = interactive
        self.main_win.refresh_self_update_ui(
            self.update_info,
            applying=True,
            status_override=f"⏳ GitHub から v{self.update_info.remote_version} の差分パッケージを取得・検証しています…",
        )
        custom_url = str(self.config.get("custom_github_update_url") or "").strip()
        backup_dir = os.path.join(LOCAL_STATE_DIR, "app_backup")
        self._update_apply_worker = UpdateApplyWorker(
            update_info=self.update_info,
            target_app_dir=APP_DIR,
            custom_base_url=custom_url,
            backup_dir=backup_dir,
            parent=self,
        )
        self._update_apply_worker.update_applied.connect(self._on_self_update_applied)
        self._update_apply_worker.update_failed.connect(self._on_self_update_failed)
        self._update_apply_worker.start()

    def _on_self_update_applied(self, new_ver: str, _updated_files: object) -> None:
        reopen = bool(getattr(self, "_was_dashboard_visible_before_update", False))
        self.tray.showMessage(
            APP_NAME,
            f"v{new_ver} への差分アップデートが完了しました。再起動して反映します…",
            QSystemTrayIcon.MessageIcon.Information,
            2500,
        )
        QTimer.singleShot(250, lambda: self.restart_into_updated_app(reopen_dashboard=reopen))

    def _on_self_update_failed(self, err_msg: str) -> None:
        self.main_win.refresh_self_update_ui(self.update_info, applying=False)
        if getattr(self, "_was_update_interactive", True):
            QMessageBox.warning(
                self.main_win,
                APP_NAME,
                f"GitHub 差分アップデートの適用に失敗しました:\n{err_msg}",
            )

    def restart_into_updated_app(self, reopen_dashboard: bool = True) -> None:
        self.poll_timer.stop()
        self.reminder_timer.stop()
        self.update_timer.stop()
        if self._worker is not None and self._worker.isRunning():
            self._worker.wait(1500)
        self.popup.hide_popup()
        self.tray.hide()
        self.local_server.close()
        QLocalServer.removeServer(SINGLE_INSTANCE_KEY)

        extra_flags = ["--restarted-after-update"]
        if not reopen_dashboard:
            extra_flags.append("--startup")

        if getattr(sys, "frozen", False):
            cmd = [os.path.abspath(sys.executable)] + extra_flags
            work_dir = INSTALL_DIR
        else:
            pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
            runner = pyw if os.path.exists(pyw) else sys.executable
            entry_pyw = os.path.join(APP_DIR, "pmd_user_monitor.pyw")
            cmd = [runner, entry_pyw] + extra_flags
            work_dir = APP_DIR

        creation_flags = getattr(subprocess, "DETACHED_PROCESS", 0x00000008) | getattr(
            subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200
        )
        try:
            subprocess.Popen(
                cmd,
                cwd=work_dir,
                close_fds=True,
                creationflags=creation_flags,
            )
        except Exception:
            pass
        self.app.quit()

    def quit_app(self) -> None:
        self.poll_timer.stop()
        self.reminder_timer.stop()
        self.update_timer.stop()
        if self._worker is not None and self._worker.isRunning():
            self._worker.wait(3000)
        if self._update_check_worker is not None and self._update_check_worker.isRunning():
            self._update_check_worker.wait(1500)
        if self._update_apply_worker is not None and self._update_apply_worker.isRunning():
            self._update_apply_worker.wait(3000)
        self.popup.hide_popup()
        self.tray.hide()
        self.local_server.close()
        self.app.quit()


# ---------------------------------------------------------------------------
# エントリポイント & 単一インスタンスIPC制御
# ---------------------------------------------------------------------------
def _send_ipc_command(cmd: str) -> bool:
    sock = QLocalSocket()
    sock.connectToServer(SINGLE_INSTANCE_KEY)
    if sock.waitForConnected(400):
        sock.write(cmd.encode("utf-8"))
        sock.flush()
        sock.waitForBytesWritten(400)
        if cmd == "PING":
            sock.waitForReadyRead(400)
        sock.disconnectFromServer()
        return True
    return False


def main() -> int:
    raw_args = sys.argv[1:]
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)

    if "--save-ico" in raw_args:
        idx = raw_args.index("--save-ico")
        out_ico = (
            raw_args[idx + 1]
            if idx + 1 < len(raw_args)
            else os.path.join(APP_DIR, "pmd_user_monitor.ico")
        )
        save_monitor_ico(out_ico)
        return 0

    args = set(raw_args)
    if "--quit" in args:
        _send_ipc_command("QUIT")
        return 0

    if "--restarted-after-update" in args:
        # 差分更新直後の再起動時は旧プロセスがパイプを閉じるまで最大3秒待機する
        for _ in range(20):
            if not _send_ipc_command("PING"):
                break
            time.sleep(0.15)

    ipc_cmd = "PING" if ("--startup" in args or "--smoke-test" in args) else "SHOW"
    if "--smoke-test" not in args and "--restarted-after-update" not in args and _send_ipc_command(ipc_cmd):
        # 既に常駐プロセスが存在する場合は、手動起動なら前面表示して終了（startup重複時は静かに終了）
        return 0

    is_smoke = "--smoke-test" in args
    controller = PmdUserMonitorApp(
        app,
        started_from_startup=("--startup" in args or is_smoke),
    )

    if is_smoke:
        def _finish_smoke() -> None:
            snap = controller.latest_snapshot
            ipc_ok = _send_ipc_command("PING")
            summary = {
                "app_version": APP_VERSION,
                "app_dir": APP_DIR,
                "ipc_ok": ipc_ok,
                "tray_available": QSystemTrayIcon.isSystemTrayAvailable(),
                "has_snapshot": snap is not None,
                "users": len(snap.users) if snap else 0,
                "operations": len(snap.operations) if snap else 0,
                "errors": len(snap.errors) if snap else 0,
                "latest_published_version": snap.latest_published_version if snap else "",
            }
            print("SMOKE_TEST_RESULT=" + json.dumps(summary, ensure_ascii=False), flush=True)
            controller.quit_app()

        def _poll_smoke_done() -> None:
            if controller.latest_snapshot is not None:
                _finish_smoke()

        smoke_timer = QTimer(controller)
        smoke_timer.timeout.connect(_poll_smoke_done)
        smoke_timer.start(250)
        QTimer.singleShot(15000, _finish_smoke)

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
